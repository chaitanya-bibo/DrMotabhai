import { useState } from "react";
import { BrowserRouter as Router, Routes, Route, Link } from "react-router-dom";
import { HomePage } from "@/app/pages/home-page";
import { PricingPage } from "@/app/pages/pricing-page";
import { TreatmentsPage } from "@/app/pages/treatments-page";
import { ProductsPage } from "@/app/pages/products-page";
import { EducationPage } from "@/app/pages/education-page";
import { EligibilityPage } from "@/app/pages/eligibility-page";
import { FAQPage } from "@/app/pages/faq-page";
import { CheckoutPage } from "@/app/pages/checkout-page";
import { WireframeMultipage } from "@/app/components/wireframe-multipage";
import { PatientEMRPage } from "@/app/pages/patient-emr-page";
import { DoctorDashboardPage } from "@/app/pages/doctor-dashboard-page";
import { ManagerDashboardPage } from "@/app/pages/manager-dashboard-page";
import { DashboardsWireframe } from "@/app/components/dashboards-wireframe";
import { CartProvider } from "@/app/contexts/cart-context";
import { AuthProvider } from "@/app/contexts/auth-context";
import { Toaster } from "@/app/components/ui/sonner";

export default function App() {
  const [showWireframe, setShowWireframe] = useState(false);

  return (
    <AuthProvider>
      <CartProvider>
        <Router>
          <div className="min-h-screen bg-white">
            {/* Toggle Button - Only show on main website pages */}
            {!window.location.pathname.startsWith('/dashboard') && (
              <button
                onClick={() => setShowWireframe(!showWireframe)}
                className="fixed top-4 right-4 z-[100] px-6 py-3 bg-blue-600 text-white rounded-full shadow-lg hover:bg-blue-700 transition-all font-semibold"
                style={{ fontFamily: 'DM Sans' }}
              >
                {showWireframe ? "View Live Site" : "View Wireframe"}
              </button>
            )}

            {showWireframe && !window.location.pathname.startsWith('/dashboard') ? (
              <WireframeMultipage />
            ) : (
              <Routes>
                {/* Main Website Routes */}
                <Route path="/" element={<HomePage />} />
                <Route path="/treatments" element={<TreatmentsPage />} />
                <Route path="/products" element={<ProductsPage />} />
                <Route path="/education" element={<EducationPage />} />
                <Route path="/pricing" element={<PricingPage />} />
                <Route path="/eligibility" element={<EligibilityPage />} />
                <Route path="/faq" element={<FAQPage />} />
                <Route path="/checkout" element={<CheckoutPage />} />
                <Route path="/wireframe" element={<WireframeMultipage />} />
                
                {/* Dashboard Routes - Separate Access */}
                <Route path="/dashboard/patient" element={<PatientEMRPage />} />
                <Route path="/dashboard/doctor" element={<DoctorDashboardPage />} />
                <Route path="/dashboard/manager" element={<ManagerDashboardPage />} />
                <Route path="/dashboard/wireframe" element={<DashboardsWireframe />} />
              </Routes>
            )}
            
            <Toaster />
          </div>
        </Router>
      </CartProvider>
    </AuthProvider>
  );
}