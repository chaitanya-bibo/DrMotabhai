import { Header } from "@/app/components/header";
import { Footer } from "@/app/components/footer";
import { Play, Award, BookOpen, GraduationCap, Users, Star } from "lucide-react";

export function EducationPage() {
  const medications = [
    {
      name: "Semaglutide (Ozempic/Wegovy)",
      description: "Understanding how Semaglutide works for weight loss and diabetes management",
      category: "GLP-1 Medications",
      readTime: "8 min read"
    },
    {
      name: "Tirzepatide (Mounjaro)",
      description: "The dual-action GIP/GLP-1 receptor agonist revolutionizing weight loss",
      category: "GLP-1 Medications",
      readTime: "7 min read"
    },
    {
      name: "Orlistat (Alli/Xenical)",
      description: "How lipase inhibitors work to block fat absorption for weight management",
      category: "Oral Medications",
      readTime: "6 min read"
    },
    {
      name: "Understanding GLP-1 Receptor Agonists",
      description: "A comprehensive guide to how GLP-1 medications help with weight management",
      category: "Educational",
      readTime: "10 min read"
    },
    {
      name: "Managing Side Effects",
      description: "Common side effects of weight loss medications and how to manage them effectively",
      category: "Patient Care",
      readTime: "6 min read"
    },
    {
      name: "Nutrition While on Weight Loss Medication",
      description: "Dietary guidelines and nutrition tips for patients on GLP-1 or oral therapy",
      category: "Nutrition",
      readTime: "9 min read"
    },
    {
      name: "Exercise and Weight Loss Treatment",
      description: "Optimizing your exercise routine while on weight loss medications",
      category: "Fitness",
      readTime: "7 min read"
    }
  ];

  return (
    <div className="min-h-screen bg-white">
      <Header />
      
      {/* Hero Section */}
      <section className="relative pt-32 pb-20 bg-gradient-to-b from-[#4A6B78] to-[#3E5147]">
        <div className="container mx-auto px-4 lg:px-8 max-w-7xl">
          <div className="text-center text-white">
            <h1 
              className="mb-6"
              style={{ 
                fontFamily: 'Bebas Neue',
                fontSize: 'clamp(36px, 5vw, 64px)',
                letterSpacing: '0.02em',
                lineHeight: '1.1'
              }}
            >
              Education & Resources
            </h1>
            <p 
              className="text-xl max-w-3xl mx-auto opacity-90"
              style={{ 
                fontFamily: 'DM Sans',
                fontSize: '18px',
                lineHeight: '1.6'
              }}
            >
              Expert insights, medication guides, and educational content from Dr. Raju and our medical team
            </p>
          </div>
        </div>
      </section>

      {/* Dr. Raju Featured Section */}
      <section className="py-20 lg:py-28 bg-white" id="dr-raju">
        <div className="container mx-auto px-4 lg:px-8 max-w-7xl">
          <div className="bg-gradient-to-br from-[#4A6B78] to-[#3E5147] rounded-3xl overflow-hidden shadow-2xl">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-0">
              {/* Left Side - Image */}
              <div className="relative h-96 lg:h-auto">
                <div className="absolute inset-0 bg-gradient-to-r from-[#3E5147] to-transparent opacity-60 lg:hidden"></div>
                <img
                  src="https://images.unsplash.com/photo-1612349317150-e413f6a5b16d?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxpbmRpYW4lMjBkb2N0b3IlMjBwcm9mZXNzaW9uYWx8ZW58MHx8fHwxNzM4MjU2ODAwfDA&ixlib=rb-4.1.0&q=80&w=1080"
                  alt="Dr. Raju"
                  className="w-full h-full object-cover"
                />
              </div>

              {/* Right Side - Content */}
              <div className="p-8 lg:p-16 text-white flex flex-col justify-center">
                <div className="flex items-center gap-3 mb-6">
                  <div className="w-16 h-1 bg-[#E8BFB8] rounded"></div>
                  <span className="text-sm font-semibold tracking-wider uppercase" style={{ fontFamily: 'DM Sans' }}>
                    Featured Expert
                  </span>
                </div>

                <h2 
                  className="mb-4"
                  style={{ 
                    fontFamily: 'Bebas Neue',
                    fontSize: 'clamp(36px, 4vw, 56px)',
                    letterSpacing: '0.02em',
                    lineHeight: '1.1'
                  }}
                >
                  Dr. Raju
                </h2>

                <p 
                  className="text-2xl mb-6 opacity-90"
                  style={{ 
                    fontFamily: 'DM Sans',
                    fontWeight: '500'
                  }}
                >
                  MD, FACP, FACE
                </p>

                <p 
                  className="text-lg mb-8 leading-relaxed opacity-90"
                  style={{ fontFamily: 'DM Sans', lineHeight: '1.8' }}
                >
                  Leading expert in obesity medicine and metabolic health with over 20 years of experience. 
                  Board-certified in Endocrinology, Diabetes, and Metabolism, Dr. Raju has helped thousands 
                  of patients achieve sustainable weight loss through evidence-based GLP-1 therapy and comprehensive 
                  lifestyle interventions.
                </p>

                {/* Credentials */}
                <div className="grid grid-cols-2 gap-6 mb-8">
                  <div className="flex items-start gap-3">
                    <Award className="w-6 h-6 text-[#E8BFB8] flex-shrink-0 mt-1" />
                    <div>
                      <p className="font-semibold mb-1" style={{ fontFamily: 'DM Sans' }}>Board Certified</p>
                      <p className="text-sm opacity-80">Endocrinology & Obesity Medicine</p>
                    </div>
                  </div>
                  <div className="flex items-start gap-3">
                    <GraduationCap className="w-6 h-6 text-[#E8BFB8] flex-shrink-0 mt-1" />
                    <div>
                      <p className="font-semibold mb-1" style={{ fontFamily: 'DM Sans' }}>Education</p>
                      <p className="text-sm opacity-80">AIIMS Delhi, Johns Hopkins</p>
                    </div>
                  </div>
                  <div className="flex items-start gap-3">
                    <Users className="w-6 h-6 text-[#E8BFB8] flex-shrink-0 mt-1" />
                    <div>
                      <p className="font-semibold mb-1" style={{ fontFamily: 'DM Sans' }}>Experience</p>
                      <p className="text-sm opacity-80">20+ Years in Practice</p>
                    </div>
                  </div>
                  <div className="flex items-start gap-3">
                    <Star className="w-6 h-6 text-[#E8BFB8] flex-shrink-0 mt-1" />
                    <div>
                      <p className="font-semibold mb-1" style={{ fontFamily: 'DM Sans' }}>Patient Rating</p>
                      <p className="text-sm opacity-80">4.9/5 (2,500+ Reviews)</p>
                    </div>
                  </div>
                </div>

                {/* Specializations */}
                <div className="mb-8">
                  <h3 className="text-xl font-bold mb-4" style={{ fontFamily: 'Bebas Neue', letterSpacing: '0.02em' }}>
                    Areas of Expertise
                  </h3>
                  <div className="flex flex-wrap gap-2">
                    {[
                      "GLP-1 Therapy",
                      "Metabolic Health",
                      "Diabetes Management",
                      "Obesity Medicine",
                      "Lifestyle Medicine",
                      "Preventive Care"
                    ].map((specialty, idx) => (
                      <span 
                        key={idx}
                        className="px-4 py-2 bg-white/10 backdrop-blur-sm rounded-full text-sm"
                        style={{ fontFamily: 'DM Sans' }}
                      >
                        {specialty}
                      </span>
                    ))}
                  </div>
                </div>

                {/* Publications */}
                <div className="bg-white/10 backdrop-blur-sm rounded-xl p-6 mb-8">
                  <div className="flex items-start gap-3 mb-3">
                    <BookOpen className="w-5 h-5 text-[#E8BFB8] flex-shrink-0 mt-1" />
                    <div>
                      <h4 className="font-bold mb-2" style={{ fontFamily: 'DM Sans' }}>
                        Published Research & Contributions
                      </h4>
                      <ul className="space-y-2 text-sm opacity-90">
                        <li>• 50+ peer-reviewed publications on obesity and metabolic disorders</li>
                        <li>• Contributing author to "The Complete Guide to GLP-1 Therapy" (2023)</li>
                        <li>• Featured expert in Indian Journal of Endocrinology</li>
                        <li>• Regular speaker at international medical conferences</li>
                      </ul>
                    </div>
                  </div>
                </div>

                {/* CTA Button */}
                <div>
                  <a
                    href="/eligibility"
                    className="inline-block px-8 py-4 bg-white text-[#4A6B78] rounded-lg hover:bg-[#E8BFB8] transition-all font-bold shadow-lg"
                    style={{ fontFamily: 'DM Sans', fontSize: '16px' }}
                  >
                    Schedule Consultation with Dr. Raju
                  </a>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Medication Blogs Section */}
      <section className="py-20 lg:py-28 bg-gray-50">
        <div className="container mx-auto px-4 lg:px-8 max-w-7xl">
          <div className="text-center mb-16">
            <h2 
              className="text-gray-900 mb-4"
              style={{ 
                fontFamily: 'Bebas Neue',
                fontSize: 'clamp(32px, 4vw, 48px)',
                letterSpacing: '0.02em'
              }}
            >
              Educational Resources
            </h2>
            <p 
              className="text-gray-600 max-w-2xl mx-auto"
              style={{ 
                fontFamily: 'DM Sans',
                fontSize: '16px',
                lineHeight: '1.6'
              }}
            >
              Comprehensive guides and articles about GLP-1 medications, treatment protocols, and patient care
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {medications.map((blog, index) => (
              <article 
                key={index}
                className="bg-white rounded-xl shadow-lg hover:shadow-2xl transition-all duration-300 overflow-hidden group cursor-pointer"
              >
                <div className="h-48 bg-gradient-to-br from-[#4A6B78] to-[#3E5147] relative overflow-hidden">
                  <div className="absolute inset-0 flex items-center justify-center">
                    <BookOpen className="w-16 h-16 text-white opacity-30 group-hover:opacity-50 transition-opacity" />
                  </div>
                  <div className="absolute top-4 left-4">
                    <span className="px-3 py-1 bg-white/20 backdrop-blur-sm text-white text-xs rounded-full font-semibold">
                      {blog.category}
                    </span>
                  </div>
                </div>
                
                <div className="p-6">
                  <h3 
                    className="text-xl font-bold text-gray-900 mb-3 group-hover:text-[#4A6B78] transition-colors"
                    style={{ fontFamily: 'DM Sans' }}
                  >
                    {blog.name}
                  </h3>
                  <p 
                    className="text-gray-600 mb-4 text-sm leading-relaxed"
                    style={{ fontFamily: 'DM Sans' }}
                  >
                    {blog.description}
                  </p>
                  <div className="flex items-center justify-between">
                    <span className="text-xs text-gray-500" style={{ fontFamily: 'DM Sans' }}>
                      {blog.readTime}
                    </span>
                    <button className="text-[#4A6B78] hover:text-[#3E5147] font-semibold text-sm flex items-center gap-1 group-hover:gap-2 transition-all">
                      Read More →
                    </button>
                  </div>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
}