import { useState } from "react";
import { Activity, Calendar, FileText, Heart, MessageSquare, Pill, Scale, TrendingDown, User, Bell, ChevronRight, Download, Upload } from "lucide-react";

export function PatientEMRPage() {
  const [activeTab, setActiveTab] = useState("overview");

  const patientData = {
    name: "Priya Sharma",
    mrn: "MRN-2024-0123",
    age: 42,
    gender: "Female",
    bloodType: "O+",
    startWeight: 92,
    currentWeight: 80,
    targetWeight: 70,
    bmi: 29.4,
    program: "Complete Care Plan",
    medication: "Semaglutide 1.0mg",
    startDate: "Jan 15, 2024"
  };

  const vitals = [
    { date: "Jan 29, 2024", weight: "80kg", bp: "125/82", glucose: "102 mg/dL", heartRate: "72 bpm" },
    { date: "Jan 22, 2024", weight: "81.5kg", bp: "128/85", glucose: "105 mg/dL", heartRate: "75 bpm" },
    { date: "Jan 15, 2024", weight: "83kg", bp: "132/88", glucose: "110 mg/dL", heartRate: "78 bpm" }
  ];

  const appointments = [
    { date: "Feb 05, 2024", time: "10:00 AM", type: "Follow-up Consultation", doctor: "Dr. Rajesh Kumar", status: "Scheduled" },
    { date: "Feb 12, 2024", time: "2:30 PM", type: "Nutrition Counseling", provider: "Anjali Desai, RD", status: "Scheduled" },
    { date: "Jan 29, 2024", time: "11:00 AM", type: "Weekly Check-in", doctor: "Nurse Coordinator", status: "Completed" }
  ];

  const medications = [
    { name: "Semaglutide", dosage: "1.0mg", frequency: "Weekly (Monday)", route: "Subcutaneous injection", prescribedBy: "Dr. Rajesh Kumar", startDate: "Jan 15, 2024" },
    { name: "Vitamin B12", dosage: "1000mcg", frequency: "Daily", route: "Oral", prescribedBy: "Dr. Rajesh Kumar", startDate: "Jan 15, 2024" },
    { name: "Multivitamin", dosage: "1 tablet", frequency: "Daily", route: "Oral", prescribedBy: "Dr. Rajesh Kumar", startDate: "Jan 15, 2024" }
  ];

  const labResults = [
    { test: "HbA1c", result: "5.8%", range: "4.0-5.6%", date: "Jan 15, 2024", status: "Borderline" },
    { test: "Lipid Panel - Total Cholesterol", result: "205 mg/dL", range: "<200 mg/dL", date: "Jan 15, 2024", status: "High" },
    { test: "TSH", result: "2.4 mIU/L", range: "0.4-4.0 mIU/L", date: "Jan 15, 2024", status: "Normal" },
    { test: "Liver Function - ALT", result: "28 U/L", range: "7-56 U/L", date: "Jan 15, 2024", status: "Normal" }
  ];

  const messages = [
    { from: "Dr. Rajesh Kumar", subject: "Great progress this week!", date: "Jan 28, 2024", unread: true },
    { from: "Anjali Desai, RD", subject: "New meal plan attached", date: "Jan 26, 2024", unread: true },
    { from: "Nurse Coordinator", subject: "Weekly check-in reminder", date: "Jan 24, 2024", unread: false }
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white border-b border-gray-200 sticky top-0 z-50">
        <div className="px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <h1 className="text-2xl font-bold text-gray-900" style={{ fontFamily: 'Bebas Neue' }}>
                DR. MOTABHAI™ Patient Portal
              </h1>
              <span className="px-3 py-1 bg-[#4A6B78] text-white text-sm rounded-full" style={{ fontFamily: 'DM Sans' }}>
                Patient EMR
              </span>
            </div>
            <div className="flex items-center gap-4">
              <button className="relative p-2 hover:bg-gray-100 rounded-full">
                <Bell className="w-5 h-5 text-gray-600" />
                <span className="absolute top-1 right-1 w-2 h-2 bg-red-500 rounded-full"></span>
              </button>
              <div className="flex items-center gap-3">
                <div className="text-right">
                  <p className="text-sm font-semibold" style={{ fontFamily: 'DM Sans' }}>{patientData.name}</p>
                  <p className="text-xs text-gray-500" style={{ fontFamily: 'DM Sans' }}>{patientData.mrn}</p>
                </div>
                <div className="w-10 h-10 bg-[#4A6B78] rounded-full flex items-center justify-center text-white font-bold">
                  PS
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Navigation Tabs */}
        <div className="px-6 flex gap-6 border-t border-gray-200">
          {[
            { id: "overview", label: "Overview", icon: Activity },
            { id: "vitals", label: "Vitals & Tracking", icon: Heart },
            { id: "medications", label: "Medications", icon: Pill },
            { id: "appointments", label: "Appointments", icon: Calendar },
            { id: "labs", label: "Lab Results", icon: FileText },
            { id: "messages", label: "Messages", icon: MessageSquare }
          ].map(tab => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`flex items-center gap-2 px-4 py-3 border-b-2 transition-colors ${
                activeTab === tab.id 
                  ? "border-[#4A6B78] text-[#4A6B78]" 
                  : "border-transparent text-gray-600 hover:text-gray-900"
              }`}
              style={{ fontFamily: 'DM Sans' }}
            >
              <tab.icon className="w-4 h-4" />
              {tab.label}
            </button>
          ))}
        </div>
      </header>

      {/* Main Content */}
      <main className="p-6 max-w-7xl mx-auto">
        {activeTab === "overview" && (
          <div className="space-y-6">
            {/* Patient Summary Cards */}
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
              <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200">
                <div className="flex items-center justify-between mb-2">
                  <Scale className="w-5 h-5 text-[#4A6B78]" />
                  <span className="text-xs text-green-600 font-semibold">-12kg</span>
                </div>
                <p className="text-3xl font-bold text-gray-900" style={{ fontFamily: 'DM Sans' }}>{patientData.currentWeight}kg</p>
                <p className="text-sm text-gray-500">Current Weight</p>
              </div>

              <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200">
                <div className="flex items-center justify-between mb-2">
                  <TrendingDown className="w-5 h-5 text-[#55675E]" />
                  <span className="text-xs text-blue-600 font-semibold">BMI</span>
                </div>
                <p className="text-3xl font-bold text-gray-900" style={{ fontFamily: 'DM Sans' }}>{patientData.bmi}</p>
                <p className="text-sm text-gray-500">Overweight</p>
              </div>

              <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200">
                <div className="flex items-center justify-between mb-2">
                  <Activity className="w-5 h-5 text-[#3E5147]" />
                  <span className="text-xs text-purple-600 font-semibold">13%</span>
                </div>
                <p className="text-3xl font-bold text-gray-900" style={{ fontFamily: 'DM Sans' }}>12kg</p>
                <p className="text-sm text-gray-500">Weight Lost</p>
              </div>

              <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200">
                <div className="flex items-center justify-between mb-2">
                  <Calendar className="w-5 h-5 text-[#4A6B78]" />
                  <span className="text-xs text-orange-600 font-semibold">2 weeks</span>
                </div>
                <p className="text-3xl font-bold text-gray-900" style={{ fontFamily: 'DM Sans' }}>14</p>
                <p className="text-sm text-gray-500">Days in Program</p>
              </div>
            </div>

            {/* Recent Activity & Upcoming */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {/* Recent Vitals */}
              <div className="bg-white rounded-xl shadow-sm border border-gray-200">
                <div className="p-6 border-b border-gray-200">
                  <h3 className="text-lg font-bold text-gray-900" style={{ fontFamily: 'DM Sans' }}>Latest Vitals</h3>
                </div>
                <div className="p-6 space-y-4">
                  <div className="flex justify-between items-center">
                    <span className="text-gray-600" style={{ fontFamily: 'DM Sans' }}>Blood Pressure</span>
                    <span className="font-semibold text-gray-900">125/82 mmHg</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-gray-600" style={{ fontFamily: 'DM Sans' }}>Blood Glucose</span>
                    <span className="font-semibold text-gray-900">102 mg/dL</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-gray-600" style={{ fontFamily: 'DM Sans' }}>Heart Rate</span>
                    <span className="font-semibold text-gray-900">72 bpm</span>
                  </div>
                  <button className="w-full mt-4 py-2 text-[#4A6B78] hover:bg-gray-50 rounded-lg font-medium text-sm">
                    View All Vitals →
                  </button>
                </div>
              </div>

              {/* Upcoming Appointments */}
              <div className="bg-white rounded-xl shadow-sm border border-gray-200">
                <div className="p-6 border-b border-gray-200">
                  <h3 className="text-lg font-bold text-gray-900" style={{ fontFamily: 'DM Sans' }}>Upcoming Appointments</h3>
                </div>
                <div className="p-6 space-y-4">
                  {appointments.slice(0, 2).map((apt, idx) => (
                    <div key={idx} className="flex items-start gap-3">
                      <div className="w-12 h-12 bg-[#4A6B78]/10 rounded-lg flex flex-col items-center justify-center">
                        <span className="text-xs text-[#4A6B78] font-bold">FEB</span>
                        <span className="text-sm font-bold text-[#4A6B78]">05</span>
                      </div>
                      <div className="flex-1">
                        <p className="font-semibold text-gray-900 text-sm">{apt.type}</p>
                        <p className="text-xs text-gray-500">{apt.doctor || apt.provider}</p>
                        <p className="text-xs text-gray-500">{apt.time}</p>
                      </div>
                    </div>
                  ))}
                  <button className="w-full mt-4 py-2 text-[#4A6B78] hover:bg-gray-50 rounded-lg font-medium text-sm">
                    View All Appointments →
                  </button>
                </div>
              </div>
            </div>

            {/* Current Treatment Plan */}
            <div className="bg-gradient-to-br from-[#4A6B78] to-[#3E5147] rounded-xl shadow-lg text-white p-8">
              <h3 className="text-2xl font-bold mb-6" style={{ fontFamily: 'Bebas Neue' }}>Current Treatment Plan</h3>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div>
                  <p className="text-sm opacity-90 mb-2">Program</p>
                  <p className="text-xl font-bold">{patientData.program}</p>
                </div>
                <div>
                  <p className="text-sm opacity-90 mb-2">Current Medication</p>
                  <p className="text-xl font-bold">{patientData.medication}</p>
                </div>
                <div>
                  <p className="text-sm opacity-90 mb-2">Prescribing Physician</p>
                  <p className="text-xl font-bold">Dr. Rajesh Kumar</p>
                </div>
              </div>
            </div>
          </div>
        )}

        {activeTab === "vitals" && (
          <div className="space-y-6">
            <div className="bg-white rounded-xl shadow-sm border border-gray-200">
              <div className="p-6 border-b border-gray-200 flex items-center justify-between">
                <h3 className="text-lg font-bold text-gray-900" style={{ fontFamily: 'DM Sans' }}>Weight Tracking History</h3>
                <button className="flex items-center gap-2 px-4 py-2 bg-[#4A6B78] text-white rounded-lg hover:bg-[#3E5147]">
                  <Upload className="w-4 h-4" />
                  Log New Entry
                </button>
              </div>
              <div className="p-6">
                <div className="overflow-x-auto">
                  <table className="w-full" style={{ fontFamily: 'DM Sans' }}>
                    <thead className="bg-gray-50">
                      <tr>
                        <th className="px-4 py-3 text-left text-xs font-semibold text-gray-600">Date</th>
                        <th className="px-4 py-3 text-left text-xs font-semibold text-gray-600">Weight</th>
                        <th className="px-4 py-3 text-left text-xs font-semibold text-gray-600">Blood Pressure</th>
                        <th className="px-4 py-3 text-left text-xs font-semibold text-gray-600">Blood Glucose</th>
                        <th className="px-4 py-3 text-left text-xs font-semibold text-gray-600">Heart Rate</th>
                      </tr>
                    </thead>
                    <tbody>
                      {vitals.map((vital, idx) => (
                        <tr key={idx} className="border-b border-gray-100">
                          <td className="px-4 py-4 text-sm text-gray-900">{vital.date}</td>
                          <td className="px-4 py-4 text-sm font-semibold text-gray-900">{vital.weight}</td>
                          <td className="px-4 py-4 text-sm text-gray-900">{vital.bp}</td>
                          <td className="px-4 py-4 text-sm text-gray-900">{vital.glucose}</td>
                          <td className="px-4 py-4 text-sm text-gray-900">{vital.heartRate}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          </div>
        )}

        {activeTab === "medications" && (
          <div className="space-y-6">
            <div className="bg-white rounded-xl shadow-sm border border-gray-200">
              <div className="p-6 border-b border-gray-200">
                <h3 className="text-lg font-bold text-gray-900" style={{ fontFamily: 'DM Sans' }}>Active Medications</h3>
              </div>
              <div className="divide-y divide-gray-100">
                {medications.map((med, idx) => (
                  <div key={idx} className="p-6">
                    <div className="flex items-start justify-between mb-3">
                      <div>
                        <h4 className="font-bold text-gray-900 text-lg">{med.name}</h4>
                        <p className="text-sm text-gray-600">{med.dosage} - {med.frequency}</p>
                      </div>
                      <span className="px-3 py-1 bg-green-100 text-green-700 text-xs rounded-full font-semibold">Active</span>
                    </div>
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
                      <div>
                        <p className="text-gray-500 text-xs">Route</p>
                        <p className="font-semibold text-gray-900">{med.route}</p>
                      </div>
                      <div>
                        <p className="text-gray-500 text-xs">Prescribed By</p>
                        <p className="font-semibold text-gray-900">{med.prescribedBy}</p>
                      </div>
                      <div>
                        <p className="text-gray-500 text-xs">Start Date</p>
                        <p className="font-semibold text-gray-900">{med.startDate}</p>
                      </div>
                      <div>
                        <button className="text-[#4A6B78] hover:underline text-xs font-semibold">View Instructions</button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {activeTab === "appointments" && (
          <div className="space-y-6">
            <div className="bg-white rounded-xl shadow-sm border border-gray-200">
              <div className="p-6 border-b border-gray-200 flex items-center justify-between">
                <h3 className="text-lg font-bold text-gray-900" style={{ fontFamily: 'DM Sans' }}>All Appointments</h3>
                <button className="px-4 py-2 bg-[#4A6B78] text-white rounded-lg hover:bg-[#3E5147]">
                  Schedule New
                </button>
              </div>
              <div className="divide-y divide-gray-100">
                {appointments.map((apt, idx) => (
                  <div key={idx} className="p-6 hover:bg-gray-50 transition-colors">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-4">
                        <div className="w-16 h-16 bg-[#4A6B78]/10 rounded-lg flex flex-col items-center justify-center">
                          <span className="text-xs text-[#4A6B78] font-bold">FEB</span>
                          <span className="text-xl font-bold text-[#4A6B78]">05</span>
                        </div>
                        <div>
                          <h4 className="font-bold text-gray-900">{apt.type}</h4>
                          <p className="text-sm text-gray-600">{apt.doctor || apt.provider}</p>
                          <p className="text-sm text-gray-500">{apt.time}</p>
                        </div>
                      </div>
                      <div className="flex items-center gap-3">
                        <span className={`px-3 py-1 rounded-full text-xs font-semibold ${
                          apt.status === "Scheduled" ? "bg-blue-100 text-blue-700" : "bg-green-100 text-green-700"
                        }`}>
                          {apt.status}
                        </span>
                        <ChevronRight className="w-5 h-5 text-gray-400" />
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {activeTab === "labs" && (
          <div className="space-y-6">
            <div className="bg-white rounded-xl shadow-sm border border-gray-200">
              <div className="p-6 border-b border-gray-200 flex items-center justify-between">
                <h3 className="text-lg font-bold text-gray-900" style={{ fontFamily: 'DM Sans' }}>Laboratory Results</h3>
                <button className="flex items-center gap-2 px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50">
                  <Download className="w-4 h-4" />
                  Download Report
                </button>
              </div>
              <div className="p-6">
                <div className="overflow-x-auto">
                  <table className="w-full" style={{ fontFamily: 'DM Sans' }}>
                    <thead className="bg-gray-50">
                      <tr>
                        <th className="px-4 py-3 text-left text-xs font-semibold text-gray-600">Test Name</th>
                        <th className="px-4 py-3 text-left text-xs font-semibold text-gray-600">Result</th>
                        <th className="px-4 py-3 text-left text-xs font-semibold text-gray-600">Normal Range</th>
                        <th className="px-4 py-3 text-left text-xs font-semibold text-gray-600">Date</th>
                        <th className="px-4 py-3 text-left text-xs font-semibold text-gray-600">Status</th>
                      </tr>
                    </thead>
                    <tbody>
                      {labResults.map((lab, idx) => (
                        <tr key={idx} className="border-b border-gray-100">
                          <td className="px-4 py-4 text-sm text-gray-900 font-semibold">{lab.test}</td>
                          <td className="px-4 py-4 text-sm font-semibold text-gray-900">{lab.result}</td>
                          <td className="px-4 py-4 text-sm text-gray-600">{lab.range}</td>
                          <td className="px-4 py-4 text-sm text-gray-600">{lab.date}</td>
                          <td className="px-4 py-4">
                            <span className={`px-3 py-1 rounded-full text-xs font-semibold ${
                              lab.status === "Normal" ? "bg-green-100 text-green-700" :
                              lab.status === "High" ? "bg-red-100 text-red-700" :
                              "bg-yellow-100 text-yellow-700"
                            }`}>
                              {lab.status}
                            </span>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          </div>
        )}

        {activeTab === "messages" && (
          <div className="space-y-6">
            <div className="bg-white rounded-xl shadow-sm border border-gray-200">
              <div className="p-6 border-b border-gray-200 flex items-center justify-between">
                <h3 className="text-lg font-bold text-gray-900" style={{ fontFamily: 'DM Sans' }}>Messages</h3>
                <button className="px-4 py-2 bg-[#4A6B78] text-white rounded-lg hover:bg-[#3E5147]">
                  New Message
                </button>
              </div>
              <div className="divide-y divide-gray-100">
                {messages.map((msg, idx) => (
                  <div key={idx} className={`p-6 hover:bg-gray-50 transition-colors cursor-pointer ${msg.unread ? 'bg-blue-50/30' : ''}`}>
                    <div className="flex items-start justify-between">
                      <div className="flex items-start gap-4">
                        <div className="w-10 h-10 bg-[#4A6B78] rounded-full flex items-center justify-center text-white font-bold text-sm">
                          {msg.from.split(' ').map(n => n[0]).join('')}
                        </div>
                        <div className="flex-1">
                          <div className="flex items-center gap-2 mb-1">
                            <h4 className="font-semibold text-gray-900">{msg.from}</h4>
                            {msg.unread && <span className="w-2 h-2 bg-blue-500 rounded-full"></span>}
                          </div>
                          <p className="text-sm text-gray-900 mb-1">{msg.subject}</p>
                          <p className="text-xs text-gray-500">{msg.date}</p>
                        </div>
                      </div>
                      <ChevronRight className="w-5 h-5 text-gray-400" />
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}
      </main>
    </div>
  );
}
