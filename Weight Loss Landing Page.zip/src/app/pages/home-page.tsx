import { Header } from "@/app/components/header";
import { HeroSection } from "@/app/components/hero-section";
import { TreatmentsSection } from "@/app/components/treatments-section";
import { WeightLossProgram } from "@/app/components/weight-loss-program";
import { HowItWorks } from "@/app/components/how-it-works";
import { MotabhaiMeaning } from "@/app/components/motabhai-meaning";
import { DrRajuSection } from "@/app/components/dr-raju-section";
import { TestimonialsSection } from "@/app/components/testimonials-section";
import { SocialVideoCarousel } from "@/app/components/social-video-carousel";
import { ProductsShowcase } from "@/app/components/products-showcase";
import { Footer } from "@/app/components/footer";

export function HomePage() {
  return (
    <div className="min-h-screen bg-white">
      <Header />
      <HeroSection />
      <MotabhaiMeaning />
      <TreatmentsSection />
      <WeightLossProgram />
      <HowItWorks />
      <DrRajuSection />
      <TestimonialsSection />
      <ProductsShowcase />
      <SocialVideoCarousel />
      <Footer />
    </div>
  );
}