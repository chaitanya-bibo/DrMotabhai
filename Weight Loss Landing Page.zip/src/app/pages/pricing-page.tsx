import { useState } from "react";
import { Check, Plus } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { Header } from "@/app/components/header";
import { Footer } from "@/app/components/footer";
import { useCart } from "@/app/contexts/cart-context";
import { toast } from "sonner";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/app/components/ui/dialog";
import { Button } from "@/app/components/ui/button";
import { Checkbox } from "@/app/components/ui/checkbox";

export function PricingPage() {
  const navigate = useNavigate();
  const { addItem } = useCart();
  const [selectedPlan, setSelectedPlan] = useState<any>(null);
  const [selectedAddons, setSelectedAddons] = useState<string[]>([]);
  const [showAddonsDialog, setShowAddonsDialog] = useState(false);

  const plans = [
    {
      id: "plan-essential",
      name: "Essential",
      price: 13000,
      displayPrice: "₹13,000",
      period: "per month",
      description: "Perfect for getting started with GLP-1 treatment",
      features: [
        "GLP-1 Medication (Semaglutide or Tirzepatide)",
        "Monthly Virtual Consultations",
        "Basic Progress Tracking",
        "Email Support",
        "Prescription Management",
        "Treatment Plan Overview"
      ],
      popular: false,
      canAddAddons: true
    },
    {
      id: "plan-complete",
      name: "Complete Care",
      price: 16000,
      displayPrice: "₹16,000",
      period: "per month",
      description: "Comprehensive support for optimal results",
      features: [
        "Everything in Essential",
        "Medical Coach - Weekly Check-ins",
        "Personalized Meal Planning",
        "Lab Work Monitoring",
        "Priority Support",
        "Mobile App Access",
        "Community Forum Access"
      ],
      popular: true,
      canAddAddons: true
    },
    {
      id: "plan-premium",
      name: "Premium Plus",
      price: 18000,
      displayPrice: "₹18,000",
      period: "per month",
      description: "Complete transformation with full support team",
      features: [
        "Everything in Complete Care",
        "Dedicated Medical Coach",
        "Certified Fitness Coach",
        "Registered Nutrition Coach",
        "CGM (Continuous Glucose Monitor)",
        "Bi-weekly Video Consultations",
        "24/7 Medical Support",
        "Custom Fitness Programs",
        "Advanced Body Composition Analysis"
      ],
      popular: false,
      canAddAddons: false
    }
  ];

  const addOns = [
    {
      id: "addon-medical-coach",
      name: "Medical Coach",
      price: 1200,
      displayPrice: "₹1,200/month",
      description: "Personal medical guidance and weekly progress reviews",
      benefits: [
        "Weekly progress check-ins",
        "Medication adjustment recommendations",
        "Side effect management",
        "Direct messaging access"
      ]
    },
    {
      id: "addon-fitness-coach",
      name: "Fitness Coach",
      price: 1400,
      displayPrice: "₹1,400/month",
      description: "Customized workout plans and accountability",
      benefits: [
        "Personalized training programs",
        "Video exercise demonstrations",
        "Weekly workout adjustments",
        "Form review and feedback"
      ]
    },
    {
      id: "addon-nutrition-coach",
      name: "Nutrition Coach",
      price: 1300,
      displayPrice: "₹1,300/month",
      description: "Expert meal planning and dietary guidance",
      benefits: [
        "Custom meal plans",
        "Macro tracking assistance",
        "Recipe recommendations",
        "Grocery shopping guides"
      ]
    },
    {
      id: "addon-cgm",
      name: "CGM Device",
      price: 3200,
      displayPrice: "₹3,200/month",
      description: "Real-time glucose monitoring technology",
      benefits: [
        "24/7 glucose tracking",
        "Trend analysis and insights",
        "Food response monitoring",
        "Mobile app integration"
      ]
    }
  ];

  const handleBuyPlan = (plan: any) => {
    if (plan.canAddAddons) {
      setSelectedPlan(plan);
      setSelectedAddons([]);
      setShowAddonsDialog(true);
    } else {
      // Premium Plus - add directly to cart
      addItem({
        id: plan.id,
        name: `${plan.name} - Monthly Plan`,
        price: plan.price,
        quantity: 1,
        type: 'plan',
        description: plan.description
      });
      toast.success(`${plan.name} plan added to cart!`);
    }
  };

  const handleAddToCart = () => {
    if (!selectedPlan) return;

    // Add the plan
    addItem({
      id: selectedPlan.id,
      name: `${selectedPlan.name} - Monthly Plan`,
      price: selectedPlan.price,
      quantity: 1,
      type: 'plan',
      description: selectedPlan.description
    });

    // Add selected add-ons
    selectedAddons.forEach(addonId => {
      const addon = addOns.find(a => a.id === addonId);
      if (addon) {
        addItem({
          id: addon.id,
          name: addon.name,
          price: addon.price,
          quantity: 1,
          type: 'addon',
          description: addon.description
        });
      }
    });

    toast.success(`${selectedPlan.name} plan${selectedAddons.length > 0 ? ' with add-ons' : ''} added to cart!`);
    setShowAddonsDialog(false);
    setSelectedPlan(null);
    setSelectedAddons([]);
  };

  const toggleAddon = (addonId: string) => {
    setSelectedAddons(prev =>
      prev.includes(addonId)
        ? prev.filter(id => id !== addonId)
        : [...prev, addonId]
    );
  };

  const getTotalPrice = () => {
    if (!selectedPlan) return 0;
    const addonsTotal = selectedAddons.reduce((sum, addonId) => {
      const addon = addOns.find(a => a.id === addonId);
      return sum + (addon?.price || 0);
    }, 0);
    return selectedPlan.price + addonsTotal;
  };

  const formatPrice = (price: number) => {
    return new Intl.NumberFormat('en-IN', {
      style: 'currency',
      currency: 'INR',
      maximumFractionDigits: 0,
    }).format(price);
  };

  return (
    <div className="min-h-screen bg-white">
      <Header />
      
      {/* Hero Section */}
      <section className="pt-32 pb-20 bg-gradient-to-b from-[#4A6B78]/10 to-white">
        <div className="container mx-auto px-4 lg:px-8 max-w-7xl">
          <div className="text-center mb-16">
            <h1 
              className="text-gray-900 mb-6"
              style={{ 
                fontFamily: 'Bebas Neue',
                fontSize: 'clamp(48px, 8vw, 72px)',
                lineHeight: '1',
                letterSpacing: '0.02em'
              }}
            >
              Treatment Plans & Pricing
            </h1>
            <p 
              className="text-gray-600 max-w-2xl mx-auto mb-4"
              style={{ 
                fontFamily: 'DM Sans',
                fontSize: '18px',
                lineHeight: '1.6'
              }}
            >
              Flexible pricing plans with comprehensive support options. All plans include medical-grade GLP-1 medication prescribed by Dr. Motabhai after consultation.
            </p>
            <p 
              className="text-[#4A6B78] max-w-2xl mx-auto text-sm font-semibold"
              style={{ 
                fontFamily: 'DM Sans',
                lineHeight: '1.6'
              }}
            >
              Note: Medication selection is determined by Dr. Motabhai based on your medical history, eligibility assessment, and consultation.
            </p>
          </div>

          {/* Pricing Cards */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-20">
            {plans.map((plan, index) => (
              <div
                key={index}
                className={`relative rounded-3xl p-8 ${
                  plan.popular
                    ? 'bg-[#4A6B78] text-white shadow-2xl scale-105'
                    : 'bg-white text-gray-900 border-2 border-gray-200'
                }`}
              >
                {plan.popular && (
                  <div className="absolute -top-4 left-1/2 transform -translate-x-1/2">
                    <span 
                      className="bg-[#E8BFB8] text-gray-900 px-6 py-2 rounded-full text-sm font-bold"
                      style={{ fontFamily: 'DM Sans' }}
                    >
                      MOST POPULAR
                    </span>
                  </div>
                )}
                
                <h3 
                  className="mb-2"
                  style={{ 
                    fontFamily: 'Bebas Neue',
                    fontSize: '32px',
                    letterSpacing: '0.02em'
                  }}
                >
                  {plan.name}
                </h3>
                
                <div className="mb-4">
                  <span 
                    className={plan.popular ? 'text-white' : 'text-[#4A6B78]'}
                    style={{ 
                      fontFamily: 'DM Sans',
                      fontSize: '48px',
                      fontWeight: '700'
                    }}
                  >
                    {plan.displayPrice}
                  </span>
                  <span 
                    className={`ml-2 ${plan.popular ? 'text-white/80' : 'text-gray-500'}`}
                    style={{ fontFamily: 'DM Sans', fontSize: '14px' }}
                  >
                    {plan.period}
                  </span>
                </div>
                
                <p 
                  className={`mb-8 ${plan.popular ? 'text-white/90' : 'text-gray-600'}`}
                  style={{ 
                    fontFamily: 'DM Sans',
                    fontSize: '14px',
                    lineHeight: '1.5'
                  }}
                >
                  {plan.description}
                </p>
                
                <ul className="space-y-4 mb-8">
                  {plan.features.map((feature, i) => (
                    <li key={i} className="flex items-start">
                      <Check 
                        className={`w-5 h-5 mr-3 flex-shrink-0 mt-0.5 ${
                          plan.popular ? 'text-[#E8BFB8]' : 'text-[#55675E]'
                        }`}
                      />
                      <span 
                        style={{ fontFamily: 'DM Sans', fontSize: '14px' }}
                      >
                        {feature}
                      </span>
                    </li>
                  ))}
                </ul>
                
                <div className="space-y-3">
                  <button 
                    onClick={() => navigate('/eligibility')}
                    className={`w-full py-4 rounded-lg font-bold transition-all ${
                      plan.popular
                        ? 'bg-white text-[#4A6B78] hover:bg-gray-100'
                        : 'bg-[#4A6B78] text-white hover:bg-[#3E5147]'
                    }`}
                    style={{ fontFamily: 'DM Sans', fontSize: '16px' }}
                  >
                    Book Consultation
                  </button>
                  
                  <button 
                    onClick={() => handleBuyPlan(plan)}
                    className={`w-full py-4 rounded-lg font-bold transition-all border-2 ${
                      plan.popular
                        ? 'border-white/50 text-white hover:bg-white/10'
                        : 'border-[#4A6B78] text-[#4A6B78] hover:bg-[#4A6B78]/5'
                    }`}
                    style={{ fontFamily: 'DM Sans', fontSize: '16px' }}
                  >
                    Buy Plan
                  </button>
                </div>
              </div>
            ))}
          </div>

          {/* Add-On Services */}
          <div className="mt-20">
            <h2 
              className="text-center text-gray-900 mb-4"
              style={{ 
                fontFamily: 'Bebas Neue',
                fontSize: 'clamp(36px, 6vw, 56px)',
                letterSpacing: '0.02em'
              }}
            >
              Enhance Your Program
            </h2>
            <p 
              className="text-center text-gray-600 mb-12 max-w-2xl mx-auto"
              style={{ 
                fontFamily: 'DM Sans',
                fontSize: '16px',
                lineHeight: '1.6'
              }}
            >
              Boost your results with our specialized add-on services. Available with Essential and Complete Care plans.
            </p>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              {addOns.map((addon, index) => (
                <div
                  key={index}
                  className="bg-white border-2 border-gray-200 rounded-2xl p-8 hover:border-[#4A6B78] transition-all"
                >
                  <div className="flex justify-between items-start mb-4">
                    <h3 
                      className="text-gray-900"
                      style={{ 
                        fontFamily: 'Bebas Neue',
                        fontSize: '28px',
                        letterSpacing: '0.02em'
                      }}
                    >
                      {addon.name}
                    </h3>
                    <span 
                      className="text-[#4A6B78] font-bold"
                      style={{ 
                        fontFamily: 'DM Sans',
                        fontSize: '20px'
                      }}
                    >
                      {addon.displayPrice}
                    </span>
                  </div>
                  
                  <p 
                    className="text-gray-600 mb-6"
                    style={{ 
                      fontFamily: 'DM Sans',
                      fontSize: '14px',
                      lineHeight: '1.5'
                    }}
                  >
                    {addon.description}
                  </p>
                  
                  <ul className="space-y-3">
                    {addon.benefits.map((benefit, i) => (
                      <li key={i} className="flex items-start">
                        <Check className="w-4 h-4 text-[#55675E] mr-2 flex-shrink-0 mt-1" />
                        <span 
                          className="text-gray-700"
                          style={{ fontFamily: 'DM Sans', fontSize: '13px' }}
                        >
                          {benefit}
                        </span>
                      </li>
                    ))}
                  </ul>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Add-ons Dialog */}
      <Dialog open={showAddonsDialog} onOpenChange={setShowAddonsDialog}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle style={{ fontFamily: 'Bebas Neue', fontSize: '32px', letterSpacing: '0.02em' }}>
              Customize Your {selectedPlan?.name} Plan
            </DialogTitle>
            <DialogDescription style={{ fontFamily: 'DM Sans', fontSize: '14px' }}>
              Select add-on services to enhance your weight loss journey
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-4 my-6">
            {addOns.map((addon) => (
              <div
                key={addon.id}
                className={`border-2 rounded-xl p-4 cursor-pointer transition-all ${
                  selectedAddons.includes(addon.id)
                    ? 'border-[#4A6B78] bg-[#4A6B78]/5'
                    : 'border-gray-200 hover:border-gray-300'
                }`}
                onClick={() => toggleAddon(addon.id)}
              >
                <div className="flex items-start gap-4">
                  <Checkbox
                    checked={selectedAddons.includes(addon.id)}
                    onCheckedChange={() => toggleAddon(addon.id)}
                    className="mt-1"
                  />
                  <div className="flex-1">
                    <div className="flex justify-between items-start mb-2">
                      <h4 className="font-semibold text-gray-900" style={{ fontFamily: 'DM Sans', fontSize: '16px' }}>
                        {addon.name}
                      </h4>
                      <span className="text-[#4A6B78] font-bold" style={{ fontFamily: 'DM Sans', fontSize: '16px' }}>
                        {addon.displayPrice}
                      </span>
                    </div>
                    <p className="text-gray-600 text-sm mb-3" style={{ fontFamily: 'DM Sans' }}>
                      {addon.description}
                    </p>
                    <ul className="space-y-1">
                      {addon.benefits.map((benefit, i) => (
                        <li key={i} className="flex items-start">
                          <Check className="w-3 h-3 text-[#55675E] mr-2 flex-shrink-0 mt-1" />
                          <span className="text-gray-600 text-xs" style={{ fontFamily: 'DM Sans' }}>
                            {benefit}
                          </span>
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>
              </div>
            ))}
          </div>

          <div className="border-t pt-4">
            <div className="flex justify-between items-center mb-4">
              <span className="text-gray-600 font-medium" style={{ fontFamily: 'DM Sans', fontSize: '16px' }}>
                Total Monthly Cost
              </span>
              <span className="text-2xl font-bold text-[#4A6B78]" style={{ fontFamily: 'DM Sans' }}>
                {formatPrice(getTotalPrice())}
              </span>
            </div>
            <div className="flex gap-3">
              <Button
                variant="outline"
                onClick={() => {
                  setShowAddonsDialog(false);
                  setSelectedPlan(null);
                  setSelectedAddons([]);
                }}
                className="flex-1"
                style={{ fontFamily: 'DM Sans' }}
              >
                Cancel
              </Button>
              <Button
                onClick={handleAddToCart}
                className="flex-1 bg-[#4A6B78] text-white hover:bg-[#3E5147]"
                style={{ fontFamily: 'DM Sans' }}
              >
                Add to Cart
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      <Footer />
    </div>
  );
}
