import { useState } from "react";
import { ChevronDown, ChevronUp } from "lucide-react";
import { Header } from "@/app/components/header";
import { Footer } from "@/app/components/footer";

export function TreatmentsPage() {
  const [expandedTreatment, setExpandedTreatment] = useState<number | null>(0);

  const treatments = [
    {
      name: "Semaglutide (Ozempic / Wegovy)",
      dosage: "0.25mg - 2.4mg weekly",
      mechanism: "GLP-1 Receptor Agonist",
      description: "Semaglutide is a once-weekly injectable medication that mimics the GLP-1 hormone naturally produced in your body. It works by regulating appetite, slowing gastric emptying, and improving blood sugar control.",
      benefits: [
        "Average 12-15% body weight reduction",
        "Once-weekly injection",
        "FDA-approved for weight management",
        "Improved cardiovascular health",
        "Better blood sugar control",
        "Reduced food cravings"
      ],
      sideEffects: [
        "Nausea (usually temporary)",
        "Diarrhea or constipation",
        "Fatigue",
        "Headache",
        "Decreased appetite"
      ],
      ideal: "Best for patients looking for once-weekly dosing with proven long-term results. Ideal for those with BMI ≥30 or ≥27 with weight-related conditions."
    },
    {
      name: "Tirzepatide (Mounjaro / Zepbound)",
      dosage: "2.5mg - 15mg weekly",
      mechanism: "Dual GLP-1/GIP Receptor Agonist",
      description: "Tirzepatide is a groundbreaking medication that activates both GLP-1 and GIP receptors, providing enhanced weight loss results compared to GLP-1 medications alone.",
      benefits: [
        "Average 15-22% body weight reduction",
        "Dual-action mechanism",
        "Once-weekly injection",
        "Superior weight loss vs. semaglutide",
        "Improved metabolic health",
        "Reduced cardiovascular risk"
      ],
      sideEffects: [
        "Nausea (usually temporary)",
        "Diarrhea",
        "Decreased appetite",
        "Vomiting (less common)",
        "Constipation",
        "Injection site reactions"
      ],
      ideal: "Best for patients seeking maximum weight loss results. Ideal for those who haven't achieved goals with other GLP-1 medications or prefer a more potent option."
    },
    {
      name: "Compounded Semaglutide",
      dosage: "Custom dosing available",
      mechanism: "GLP-1 Receptor Agonist",
      description: "Compounded semaglutide offers the same active ingredient as brand-name versions but at a more affordable price point. Made by licensed US compounding pharmacies under strict quality control.",
      benefits: [
        "Same active ingredient as Ozempic/Wegovy",
        "Cost-effective option",
        "Flexible dosing options",
        "No insurance required",
        "12-15% average weight loss",
        "Custom strength availability"
      ],
      sideEffects: [
        "Nausea (usually temporary)",
        "GI discomfort",
        "Decreased appetite",
        "Fatigue",
        "Potential headaches"
      ],
      ideal: "Best for cost-conscious patients without insurance coverage. Ideal for those seeking proven GLP-1 benefits at an accessible price point."
    },
    {
      name: "Orlistat (Alli / Xenical)",
      dosage: "60mg - 120mg three times daily",
      mechanism: "Lipase Inhibitor",
      description: "Orlistat is an oral medication that works by blocking the absorption of about 25% of dietary fat. Unlike GLP-1 medications, it acts in the digestive system rather than affecting appetite hormones.",
      benefits: [
        "Average 5-10% body weight reduction",
        "Oral medication - no injections",
        "Available over-the-counter (60mg)",
        "Reduces fat absorption",
        "Can lower cholesterol",
        "Works independently of appetite"
      ],
      sideEffects: [
        "Oily stools and gas",
        "Frequent bowel movements",
        "Abdominal cramping",
        "Vitamin deficiency (fat-soluble vitamins)",
        "Fecal urgency or incontinence"
      ],
      ideal: "Best for patients who prefer oral medication or cannot use injections. Ideal for those with modest weight loss goals or as an alternative to GLP-1 therapy."
    }
  ];

  return (
    <div className="min-h-screen bg-white">
      <Header />
      
      {/* Hero Section */}
      <section className="pt-32 pb-20 bg-gradient-to-b from-[#55675E]/10 to-white">
        <div className="container mx-auto px-4 lg:px-8 max-w-7xl">
          <div className="text-center mb-16">
            <h1 
              className="text-gray-900 mb-6"
              style={{ 
                fontFamily: 'Bebas Neue',
                fontSize: 'clamp(48px, 8vw, 72px)',
                lineHeight: '1',
                letterSpacing: '0.02em'
              }}
            >
              Weight Loss Treatment Options
            </h1>
            <p 
              className="text-gray-600 max-w-2xl mx-auto mb-4"
              style={{ 
                fontFamily: 'DM Sans',
                fontSize: '18px',
                lineHeight: '1.6'
              }}
            >
              Explore our range of FDA-approved GLP-1 medications and oral weight loss treatments. Dr. Motabhai will prescribe the right treatment for your unique goals after your eligibility assessment and consultation.
            </p>
            <p 
              className="text-[#4A6B78] max-w-2xl mx-auto text-sm font-semibold"
              style={{ 
                fontFamily: 'DM Sans',
                lineHeight: '1.6'
              }}
            >
              All medications are prescribed by Dr. Motabhai based on your medical history and consultation. You may express interest in specific treatments.
            </p>
          </div>

          {/* Treatment Comparison */}
          <div className="space-y-6">
            {treatments.map((treatment, index) => (
              <div
                key={index}
                className="bg-white rounded-2xl border-2 border-gray-200 overflow-hidden hover:border-[#4A6B78] transition-all"
              >
                <button
                  onClick={() => setExpandedTreatment(expandedTreatment === index ? null : index)}
                  className="w-full p-8 text-left flex justify-between items-center"
                >
                  <div className="flex-1">
                    <h2 
                      className="text-gray-900 mb-2"
                      style={{ 
                        fontFamily: 'Bebas Neue',
                        fontSize: 'clamp(28px, 4vw, 36px)',
                        letterSpacing: '0.02em'
                      }}
                    >
                      {treatment.name}
                    </h2>
                    <div className="flex gap-4 flex-wrap">
                      <span 
                        className="text-[#4A6B78] text-sm font-semibold"
                        style={{ fontFamily: 'DM Sans' }}
                      >
                        {treatment.mechanism}
                      </span>
                      <span 
                        className="text-gray-500 text-sm"
                        style={{ fontFamily: 'DM Sans' }}
                      >
                        {treatment.dosage}
                      </span>
                    </div>
                  </div>
                  {expandedTreatment === index ? (
                    <ChevronUp className="w-6 h-6 text-[#4A6B78]" />
                  ) : (
                    <ChevronDown className="w-6 h-6 text-[#4A6B78]" />
                  )}
                </button>

                {expandedTreatment === index && (
                  <div className="px-8 pb-8 space-y-6 border-t border-gray-100">
                    <p 
                      className="text-gray-700 pt-6"
                      style={{ 
                        fontFamily: 'DM Sans',
                        fontSize: '15px',
                        lineHeight: '1.6'
                      }}
                    >
                      {treatment.description}
                    </p>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <div className="bg-[#55675E]/5 rounded-xl p-6">
                        <h3 
                          className="text-gray-900 mb-4"
                          style={{ 
                            fontFamily: 'Bebas Neue',
                            fontSize: '24px',
                            letterSpacing: '0.02em'
                          }}
                        >
                          Key Benefits
                        </h3>
                        <ul className="space-y-2">
                          {treatment.benefits.map((benefit, i) => (
                            <li 
                              key={i}
                              className="text-gray-700 flex items-start"
                              style={{ fontFamily: 'DM Sans', fontSize: '14px' }}
                            >
                              <span className="text-[#55675E] mr-2">•</span>
                              {benefit}
                            </li>
                          ))}
                        </ul>
                      </div>

                      <div className="bg-gray-50 rounded-xl p-6">
                        <h3 
                          className="text-gray-900 mb-4"
                          style={{ 
                            fontFamily: 'Bebas Neue',
                            fontSize: '24px',
                            letterSpacing: '0.02em'
                          }}
                        >
                          Possible Side Effects
                        </h3>
                        <ul className="space-y-2">
                          {treatment.sideEffects.map((effect, i) => (
                            <li 
                              key={i}
                              className="text-gray-600 flex items-start"
                              style={{ fontFamily: 'DM Sans', fontSize: '14px' }}
                            >
                              <span className="text-gray-400 mr-2">•</span>
                              {effect}
                            </li>
                          ))}
                        </ul>
                      </div>
                    </div>

                    <div className="bg-[#E8BFB8]/20 rounded-xl p-6">
                      <h3 
                        className="text-gray-900 mb-2"
                        style={{ 
                          fontFamily: 'Bebas Neue',
                          fontSize: '20px',
                          letterSpacing: '0.02em'
                        }}
                      >
                        Ideal For
                      </h3>
                      <p 
                        className="text-gray-700"
                        style={{ 
                          fontFamily: 'DM Sans',
                          fontSize: '14px',
                          lineHeight: '1.6'
                        }}
                      >
                        {treatment.ideal}
                      </p>
                    </div>

                    <button 
                      className="w-full py-4 bg-[#4A6B78] text-white rounded-lg font-bold hover:bg-[#3E5147] transition-all"
                      style={{ fontFamily: 'DM Sans', fontSize: '16px' }}
                      onClick={() => window.location.href = '/eligibility'}
                    >
                      Check Eligibility
                    </button>
                  </div>
                )}
              </div>
            ))}
          </div>

          {/* How GLP-1 Works */}
          <div className="mt-20 bg-gray-50 rounded-3xl p-12">
            <h2 
              className="text-center text-gray-900 mb-12"
              style={{ 
                fontFamily: 'Bebas Neue',
                fontSize: 'clamp(36px, 6vw, 48px)',
                letterSpacing: '0.02em'
              }}
            >
              How GLP-1 Medications Work
            </h2>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-5xl mx-auto">
              {[
                {
                  title: "Appetite Regulation",
                  description: "GLP-1 signals your brain to reduce hunger and increase feelings of fullness, helping you eat less naturally without feeling deprived."
                },
                {
                  title: "Slower Digestion",
                  description: "By slowing gastric emptying, food stays in your stomach longer, leading to prolonged satiety and better portion control."
                },
                {
                  title: "Blood Sugar Control",
                  description: "Improves insulin secretion and reduces glucagon, leading to better blood sugar management and reduced cravings."
                }
              ].map((item, i) => (
                <div key={i} className="bg-white rounded-xl p-6">
                  <h3 
                    className="text-[#4A6B78] mb-3"
                    style={{ 
                      fontFamily: 'Bebas Neue',
                      fontSize: '24px',
                      letterSpacing: '0.02em'
                    }}
                  >
                    {item.title}
                  </h3>
                  <p 
                    className="text-gray-600"
                    style={{ 
                      fontFamily: 'DM Sans',
                      fontSize: '14px',
                      lineHeight: '1.6'
                    }}
                  >
                    {item.description}
                  </p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>
      
      <Footer />
    </div>
  );
}