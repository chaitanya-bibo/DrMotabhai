import { useState } from "react";
import { ChevronDown, ChevronUp } from "lucide-react";
import { Link } from "react-router";
import { Header } from "@/app/components/header";
import { Footer } from "@/app/components/footer";

export function FAQPage() {
  const [expandedIndex, setExpandedIndex] = useState<number | null>(null);

  const faqs = [
    {
      category: "Getting Started",
      questions: [
        {
          q: "How do I start GLP-1 treatment with Dr. Motabhai?",
          a: "Simply schedule a free consultation through our website. Dr. Motabhai will review your medical history, discuss your weight loss goals, and determine if GLP-1 treatment is right for you. The process typically takes 15-20 minutes and can be done entirely online."
        },
        {
          q: "What is required for my first consultation?",
          a: "You'll need to provide basic health information including your current medications, medical history, and weight loss goals. We may also request recent lab work if available. The consultation is comprehensive but straightforward."
        },
        {
          q: "How quickly can I start treatment?",
          a: "If approved, most patients receive their first shipment within 5-7 business days. We'll coordinate with our partner pharmacies to ensure prompt delivery of your medication."
        }
      ]
    },
    {
      category: "Treatment & Medications",
      questions: [
        {
          q: "What's the difference between Semaglutide and Tirzepatide?",
          a: "Semaglutide (Ozempic/Wegovy) is a GLP-1 receptor agonist that typically results in 12-15% body weight reduction. Tirzepatide (Mounjaro/Zepbound) is a dual GLP-1/GIP receptor agonist with enhanced efficacy, typically resulting in 15-22% weight reduction. Dr. Motabhai will help determine which is best for your goals."
        },
        {
          q: "How are the injections administered?",
          a: "GLP-1 medications are self-administered via a small, pre-filled pen injector once weekly. The needles are very thin and most patients report minimal discomfort. We provide detailed instructions and video tutorials."
        },
        {
          q: "What if I experience side effects?",
          a: "Common side effects like nausea typically subside within 2-4 weeks. Dr. Motabhai and our medical team are available 24/7 to address any concerns and can adjust your dosage if needed."
        },
        {
          q: "Can I stop treatment anytime?",
          a: "Yes, you can discontinue treatment at any time. However, we recommend doing so under medical supervision to maintain your results. Many patients choose to continue at a maintenance dose."
        }
      ]
    },
    {
      category: "Results & Expectations",
      questions: [
        {
          q: "How much weight can I expect to lose?",
          a: "On average, patients lose 12-15% of their body weight with Semaglutide and 15-22% with Tirzepatide over 12-16 months. Results vary based on individual factors, adherence to treatment, and lifestyle modifications."
        },
        {
          q: "When will I see results?",
          a: "Most patients notice reduced appetite within the first week. Visible weight loss typically begins in weeks 2-4, with steady progress throughout treatment. Peak results are usually achieved around months 12-16."
        },
        {
          q: "Do I need to diet and exercise?",
          a: "While GLP-1 medications reduce appetite naturally, combining treatment with healthy eating and regular physical activity enhances results. Our coaching services can help you develop sustainable habits."
        }
      ]
    },
    {
      category: "Costs & Insurance",
      questions: [
        {
          q: "How much does treatment cost?",
          a: "Our plans range from $297-$797 per month depending on the medication and support level you choose. All plans include medication, medical supervision, and ongoing support."
        },
        {
          q: "Do you accept insurance?",
          a: "We don't directly bill insurance, but many patients successfully submit for reimbursement. We provide detailed receipts for this purpose. HSA/FSA cards are accepted."
        },
        {
          q: "Are there any hidden fees?",
          a: "No. All costs are transparent and included in your monthly plan. Occasional lab work may be additional but is discussed upfront."
        },
        {
          q: "Can I change my plan?",
          a: "Yes! You can upgrade or downgrade your plan at any time. Changes take effect at the start of your next billing cycle."
        }
      ]
    },
    {
      category: "Coaching & Support",
      questions: [
        {
          q: "What does the Medical Coach do?",
          a: "Your Medical Coach provides weekly check-ins, monitors your progress, helps manage side effects, and coordinates with Dr. Motabhai for medication adjustments. They're your primary point of contact throughout treatment."
        },
        {
          q: "How does the Fitness Coach help?",
          a: "Our Fitness Coaches create personalized workout programs based on your current fitness level and goals. They provide video demonstrations, track your progress, and adjust programs as you advance."
        },
        {
          q: "What's included with the Nutrition Coach?",
          a: "Nutrition Coaches develop customized meal plans, provide recipe ideas, help with macro tracking, and teach sustainable eating habits that complement your GLP-1 treatment."
        },
        {
          q: "What is CGM and how does it help?",
          a: "A Continuous Glucose Monitor is a small device that tracks your blood sugar 24/7. It helps you understand how different foods affect you, optimize meal timing, and make data-driven decisions about your diet."
        }
      ]
    },
    {
      category: "Safety & Medical",
      questions: [
        {
          q: "Are GLP-1 medications safe?",
          a: "Yes, GLP-1 medications are FDA-approved and have been used safely for years. They're prescribed under medical supervision with regular monitoring to ensure safety and efficacy."
        },
        {
          q: "Who should not take GLP-1 medications?",
          a: "GLP-1 medications are not recommended for pregnant or breastfeeding women, individuals with a history of medullary thyroid cancer or Multiple Endocrine Neoplasia syndrome type 2, or those with severe gastrointestinal disease."
        },
        {
          q: "How often do I need to see Dr. Motabhai?",
          a: "Initial consultation is followed by check-ins at 1 month, 3 months, and then quarterly. Additional consultations are available anytime you have questions or concerns."
        },
        {
          q: "What happens if I miss a dose?",
          a: "If you miss a dose within 5 days of your scheduled day, take it as soon as you remember. If it's been more than 5 days, skip the missed dose and resume your regular schedule. Never double dose."
        }
      ]
    },
    {
      category: "Healthcare Portals",
      questions: [
        {
          q: "How do I access the Patient Portal?",
          a: "Our Patient EMR portal allows you to view your medical records, track vitals, manage appointments, and monitor your treatment progress. Click here to access: "
        },
        {
          q: "What is the Doctor Dashboard?",
          a: "The Doctor Dashboard is a comprehensive physician management system where doctors can conduct consultations, manage prescriptions, create treatment plans, and monitor patient progress. Healthcare providers can access it at /dashboard/doctor"
        },
        {
          q: "What is the Manager Dashboard?",
          a: "The Manager Dashboard is a unified operations portal that consolidates administrative functions including user management, patient care coordination, billing, inventory control, and vendor management into one comprehensive system."
        }
      ]
    }
  ];

  return (
    <div className="min-h-screen bg-white">
      <Header />
      
      <section className="pt-32 pb-20">
        <div className="container mx-auto px-4 lg:px-8 max-w-4xl">
          <div className="text-center mb-16">
            <h1 
              className="text-gray-900 mb-6"
              style={{ 
                fontFamily: 'Bebas Neue',
                fontSize: 'clamp(48px, 8vw, 72px)',
                lineHeight: '1',
                letterSpacing: '0.02em'
              }}
            >
              Frequently Asked Questions
            </h1>
            <p 
              className="text-gray-600 max-w-2xl mx-auto"
              style={{ 
                fontFamily: 'DM Sans',
                fontSize: '18px',
                lineHeight: '1.6'
              }}
            >
              Find answers to common questions about GLP-1 treatment, our services, and what to expect.
            </p>
          </div>

          {faqs.map((category, catIndex) => (
            <div key={catIndex} className="mb-12">
              <h2 
                className="text-[#4A6B78] mb-6"
                style={{ 
                  fontFamily: 'Bebas Neue',
                  fontSize: '32px',
                  letterSpacing: '0.02em'
                }}
              >
                {category.category}
              </h2>
              
              <div className="space-y-4">
                {category.questions.map((faq, qIndex) => {
                  const globalIndex = catIndex * 100 + qIndex;
                  const isExpanded = expandedIndex === globalIndex;
                  
                  return (
                    <div
                      key={qIndex}
                      className="bg-white border-2 border-gray-200 rounded-xl overflow-hidden hover:border-[#4A6B78]/50 transition-all"
                    >
                      <button
                        onClick={() => setExpandedIndex(isExpanded ? null : globalIndex)}
                        className="w-full p-6 text-left flex justify-between items-start gap-4"
                      >
                        <h3 
                          className="text-gray-900 pr-4"
                          style={{ 
                            fontFamily: 'DM Sans',
                            fontSize: '16px',
                            fontWeight: '600',
                            lineHeight: '1.4'
                          }}
                        >
                          {faq.q}
                        </h3>
                        {isExpanded ? (
                          <ChevronUp className="w-5 h-5 text-[#4A6B78] flex-shrink-0" />
                        ) : (
                          <ChevronDown className="w-5 h-5 text-gray-400 flex-shrink-0" />
                        )}
                      </button>
                      
                      {isExpanded && (
                        <div className="px-6 pb-6 border-t border-gray-100">
                          <p 
                            className="text-gray-600 pt-4"
                            style={{ 
                              fontFamily: 'DM Sans',
                              fontSize: '15px',
                              lineHeight: '1.6'
                            }}
                          >
                            {faq.a}
                          </p>
                          
                          {/* Special handling for portal links */}
                          {category.category === "Healthcare Portals" && (
                            <div className="mt-4 flex flex-wrap gap-2">
                              {qIndex === 0 && (
                                <Link 
                                  to="/dashboard/patient"
                                  className="px-4 py-2 bg-blue-500 text-white rounded-lg hover:bg-blue-600 transition-colors text-sm font-semibold"
                                >
                                  Access Patient Portal →
                                </Link>
                              )}
                              {qIndex === 1 && (
                                <Link 
                                  to="/dashboard/doctor"
                                  className="px-4 py-2 bg-purple-500 text-white rounded-lg hover:bg-purple-600 transition-colors text-sm font-semibold"
                                >
                                  Access Doctor Dashboard →
                                </Link>
                              )}
                              {qIndex === 2 && (
                                <Link 
                                  to="/dashboard/manager"
                                  className="px-4 py-2 bg-green-500 text-white rounded-lg hover:bg-green-600 transition-colors text-sm font-semibold"
                                >
                                  Access Manager Dashboard →
                                </Link>
                              )}
                            </div>
                          )}
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            </div>
          ))}

          {/* CTA Section */}
          <div className="mt-16 bg-gradient-to-r from-[#4A6B78] to-[#55675E] rounded-3xl p-12 text-center text-white">
            <h2 
              className="mb-4"
              style={{ 
                fontFamily: 'Bebas Neue',
                fontSize: 'clamp(32px, 5vw, 48px)',
                letterSpacing: '0.02em'
              }}
            >
              Still Have Questions?
            </h2>
            <p 
              className="mb-8 max-w-2xl mx-auto"
              style={{ 
                fontFamily: 'DM Sans',
                fontSize: '16px',
                lineHeight: '1.6'
              }}
            >
              Our team is here to help. Schedule a free consultation with Dr. Motabhai to get personalized answers.
            </p>
            <button 
              className="px-8 py-4 bg-white text-[#4A6B78] rounded-lg font-bold hover:bg-gray-100 transition-all"
              style={{ fontFamily: 'DM Sans', fontSize: '16px' }}
            >
              Schedule Free Consultation
            </button>
          </div>
        </div>
      </section>
      
      <Footer />
    </div>
  );
}