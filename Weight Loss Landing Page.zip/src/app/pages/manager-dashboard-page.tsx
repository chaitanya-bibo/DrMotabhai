import { useState } from "react";
import { Activity, AlertTriangle, Bell, Box, Calendar, CheckCircle, Clock, DollarSign, Download, FileText, Filter, MessageSquare, Package, Pill, Search, Settings, ShoppingCart, TrendingUp, Truck, Users, UserPlus, BarChart3 } from "lucide-react";

export function ManagerDashboardPage() {
  const [activeTab, setActiveTab] = useState("overview");

  // Combined Stats
  const overviewStats = {
    totalPatients: 124,
    activePatients: 98,
    todayAppointments: 12,
    pendingVitals: 5,
    activeAlerts: 3,
    totalStaff: 12,
    totalDoctors: 5,
    monthlyRevenue: "₹52,45,000",
    pendingPayments: "₹8,75,000",
    newEnrollments: 18,
    pendingOrders: 8,
    totalOrders: 45,
    vendorRevenue: "₹18,45,000"
  };

  // User Management Data (Admin)
  const recentUsers = [
    { name: "Priya Sharma", type: "Patient", email: "priya.s@email.com", joinDate: "Jan 29, 2024", status: "Active" },
    { name: "Dr. Anita Desai", type: "Doctor", email: "anita.d@motabhai.com", joinDate: "Jan 25, 2024", status: "Active" },
    { name: "Raj Patel", type: "Patient", email: "raj.p@email.com", joinDate: "Jan 28, 2024", status: "Active" },
    { name: "Nurse Maya Kumar", type: "Staff", email: "maya.k@motabhai.com", joinDate: "Jan 20, 2024", status: "Active" }
  ];

  // Patient Care Data (Nurse)
  const patients = [
    { id: "MRN-0123", name: "Priya Sharma", age: 42, program: "Complete Care", lastVisit: "Jan 29", nextVisit: "Feb 05", status: "Active", priority: "Normal", vitals: "Due Today" },
    { id: "MRN-0124", name: "Raj Patel", age: 38, program: "Essential", lastVisit: "Jan 28", nextVisit: "Feb 06", status: "Active", priority: "High", vitals: "Overdue" },
    { id: "MRN-0125", name: "Anjali Verma", age: 35, program: "Premium Plus", lastVisit: "Jan 27", nextVisit: "Feb 04", status: "Active", priority: "Normal", vitals: "Completed" },
    { id: "MRN-0126", name: "Vikram Singh", age: 45, program: "Complete Care", lastVisit: "Jan 26", nextVisit: "Feb 07", status: "Active", priority: "Normal", vitals: "Due Today" }
  ];

  const vitalsQueue = [
    { patient: "Priya Sharma", mrn: "MRN-0123", scheduled: "10:00 AM", type: "Weekly Check-in", status: "Pending" },
    { patient: "Vikram Singh", mrn: "MRN-0126", scheduled: "11:30 AM", type: "Weight & BP", status: "Pending" },
    { patient: "Raj Patel", mrn: "MRN-0124", scheduled: "2:00 PM", type: "Follow-up Vitals", status: "Overdue" }
  ];

  const medications = [
    { patient: "Priya Sharma", mrn: "MRN-0123", medication: "Semaglutide 1.0mg", time: "9:00 AM", status: "Administered", administeredBy: "Nurse Sarah" },
    { patient: "Anjali Verma", mrn: "MRN-0125", medication: "Semaglutide 1.0mg", time: "10:00 AM", status: "Pending", administeredBy: "-" },
    { patient: "Vikram Singh", mrn: "MRN-0126", medication: "Semaglutide 0.5mg", time: "11:00 AM", status: "Scheduled", administeredBy: "-" }
  ];

  const alerts = [
    { patient: "Raj Patel", mrn: "MRN-0124", message: "Blood pressure elevated: 142/90", priority: "High", time: "30 min ago" },
    { patient: "Anjali Verma", mrn: "MRN-0125", message: "Reported nausea - requires follow-up", priority: "Medium", time: "2 hours ago" },
    { patient: "Priya Sharma", mrn: "MRN-0123", message: "Lab results available for review", priority: "Low", time: "4 hours ago" }
  ];

  // Schedule Data (Nurse)
  const appointments = [
    { time: "10:00 AM", patient: "Priya Sharma", type: "Weekly Check-in", status: "In Progress" },
    { time: "11:30 AM", patient: "Vikram Singh", type: "Vitals Assessment", status: "Scheduled" },
    { time: "2:00 PM", patient: "Raj Patel", type: "Follow-up", status: "Scheduled" },
    { time: "3:30 PM", patient: "Anjali Verma", type: "Medication Review", status: "Scheduled" }
  ];

  // Billing Data (Admin)
  const billingOverview = [
    { patient: "Priya Sharma", mrn: "MRN-0123", plan: "Complete Care", amount: "₹41,700", dueDate: "Feb 15, 2024", status: "Paid" },
    { patient: "Raj Patel", mrn: "MRN-0124", plan: "Essential", amount: "₹24,900", dueDate: "Feb 10, 2024", status: "Pending" },
    { patient: "Anjali Verma", mrn: "MRN-0125", plan: "Premium Plus", amount: "₹66,900", dueDate: "Feb 20, 2024", status: "Paid" },
    { patient: "Vikram Singh", mrn: "MRN-0126", plan: "Complete Care", amount: "₹41,700", dueDate: "Feb 01, 2024", status: "Overdue" }
  ];

  // Inventory Data (Admin + Vendor)
  const inventoryStatus = [
    { item: "Semaglutide 1.0mg", stock: "45 units", status: "In Stock", reorderLevel: "20 units", supplier: "PharmaCorp India", servicePartner: "MedEx Logistics", location: "Mumbai, Maharashtra", pincode: "400001" },
    { item: "Semaglutide 0.5mg", stock: "12 units", status: "Low Stock", reorderLevel: "20 units", supplier: "PharmaCorp India", servicePartner: "MedEx Logistics", location: "Mumbai, Maharashtra", pincode: "400001" },
    { item: "Mounjaro 2.5mg", stock: "28 units", status: "In Stock", reorderLevel: "15 units", supplier: "MedSupply Ltd", servicePartner: "HealthCare Delivery", location: "Delhi, Delhi", pincode: "110001" },
    { item: "Blood Glucose Monitors", stock: "8 units", status: "Critical", reorderLevel: "10 units", supplier: "MedTech Solutions", servicePartner: "QuickShip Medical", location: "Bangalore, Karnataka", pincode: "560001" }
  ];

  // Vendor Management Data
  const vendorOrders = [
    { orderId: "ORD-2024-0156", vendor: "PharmaCorp India", item: "Semaglutide 1.0mg", quantity: "30 units", orderDate: "Jan 28, 2024", deliveryDate: "Feb 02, 2024", amount: "₹2,45,000", status: "Processing" },
    { orderId: "ORD-2024-0157", vendor: "MedTech Solutions", item: "Blood Glucose Monitors", quantity: "15 units", orderDate: "Jan 29, 2024", deliveryDate: "Feb 03, 2024", amount: "₹75,000", status: "Pending" },
    { orderId: "ORD-2024-0158", vendor: "PharmaCorp India", item: "Semaglutide 0.5mg", quantity: "20 units", orderDate: "Jan 29, 2024", deliveryDate: "Feb 05, 2024", amount: "₹1,60,000", status: "Pending" }
  ];

  const recentDeliveries = [
    { orderId: "ORD-2024-0153", vendor: "MedSupply Ltd", item: "Mounjaro 2.5mg", quantity: "25 units", deliveryDate: "Jan 27, 2024", amount: "₹3,15,000", status: "Delivered" },
    { orderId: "ORD-2024-0152", vendor: "PharmaCorp India", item: "Vitamin B12 1000mcg", quantity: "100 units", deliveryDate: "Jan 25, 2024", amount: "₹45,000", status: "Delivered" },
    { orderId: "ORD-2024-0151", vendor: "PharmaCorp India", item: "Semaglutide 1.0mg", quantity: "40 units", deliveryDate: "Jan 22, 2024", amount: "₹3,25,000", status: "Delivered" }
  ];

  const vendorInvoices = [
    { invoiceId: "INV-2024-0089", vendor: "MedSupply Ltd", amount: "₹3,15,000", issueDate: "Jan 27, 2024", dueDate: "Feb 26, 2024", status: "Sent" },
    { invoiceId: "INV-2024-0088", vendor: "PharmaCorp India", amount: "₹45,000", issueDate: "Jan 25, 2024", dueDate: "Feb 24, 2024", status: "Paid" },
    { invoiceId: "INV-2024-0087", vendor: "PharmaCorp India", amount: "₹3,25,000", issueDate: "Jan 22, 2024", dueDate: "Feb 21, 2024", status: "Paid" }
  ];

  // System Activity
  const systemActivity = [
    { user: "Dr. Rajesh Kumar", action: "Created prescription for MRN-0123", time: "10 min ago", type: "Clinical" },
    { user: "Admin Sarah", action: "Updated billing for MRN-0124", time: "25 min ago", type: "Billing" },
    { user: "Nurse Maya", action: "Recorded vitals for MRN-0125", time: "1 hour ago", type: "Clinical" },
    { user: "System", action: "Automated backup completed", time: "2 hours ago", type: "System" }
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white border-b border-gray-200 sticky top-0 z-50">
        <div className="px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <h1 className="text-2xl font-bold text-gray-900" style={{ fontFamily: 'Bebas Neue' }}>
                DR. MOTABHAI™ Manager Portal
              </h1>
              <span className="px-3 py-1 bg-[#3E5147] text-white text-sm rounded-full" style={{ fontFamily: 'DM Sans' }}>
                Unified Management Dashboard
              </span>
            </div>
            <div className="flex items-center gap-4">
              <button className="relative p-2 hover:bg-gray-100 rounded-full">
                <Bell className="w-5 h-5 text-gray-600" />
                <span className="absolute top-1 right-1 w-2 h-2 bg-red-500 rounded-full"></span>
              </button>
              <div className="flex items-center gap-3">
                <div className="text-right">
                  <p className="text-sm font-semibold" style={{ fontFamily: 'DM Sans' }}>Manager Sarah Patel</p>
                  <p className="text-xs text-gray-500" style={{ fontFamily: 'DM Sans' }}>Operations Manager</p>
                </div>
                <div className="w-10 h-10 bg-[#3E5147] rounded-full flex items-center justify-center text-white font-bold">
                  SP
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Navigation Tabs */}
        <div className="px-6 flex gap-6 border-t border-gray-200 overflow-x-auto">
          {[
            { id: "overview", label: "Overview", icon: Activity },
            { id: "users", label: "Users & Staff", icon: Users },
            { id: "patient-care", label: "Patient Care", icon: Pill },
            { id: "schedule", label: "Schedule", icon: Calendar },
            { id: "billing", label: "Billing", icon: DollarSign },
            { id: "inventory", label: "Inventory", icon: Package },
            { id: "vendors", label: "Vendors", icon: Truck },
            { id: "analytics", label: "Analytics", icon: BarChart3 },
            { id: "messages", label: "Messages", icon: MessageSquare },
            { id: "settings", label: "Settings", icon: Settings }
          ].map(tab => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`flex items-center gap-2 px-4 py-3 border-b-2 transition-colors whitespace-nowrap ${
                activeTab === tab.id 
                  ? "border-[#3E5147] text-[#3E5147]" 
                  : "border-transparent text-gray-600 hover:text-gray-900"
              }`}
              style={{ fontFamily: 'DM Sans' }}
            >
              <tab.icon className="w-4 h-4" />
              {tab.label}
              {tab.id === "patient-care" && overviewStats.activeAlerts > 0 && (
                <span className="ml-1 px-2 py-0.5 bg-red-500 text-white text-xs rounded-full">{overviewStats.activeAlerts}</span>
              )}
            </button>
          ))}
        </div>
      </header>

      {/* Main Content */}
      <main className="p-6 max-w-7xl mx-auto">
        {activeTab === "overview" && (
          <div className="space-y-6">
            {/* Combined Stats Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
              <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200">
                <div className="flex items-center justify-between mb-2">
                  <Users className="w-5 h-5 text-[#4A6B78]" />
                  <span className="text-xs text-green-600 font-semibold">+{overviewStats.newEnrollments} this month</span>
                </div>
                <p className="text-3xl font-bold text-gray-900" style={{ fontFamily: 'DM Sans' }}>{overviewStats.totalPatients}</p>
                <p className="text-sm text-gray-500">Total Patients</p>
              </div>

              <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200">
                <div className="flex items-center justify-between mb-2">
                  <Calendar className="w-5 h-5 text-[#55675E]" />
                  <span className="text-xs text-blue-600 font-semibold">Today</span>
                </div>
                <p className="text-3xl font-bold text-gray-900" style={{ fontFamily: 'DM Sans' }}>{overviewStats.todayAppointments}</p>
                <p className="text-sm text-gray-500">Appointments</p>
              </div>

              <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200">
                <div className="flex items-center justify-between mb-2">
                  <DollarSign className="w-5 h-5 text-green-600" />
                  <span className="text-xs text-green-600 font-semibold">+12%</span>
                </div>
                <p className="text-3xl font-bold text-gray-900" style={{ fontFamily: 'DM Sans' }}>{overviewStats.monthlyRevenue}</p>
                <p className="text-sm text-gray-500">Monthly Revenue</p>
              </div>

              <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200">
                <div className="flex items-center justify-between mb-2">
                  <AlertTriangle className="w-5 h-5 text-red-500" />
                  <span className="text-xs text-red-600 font-semibold">Urgent</span>
                </div>
                <p className="text-3xl font-bold text-gray-900" style={{ fontFamily: 'DM Sans' }}>{overviewStats.activeAlerts}</p>
                <p className="text-sm text-gray-500">Active Alerts</p>
              </div>

              <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200">
                <div className="flex items-center justify-between mb-2">
                  <Activity className="w-5 h-5 text-[#3E5147]" />
                  <span className="text-xs text-orange-600 font-semibold">Pending</span>
                </div>
                <p className="text-3xl font-bold text-gray-900" style={{ fontFamily: 'DM Sans' }}>{overviewStats.pendingVitals}</p>
                <p className="text-sm text-gray-500">Vitals Due</p>
              </div>

              <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200">
                <div className="flex items-center justify-between mb-2">
                  <ShoppingCart className="w-5 h-5 text-[#4A6B78]" />
                  <span className="text-xs text-orange-600 font-semibold">{overviewStats.pendingOrders} Pending</span>
                </div>
                <p className="text-3xl font-bold text-gray-900" style={{ fontFamily: 'DM Sans' }}>{overviewStats.totalOrders}</p>
                <p className="text-sm text-gray-500">Vendor Orders</p>
              </div>

              <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200">
                <div className="flex items-center justify-between mb-2">
                  <Package className="w-5 h-5 text-[#55675E]" />
                  <span className="text-xs text-yellow-600 font-semibold">2 Low Stock</span>
                </div>
                <p className="text-3xl font-bold text-gray-900" style={{ fontFamily: 'DM Sans' }}>156</p>
                <p className="text-sm text-gray-500">Total Items</p>
              </div>

              <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200">
                <div className="flex items-center justify-between mb-2">
                  <Users className="w-5 h-5 text-[#3E5147]" />
                  <span className="text-xs text-blue-600 font-semibold">Active</span>
                </div>
                <p className="text-3xl font-bold text-gray-900" style={{ fontFamily: 'DM Sans' }}>{overviewStats.totalStaff + overviewStats.totalDoctors}</p>
                <p className="text-sm text-gray-500">Total Staff</p>
              </div>
            </div>

            {/* Main Grid */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* System Activity */}
              <div className="bg-white rounded-xl shadow-sm border border-gray-200">
                <div className="p-6 border-b border-gray-200">
                  <h3 className="text-lg font-bold text-gray-900" style={{ fontFamily: 'DM Sans' }}>Recent System Activity</h3>
                </div>
                <div className="divide-y divide-gray-100">
                  {systemActivity.map((activity, idx) => (
                    <div key={idx} className="p-6">
                      <div className="flex items-start justify-between">
                        <div>
                          <h4 className="font-semibold text-gray-900 text-sm">{activity.user}</h4>
                          <p className="text-sm text-gray-600 mt-1">{activity.action}</p>
                          <p className="text-xs text-gray-500 mt-1">{activity.time}</p>
                        </div>
                        <span className={`px-3 py-1 rounded-full text-xs font-semibold ${
                          activity.type === "Clinical" ? "bg-blue-100 text-blue-700" :
                          activity.type === "Billing" ? "bg-green-100 text-green-700" :
                          "bg-gray-100 text-gray-700"
                        }`}>
                          {activity.type}
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Active Alerts */}
              <div className="bg-white rounded-xl shadow-sm border border-gray-200">
                <div className="p-6 border-b border-gray-200">
                  <h3 className="text-lg font-bold text-gray-900" style={{ fontFamily: 'DM Sans' }}>Active Patient Alerts</h3>
                </div>
                <div className="divide-y divide-gray-100">
                  {alerts.map((alert, idx) => (
                    <div key={idx} className={`p-6 ${
                      alert.priority === "High" ? "bg-red-50" : 
                      alert.priority === "Medium" ? "bg-yellow-50" : "bg-blue-50"
                    }`}>
                      <div className="flex items-start gap-4">
                        <AlertTriangle className={`w-6 h-6 flex-shrink-0 ${
                          alert.priority === "High" ? "text-red-600" :
                          alert.priority === "Medium" ? "text-yellow-600" :
                          "text-blue-600"
                        }`} />
                        <div className="flex-1">
                          <div className="flex items-center gap-2 mb-1">
                            <h4 className="font-bold text-gray-900">{alert.patient}</h4>
                            <span className="text-xs text-gray-500">({alert.mrn})</span>
                          </div>
                          <p className="text-sm text-gray-900 mb-2">{alert.message}</p>
                          <p className="text-xs text-gray-500">{alert.time}</p>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            {/* Revenue Overview */}
            <div className="bg-gradient-to-br from-[#3E5147] to-[#4A6B78] rounded-xl shadow-lg text-white p-8">
              <h3 className="text-2xl font-bold mb-6" style={{ fontFamily: 'Bebas Neue' }}>Financial Overview - January 2024</h3>
              <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
                <div>
                  <p className="text-sm opacity-90 mb-2">Total Revenue</p>
                  <p className="text-3xl font-bold">₹52,45,000</p>
                </div>
                <div>
                  <p className="text-sm opacity-90 mb-2">Pending Payments</p>
                  <p className="text-3xl font-bold">₹8,75,000</p>
                </div>
                <div>
                  <p className="text-sm opacity-90 mb-2">Vendor Expenses</p>
                  <p className="text-3xl font-bold">₹18,45,000</p>
                </div>
                <div>
                  <p className="text-sm opacity-90 mb-2">Growth Rate</p>
                  <p className="text-3xl font-bold">+12%</p>
                </div>
              </div>
            </div>
          </div>
        )}

        {activeTab === "users" && (
          <div className="space-y-6">
            <div className="bg-white rounded-xl shadow-sm border border-gray-200">
              <div className="p-6 border-b border-gray-200 flex items-center justify-between">
                <h3 className="text-lg font-bold text-gray-900" style={{ fontFamily: 'DM Sans' }}>User Management</h3>
                <button className="px-4 py-2 bg-[#3E5147] text-white rounded-lg hover:bg-[#4A6B78] flex items-center gap-2">
                  <UserPlus className="w-4 h-4" />
                  Add New User
                </button>
              </div>
              <div className="overflow-x-auto">
                <table className="w-full" style={{ fontFamily: 'DM Sans' }}>
                  <thead className="bg-gray-50">
                    <tr>
                      <th className="px-6 py-3 text-left text-xs font-semibold text-gray-600">Name</th>
                      <th className="px-6 py-3 text-left text-xs font-semibold text-gray-600">Type</th>
                      <th className="px-6 py-3 text-left text-xs font-semibold text-gray-600">Email</th>
                      <th className="px-6 py-3 text-left text-xs font-semibold text-gray-600">Join Date</th>
                      <th className="px-6 py-3 text-left text-xs font-semibold text-gray-600">Status</th>
                      <th className="px-6 py-3 text-left text-xs font-semibold text-gray-600">Actions</th>
                    </tr>
                  </thead>
                  <tbody>
                    {recentUsers.map((user, idx) => (
                      <tr key={idx} className="border-b border-gray-100 hover:bg-gray-50">
                        <td className="px-6 py-4 text-sm font-semibold text-gray-900">{user.name}</td>
                        <td className="px-6 py-4">
                          <span className={`px-3 py-1 rounded-full text-xs font-semibold ${
                            user.type === "Doctor" ? "bg-purple-100 text-purple-700" :
                            user.type === "Staff" ? "bg-blue-100 text-blue-700" :
                            "bg-green-100 text-green-700"
                          }`}>
                            {user.type}
                          </span>
                        </td>
                        <td className="px-6 py-4 text-sm text-gray-600">{user.email}</td>
                        <td className="px-6 py-4 text-sm text-gray-600">{user.joinDate}</td>
                        <td className="px-6 py-4">
                          <span className="px-3 py-1 rounded-full text-xs font-semibold bg-green-100 text-green-700">
                            {user.status}
                          </span>
                        </td>
                        <td className="px-6 py-4">
                          <button className="text-[#3E5147] hover:underline text-sm font-semibold">Edit</button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {activeTab === "patient-care" && (
          <div className="space-y-6">
            {/* Patients List */}
            <div className="bg-white rounded-xl shadow-sm border border-gray-200">
              <div className="p-6 border-b border-gray-200 flex items-center justify-between">
                <h3 className="text-lg font-bold text-gray-900" style={{ fontFamily: 'DM Sans' }}>Patient List</h3>
                <div className="flex items-center gap-3">
                  <div className="relative">
                    <Search className="w-4 h-4 absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
                    <input
                      type="text"
                      placeholder="Search patients..."
                      className="pl-10 pr-4 py-2 border border-gray-300 rounded-lg text-sm"
                      style={{ fontFamily: 'DM Sans' }}
                    />
                  </div>
                  <button className="flex items-center gap-2 px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50">
                    <Filter className="w-4 h-4" />
                    Filter
                  </button>
                </div>
              </div>
              <div className="overflow-x-auto">
                <table className="w-full" style={{ fontFamily: 'DM Sans' }}>
                  <thead className="bg-gray-50">
                    <tr>
                      <th className="px-6 py-3 text-left text-xs font-semibold text-gray-600">MRN</th>
                      <th className="px-6 py-3 text-left text-xs font-semibold text-gray-600">Patient Name</th>
                      <th className="px-6 py-3 text-left text-xs font-semibold text-gray-600">Age</th>
                      <th className="px-6 py-3 text-left text-xs font-semibold text-gray-600">Program</th>
                      <th className="px-6 py-3 text-left text-xs font-semibold text-gray-600">Next Visit</th>
                      <th className="px-6 py-3 text-left text-xs font-semibold text-gray-600">Vitals Status</th>
                      <th className="px-6 py-3 text-left text-xs font-semibold text-gray-600">Priority</th>
                      <th className="px-6 py-3 text-left text-xs font-semibold text-gray-600">Actions</th>
                    </tr>
                  </thead>
                  <tbody>
                    {patients.map((patient, idx) => (
                      <tr key={idx} className="border-b border-gray-100 hover:bg-gray-50">
                        <td className="px-6 py-4 text-sm font-mono text-gray-600">{patient.id}</td>
                        <td className="px-6 py-4 text-sm font-semibold text-gray-900">{patient.name}</td>
                        <td className="px-6 py-4 text-sm text-gray-600">{patient.age}</td>
                        <td className="px-6 py-4 text-sm text-gray-600">{patient.program}</td>
                        <td className="px-6 py-4 text-sm text-gray-600">{patient.nextVisit}</td>
                        <td className="px-6 py-4">
                          <span className={`px-3 py-1 rounded-full text-xs font-semibold ${
                            patient.vitals === "Due Today" ? "bg-yellow-100 text-yellow-700" :
                            patient.vitals === "Overdue" ? "bg-red-100 text-red-700" :
                            "bg-green-100 text-green-700"
                          }`}>
                            {patient.vitals}
                          </span>
                        </td>
                        <td className="px-6 py-4">
                          <span className={`px-3 py-1 rounded-full text-xs font-semibold ${
                            patient.priority === "High" ? "bg-red-100 text-red-700" : "bg-gray-100 text-gray-700"
                          }`}>
                            {patient.priority}
                          </span>
                        </td>
                        <td className="px-6 py-4">
                          <button className="text-[#3E5147] hover:underline text-sm font-semibold">View Chart</button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>

            {/* Vitals Queue */}
            <div className="bg-white rounded-xl shadow-sm border border-gray-200">
              <div className="p-6 border-b border-gray-200">
                <h3 className="text-lg font-bold text-gray-900" style={{ fontFamily: 'DM Sans' }}>Vitals Queue - Today</h3>
              </div>
              <div className="divide-y divide-gray-100">
                {vitalsQueue.map((vital, idx) => (
                  <div key={idx} className="p-6 hover:bg-gray-50 transition-colors">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-4">
                        <div className={`w-16 h-16 rounded-lg flex flex-col items-center justify-center ${
                          vital.status === "Overdue" ? "bg-red-100" : "bg-blue-100"
                        }`}>
                          <Clock className={`w-6 h-6 ${vital.status === "Overdue" ? "text-red-600" : "text-blue-600"}`} />
                        </div>
                        <div>
                          <h4 className="font-bold text-gray-900">{vital.patient}</h4>
                          <p className="text-sm text-gray-600">MRN: {vital.mrn}</p>
                          <p className="text-sm text-gray-500">{vital.type} - {vital.scheduled}</p>
                        </div>
                      </div>
                      <div className="flex items-center gap-3">
                        <span className={`px-3 py-1 rounded-full text-xs font-semibold ${
                          vital.status === "Overdue" ? "bg-red-100 text-red-700" : "bg-blue-100 text-blue-700"
                        }`}>
                          {vital.status}
                        </span>
                        <button className="px-4 py-2 bg-[#3E5147] text-white rounded-lg hover:bg-[#4A6B78]">
                          Record Vitals
                        </button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Medications */}
            <div className="bg-white rounded-xl shadow-sm border border-gray-200">
              <div className="p-6 border-b border-gray-200">
                <h3 className="text-lg font-bold text-gray-900" style={{ fontFamily: 'DM Sans' }}>Medication Administration - Today</h3>
              </div>
              <div className="overflow-x-auto">
                <table className="w-full" style={{ fontFamily: 'DM Sans' }}>
                  <thead className="bg-gray-50">
                    <tr>
                      <th className="px-6 py-3 text-left text-xs font-semibold text-gray-600">Time</th>
                      <th className="px-6 py-3 text-left text-xs font-semibold text-gray-600">Patient</th>
                      <th className="px-6 py-3 text-left text-xs font-semibold text-gray-600">MRN</th>
                      <th className="px-6 py-3 text-left text-xs font-semibold text-gray-600">Medication</th>
                      <th className="px-6 py-3 text-left text-xs font-semibold text-gray-600">Status</th>
                      <th className="px-6 py-3 text-left text-xs font-semibold text-gray-600">Administered By</th>
                      <th className="px-6 py-3 text-left text-xs font-semibold text-gray-600">Actions</th>
                    </tr>
                  </thead>
                  <tbody>
                    {medications.map((med, idx) => (
                      <tr key={idx} className="border-b border-gray-100 hover:bg-gray-50">
                        <td className="px-6 py-4 text-sm font-semibold text-gray-900">{med.time}</td>
                        <td className="px-6 py-4 text-sm text-gray-900">{med.patient}</td>
                        <td className="px-6 py-4 text-sm font-mono text-gray-600">{med.mrn}</td>
                        <td className="px-6 py-4 text-sm text-gray-900">{med.medication}</td>
                        <td className="px-6 py-4">
                          <span className={`px-3 py-1 rounded-full text-xs font-semibold ${
                            med.status === "Administered" ? "bg-green-100 text-green-700" :
                            med.status === "Pending" ? "bg-yellow-100 text-yellow-700" :
                            "bg-blue-100 text-blue-700"
                          }`}>
                            {med.status}
                          </span>
                        </td>
                        <td className="px-6 py-4 text-sm text-gray-600">{med.administeredBy}</td>
                        <td className="px-6 py-4">
                          {med.status !== "Administered" && (
                            <button className="text-[#3E5147] hover:underline text-sm font-semibold">Administer</button>
                          )}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {activeTab === "schedule" && (
          <div className="bg-white rounded-xl shadow-sm border border-gray-200">
            <div className="p-6 border-b border-gray-200">
              <h3 className="text-lg font-bold text-gray-900" style={{ fontFamily: 'DM Sans' }}>Today's Appointment Schedule</h3>
            </div>
            <div className="divide-y divide-gray-100">
              {appointments.map((apt, idx) => (
                <div key={idx} className="p-6 hover:bg-gray-50 transition-colors">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-4">
                      <div className="text-center">
                        <p className="text-2xl font-bold text-[#3E5147]">{apt.time.split(':')[0]}</p>
                        <p className="text-xs text-gray-500">{apt.time.split(' ')[1]}</p>
                      </div>
                      <div className="w-px h-12 bg-gray-200"></div>
                      <div>
                        <h4 className="font-bold text-gray-900">{apt.patient}</h4>
                        <p className="text-sm text-gray-600">{apt.type}</p>
                      </div>
                    </div>
                    <span className={`px-3 py-1 rounded-full text-xs font-semibold ${
                      apt.status === "In Progress" ? "bg-green-100 text-green-700" : "bg-blue-100 text-blue-700"
                    }`}>
                      {apt.status}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {activeTab === "billing" && (
          <div className="space-y-6">
            <div className="bg-white rounded-xl shadow-sm border border-gray-200">
              <div className="p-6 border-b border-gray-200 flex items-center justify-between">
                <h3 className="text-lg font-bold text-gray-900" style={{ fontFamily: 'DM Sans' }}>Billing Overview</h3>
                <button className="flex items-center gap-2 px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50">
                  <Download className="w-4 h-4" />
                  Export Report
                </button>
              </div>
              <div className="overflow-x-auto">
                <table className="w-full" style={{ fontFamily: 'DM Sans' }}>
                  <thead className="bg-gray-50">
                    <tr>
                      <th className="px-6 py-3 text-left text-xs font-semibold text-gray-600">Patient</th>
                      <th className="px-6 py-3 text-left text-xs font-semibold text-gray-600">MRN</th>
                      <th className="px-6 py-3 text-left text-xs font-semibold text-gray-600">Plan</th>
                      <th className="px-6 py-3 text-left text-xs font-semibold text-gray-600">Amount</th>
                      <th className="px-6 py-3 text-left text-xs font-semibold text-gray-600">Due Date</th>
                      <th className="px-6 py-3 text-left text-xs font-semibold text-gray-600">Status</th>
                      <th className="px-6 py-3 text-left text-xs font-semibold text-gray-600">Actions</th>
                    </tr>
                  </thead>
                  <tbody>
                    {billingOverview.map((bill, idx) => (
                      <tr key={idx} className="border-b border-gray-100 hover:bg-gray-50">
                        <td className="px-6 py-4 text-sm font-semibold text-gray-900">{bill.patient}</td>
                        <td className="px-6 py-4 text-sm font-mono text-gray-600">{bill.mrn}</td>
                        <td className="px-6 py-4 text-sm text-gray-600">{bill.plan}</td>
                        <td className="px-6 py-4 text-sm font-semibold text-gray-900">{bill.amount}</td>
                        <td className="px-6 py-4 text-sm text-gray-600">{bill.dueDate}</td>
                        <td className="px-6 py-4">
                          <span className={`px-3 py-1 rounded-full text-xs font-semibold ${
                            bill.status === "Paid" ? "bg-green-100 text-green-700" :
                            bill.status === "Pending" ? "bg-yellow-100 text-yellow-700" :
                            "bg-red-100 text-red-700"
                          }`}>
                            {bill.status}
                          </span>
                        </td>
                        <td className="px-6 py-4">
                          <button className="text-[#3E5147] hover:underline text-sm font-semibold">Manage</button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {activeTab === "inventory" && (
          <div className="space-y-6">
            <div className="bg-white rounded-xl shadow-sm border border-gray-200">
              <div className="p-6 border-b border-gray-200 flex items-center justify-between">
                <h3 className="text-lg font-bold text-gray-900" style={{ fontFamily: 'DM Sans' }}>Medication & Supply Inventory</h3>
                <button className="px-4 py-2 bg-[#3E5147] text-white rounded-lg hover:bg-[#4A6B78]">
                  Add New Item
                </button>
              </div>
              <div className="overflow-x-auto">
                <table className="w-full" style={{ fontFamily: 'DM Sans' }}>
                  <thead className="bg-gray-50">
                    <tr>
                      <th className="px-6 py-3 text-left text-xs font-semibold text-gray-600">Item Name</th>
                      <th className="px-6 py-3 text-left text-xs font-semibold text-gray-600">Current Stock</th>
                      <th className="px-6 py-3 text-left text-xs font-semibold text-gray-600">Reorder Level</th>
                      <th className="px-6 py-3 text-left text-xs font-semibold text-gray-600">Status</th>
                      <th className="px-6 py-3 text-left text-xs font-semibold text-gray-600">Supplier</th>
                      <th className="px-6 py-3 text-left text-xs font-semibold text-gray-600">Service Partner</th>
                      <th className="px-6 py-3 text-left text-xs font-semibold text-gray-600">Location</th>
                      <th className="px-6 py-3 text-left text-xs font-semibold text-gray-600">Actions</th>
                    </tr>
                  </thead>
                  <tbody>
                    {inventoryStatus.map((item, idx) => (
                      <tr key={idx} className="border-b border-gray-100 hover:bg-gray-50">
                        <td className="px-6 py-4 text-sm font-semibold text-gray-900">{item.item}</td>
                        <td className="px-6 py-4 text-sm text-gray-900">{item.stock}</td>
                        <td className="px-6 py-4 text-sm text-gray-600">{item.reorderLevel}</td>
                        <td className="px-6 py-4">
                          <span className={`px-3 py-1 rounded-full text-xs font-semibold ${
                            item.status === "In Stock" ? "bg-green-100 text-green-700" :
                            item.status === "Low Stock" ? "bg-yellow-100 text-yellow-700" :
                            "bg-red-100 text-red-700"
                          }`}>
                            {item.status}
                          </span>
                        </td>
                        <td className="px-6 py-4 text-sm text-gray-600">{item.supplier}</td>
                        <td className="px-6 py-4 text-sm text-gray-600">{item.servicePartner}</td>
                        <td className="px-6 py-4">
                          <div className="text-sm text-gray-900">{item.location}</div>
                          <div className="text-xs text-gray-500">PIN: {item.pincode}</div>
                        </td>
                        <td className="px-6 py-4">
                          <button className="text-[#3E5147] hover:underline text-sm font-semibold">Reorder</button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {activeTab === "vendors" && (
          <div className="space-y-6">
            {/* Vendor Orders */}
            <div className="bg-white rounded-xl shadow-sm border border-gray-200">
              <div className="p-6 border-b border-gray-200">
                <h3 className="text-lg font-bold text-gray-900" style={{ fontFamily: 'DM Sans' }}>Vendor Orders</h3>
              </div>
              <div className="overflow-x-auto">
                <table className="w-full" style={{ fontFamily: 'DM Sans' }}>
                  <thead className="bg-gray-50">
                    <tr>
                      <th className="px-6 py-3 text-left text-xs font-semibold text-gray-600">Order ID</th>
                      <th className="px-6 py-3 text-left text-xs font-semibold text-gray-600">Vendor</th>
                      <th className="px-6 py-3 text-left text-xs font-semibold text-gray-600">Item</th>
                      <th className="px-6 py-3 text-left text-xs font-semibold text-gray-600">Quantity</th>
                      <th className="px-6 py-3 text-left text-xs font-semibold text-gray-600">Delivery Date</th>
                      <th className="px-6 py-3 text-left text-xs font-semibold text-gray-600">Amount</th>
                      <th className="px-6 py-3 text-left text-xs font-semibold text-gray-600">Status</th>
                      <th className="px-6 py-3 text-left text-xs font-semibold text-gray-600">Actions</th>
                    </tr>
                  </thead>
                  <tbody>
                    {vendorOrders.map((order, idx) => (
                      <tr key={idx} className="border-b border-gray-100 hover:bg-gray-50">
                        <td className="px-6 py-4 text-sm font-mono text-gray-600">{order.orderId}</td>
                        <td className="px-6 py-4 text-sm text-gray-900">{order.vendor}</td>
                        <td className="px-6 py-4 text-sm font-semibold text-gray-900">{order.item}</td>
                        <td className="px-6 py-4 text-sm text-gray-600">{order.quantity}</td>
                        <td className="px-6 py-4 text-sm text-gray-600">{order.deliveryDate}</td>
                        <td className="px-6 py-4 text-sm font-semibold text-gray-900">{order.amount}</td>
                        <td className="px-6 py-4">
                          <span className={`px-3 py-1 rounded-full text-xs font-semibold ${
                            order.status === "Processing" ? "bg-blue-100 text-blue-700" : "bg-yellow-100 text-yellow-700"
                          }`}>
                            {order.status}
                          </span>
                        </td>
                        <td className="px-6 py-4">
                          <button className="text-[#3E5147] hover:underline text-sm font-semibold">Manage</button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>

            {/* Recent Deliveries */}
            <div className="bg-white rounded-xl shadow-sm border border-gray-200">
              <div className="p-6 border-b border-gray-200">
                <h3 className="text-lg font-bold text-gray-900" style={{ fontFamily: 'DM Sans' }}>Recent Deliveries</h3>
              </div>
              <div className="overflow-x-auto">
                <table className="w-full" style={{ fontFamily: 'DM Sans' }}>
                  <thead className="bg-gray-50">
                    <tr>
                      <th className="px-6 py-3 text-left text-xs font-semibold text-gray-600">Order ID</th>
                      <th className="px-6 py-3 text-left text-xs font-semibold text-gray-600">Vendor</th>
                      <th className="px-6 py-3 text-left text-xs font-semibold text-gray-600">Item</th>
                      <th className="px-6 py-3 text-left text-xs font-semibold text-gray-600">Quantity</th>
                      <th className="px-6 py-3 text-left text-xs font-semibold text-gray-600">Delivery Date</th>
                      <th className="px-6 py-3 text-left text-xs font-semibold text-gray-600">Amount</th>
                      <th className="px-6 py-3 text-left text-xs font-semibold text-gray-600">Status</th>
                    </tr>
                  </thead>
                  <tbody>
                    {recentDeliveries.map((delivery, idx) => (
                      <tr key={idx} className="border-b border-gray-100 hover:bg-gray-50">
                        <td className="px-6 py-4 text-sm font-mono text-gray-600">{delivery.orderId}</td>
                        <td className="px-6 py-4 text-sm text-gray-900">{delivery.vendor}</td>
                        <td className="px-6 py-4 text-sm font-semibold text-gray-900">{delivery.item}</td>
                        <td className="px-6 py-4 text-sm text-gray-600">{delivery.quantity}</td>
                        <td className="px-6 py-4 text-sm text-gray-600">{delivery.deliveryDate}</td>
                        <td className="px-6 py-4 text-sm font-semibold text-gray-900">{delivery.amount}</td>
                        <td className="px-6 py-4">
                          <span className="px-3 py-1 rounded-full text-xs font-semibold bg-green-100 text-green-700">
                            {delivery.status}
                          </span>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>

            {/* Vendor Invoices */}
            <div className="bg-white rounded-xl shadow-sm border border-gray-200">
              <div className="p-6 border-b border-gray-200 flex items-center justify-between">
                <h3 className="text-lg font-bold text-gray-900" style={{ fontFamily: 'DM Sans' }}>Vendor Invoices</h3>
                <button className="px-4 py-2 bg-[#3E5147] text-white rounded-lg hover:bg-[#4A6B78]">
                  Process Payment
                </button>
              </div>
              <div className="overflow-x-auto">
                <table className="w-full" style={{ fontFamily: 'DM Sans' }}>
                  <thead className="bg-gray-50">
                    <tr>
                      <th className="px-6 py-3 text-left text-xs font-semibold text-gray-600">Invoice ID</th>
                      <th className="px-6 py-3 text-left text-xs font-semibold text-gray-600">Vendor</th>
                      <th className="px-6 py-3 text-left text-xs font-semibold text-gray-600">Amount</th>
                      <th className="px-6 py-3 text-left text-xs font-semibold text-gray-600">Issue Date</th>
                      <th className="px-6 py-3 text-left text-xs font-semibold text-gray-600">Due Date</th>
                      <th className="px-6 py-3 text-left text-xs font-semibold text-gray-600">Status</th>
                      <th className="px-6 py-3 text-left text-xs font-semibold text-gray-600">Actions</th>
                    </tr>
                  </thead>
                  <tbody>
                    {vendorInvoices.map((invoice, idx) => (
                      <tr key={idx} className="border-b border-gray-100 hover:bg-gray-50">
                        <td className="px-6 py-4 text-sm font-mono text-gray-600">{invoice.invoiceId}</td>
                        <td className="px-6 py-4 text-sm text-gray-900">{invoice.vendor}</td>
                        <td className="px-6 py-4 text-sm font-semibold text-gray-900">{invoice.amount}</td>
                        <td className="px-6 py-4 text-sm text-gray-600">{invoice.issueDate}</td>
                        <td className="px-6 py-4 text-sm text-gray-600">{invoice.dueDate}</td>
                        <td className="px-6 py-4">
                          <span className={`px-3 py-1 rounded-full text-xs font-semibold ${
                            invoice.status === "Paid" ? "bg-green-100 text-green-700" : "bg-yellow-100 text-yellow-700"
                          }`}>
                            {invoice.status}
                          </span>
                        </td>
                        <td className="px-6 py-4">
                          <button className="text-[#3E5147] hover:underline text-sm font-semibold">View</button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {activeTab === "analytics" && (
          <div className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
                <h4 className="font-bold text-gray-900 mb-4">Patient Growth</h4>
                <p className="text-4xl font-bold text-[#3E5147] mb-2">+18</p>
                <p className="text-sm text-gray-600">New patients this month</p>
                <div className="mt-4">
                  <div className="flex justify-between text-xs text-gray-500 mb-1">
                    <span>Target: 20</span>
                    <span>90%</span>
                  </div>
                  <div className="w-full bg-gray-200 rounded-full h-2">
                    <div className="bg-[#3E5147] h-2 rounded-full" style={{ width: '90%' }}></div>
                  </div>
                </div>
              </div>

              <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
                <h4 className="font-bold text-gray-900 mb-4">Revenue Growth</h4>
                <p className="text-4xl font-bold text-green-600 mb-2">+12%</p>
                <p className="text-sm text-gray-600">Compared to last month</p>
                <div className="mt-4">
                  <div className="flex justify-between text-xs text-gray-500 mb-1">
                    <span>Target: 15%</span>
                    <span>80%</span>
                  </div>
                  <div className="w-full bg-gray-200 rounded-full h-2">
                    <div className="bg-green-600 h-2 rounded-full" style={{ width: '80%' }}></div>
                  </div>
                </div>
              </div>

              <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
                <h4 className="font-bold text-gray-900 mb-4">Patient Satisfaction</h4>
                <p className="text-4xl font-bold text-blue-600 mb-2">4.8/5</p>
                <p className="text-sm text-gray-600">Average rating</p>
                <div className="mt-4">
                  <div className="flex justify-between text-xs text-gray-500 mb-1">
                    <span>Target: 4.5</span>
                    <span>Exceeded</span>
                  </div>
                  <div className="w-full bg-gray-200 rounded-full h-2">
                    <div className="bg-blue-600 h-2 rounded-full" style={{ width: '96%' }}></div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {activeTab === "messages" && (
          <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-12 text-center">
            <MessageSquare className="w-16 h-16 text-gray-400 mx-auto mb-4" />
            <h3 className="text-xl font-bold text-gray-900 mb-2">Messages & Communications</h3>
            <p className="text-gray-600">Secure messaging system for staff and patient communications</p>
          </div>
        )}

        {activeTab === "settings" && (
          <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-12 text-center">
            <Settings className="w-16 h-16 text-gray-400 mx-auto mb-4" />
            <h3 className="text-xl font-bold text-gray-900 mb-2">System Settings</h3>
            <p className="text-gray-600">Configure system preferences, access controls, and integrations</p>
          </div>
        )}
      </main>
    </div>
  );
}