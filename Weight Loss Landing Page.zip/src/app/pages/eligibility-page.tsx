import { useState } from "react";
import { Header } from "@/app/components/header";
import { Footer } from "@/app/components/footer";

export function EligibilityPage() {
  const [step, setStep] = useState(1);
  const [formData, setFormData] = useState({
    age: "",
    weight: "",
    heightFeet: "",
    heightInches: "",
    bmi: 0,
    conditions: [] as string[],
    medications: "",
    previousAttempts: ""
  });

  const calculateBMI = (weightKg: number, heightFeet: number, heightInches: number) => {
    // Convert feet and inches to meters
    const totalInches = (heightFeet * 12) + heightInches;
    const heightMeters = totalInches * 0.0254;
    // BMI = weight(kg) / height(m)^2
    return (weightKg / (heightMeters * heightMeters)).toFixed(1);
  };

  const handleWeightHeightChange = (field: string, value: string) => {
    const newData = { ...formData, [field]: value };
    if (newData.weight && newData.heightFeet && newData.heightInches) {
      const bmi = parseFloat(calculateBMI(
        parseFloat(newData.weight), 
        parseFloat(newData.heightFeet), 
        parseFloat(newData.heightInches)
      ));
      newData.bmi = bmi;
    }
    setFormData(newData);
  };

  const toggleCondition = (condition: string) => {
    setFormData(prev => ({
      ...prev,
      conditions: prev.conditions.includes(condition)
        ? prev.conditions.filter(c => c !== condition)
        : [...prev.conditions, condition]
    }));
  };

  const hasComorbidities = () => {
    return formData.conditions.length > 0 && !formData.conditions.includes('None of the above');
  };

  const isEligible = () => {
    // BMI > 27 -> Need medication
    if (formData.bmi >= 27) return true;
    // BMI > 25 with comorbidities -> Need medication
    if (formData.bmi >= 25 && hasComorbidities()) return true;
    return false;
  };

  const getBMIColor = (bmi: number) => {
    if (bmi >= 30) return { bg: 'bg-red-100', text: 'text-red-700', border: 'border-red-300' };
    if (bmi >= 27) return { bg: 'bg-orange-100', text: 'text-orange-700', border: 'border-orange-300' };
    if (bmi >= 25) return { bg: 'bg-yellow-100', text: 'text-yellow-700', border: 'border-yellow-300' };
    return { bg: 'bg-green-100', text: 'text-green-700', border: 'border-green-300' };
  };

  const getBMIMessage = (bmi: number) => {
    if (bmi >= 30) return { 
      title: 'Obesity Class I or Higher', 
      description: 'You are at high risk for serious health complications including heart disease, diabetes, and stroke.' 
    };
    if (bmi >= 27) return { 
      title: 'Overweight', 
      description: 'You may be at increased risk for weight-related health conditions. Medical intervention is recommended.' 
    };
    if (bmi >= 25) return { 
      title: 'Overweight', 
      description: 'With weight-related conditions, you may benefit from medical treatment.' 
    };
    return { 
      title: 'Healthy Weight', 
      description: 'Your BMI is in the healthy range. Medication may not be necessary.' 
    };
  };

  return (
    <div className="min-h-screen bg-white">
      <Header />
      
      <section className="pt-32 pb-20">
        <div className="container mx-auto px-4 lg:px-8 max-w-4xl">
          <div className="text-center mb-12">
            <h1 
              className="text-gray-900 mb-6"
              style={{ 
                fontFamily: 'Bebas Neue',
                fontSize: 'clamp(48px, 8vw, 64px)',
                lineHeight: '1',
                letterSpacing: '0.02em'
              }}
            >
              Check Your Eligibility
            </h1>
            <p 
              className="text-gray-600 max-w-2xl mx-auto"
              style={{ 
                fontFamily: 'DM Sans',
                fontSize: '16px',
                lineHeight: '1.6'
              }}
            >
              Answer a few quick questions to see if GLP-1 treatment is right for you. After eligibility confirmation, you'll schedule a consultation where Dr. Motabhai will prescribe the appropriate medication.
            </p>
          </div>

          {/* Progress Bar */}
          <div className="mb-12">
            <div className="flex justify-between mb-2">
              {[1, 2, 3, 4].map((s) => (
                <span 
                  key={s}
                  className={`text-sm ${step >= s ? 'text-[#4A6B78] font-bold' : 'text-gray-400'}`}
                  style={{ fontFamily: 'DM Sans' }}
                >
                  Step {s}
                </span>
              ))}
            </div>
            <div className="h-2 bg-gray-200 rounded-full">
              <div 
                className="h-2 bg-[#4A6B78] rounded-full transition-all duration-300"
                style={{ width: `${(step / 4) * 100}%` }}
              />
            </div>
          </div>

          {/* Step 1: Basic Info */}
          {step === 1 && (
            <div className="bg-white border-2 border-gray-200 rounded-2xl p-8">
              <h2 
                className="text-gray-900 mb-6"
                style={{ 
                  fontFamily: 'Bebas Neue',
                  fontSize: '32px',
                  letterSpacing: '0.02em'
                }}
              >
                Basic Information
              </h2>
              
              <div className="space-y-6">
                <div>
                  <label 
                    className="block text-gray-700 mb-2 text-sm font-medium"
                    style={{ fontFamily: 'DM Sans' }}
                  >
                    Age
                  </label>
                  <input
                    type="number"
                    value={formData.age}
                    onChange={(e) => setFormData({ ...formData, age: e.target.value })}
                    className="w-full p-4 border-2 border-gray-200 rounded-lg focus:border-[#4A6B78] focus:outline-none"
                    style={{ fontFamily: 'DM Sans' }}
                    placeholder="Enter your age"
                  />
                </div>

                <div>
                  <label 
                    className="block text-gray-700 mb-2 text-sm font-medium"
                    style={{ fontFamily: 'DM Sans' }}
                  >
                    Weight (Kgs)
                  </label>
                  <input
                    type="number"
                    value={formData.weight}
                    onChange={(e) => handleWeightHeightChange('weight', e.target.value)}
                    className="w-full p-4 border-2 border-gray-200 rounded-lg focus:border-[#4A6B78] focus:outline-none"
                    style={{ fontFamily: 'DM Sans' }}
                    placeholder="Enter weight in kilograms"
                  />
                </div>

                <div>
                  <label 
                    className="block text-gray-700 mb-2 text-sm font-medium"
                    style={{ fontFamily: 'DM Sans' }}
                  >
                    Height
                  </label>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <input
                        type="number"
                        value={formData.heightFeet}
                        onChange={(e) => handleWeightHeightChange('heightFeet', e.target.value)}
                        className="w-full p-4 border-2 border-gray-200 rounded-lg focus:border-[#4A6B78] focus:outline-none"
                        style={{ fontFamily: 'DM Sans' }}
                        placeholder="Feet"
                      />
                    </div>
                    <div>
                      <input
                        type="number"
                        value={formData.heightInches}
                        onChange={(e) => handleWeightHeightChange('heightInches', e.target.value)}
                        className="w-full p-4 border-2 border-gray-200 rounded-lg focus:border-[#4A6B78] focus:outline-none"
                        style={{ fontFamily: 'DM Sans' }}
                        placeholder="Inches"
                        min="0"
                        max="11"
                      />
                    </div>
                  </div>
                </div>

                {formData.bmi > 0 && (() => {
                  const colors = getBMIColor(formData.bmi);
                  const message = getBMIMessage(formData.bmi);
                  return (
                    <div className={`${colors.bg} border-2 ${colors.border} rounded-xl p-6`}>
                      <p 
                        className="text-gray-700 mb-1"
                        style={{ fontFamily: 'DM Sans', fontSize: '14px' }}
                      >
                        Your BMI
                      </p>
                      <p 
                        className={colors.text}
                        style={{ 
                          fontFamily: 'DM Sans',
                          fontSize: '48px',
                          fontWeight: '700',
                          lineHeight: '1'
                        }}
                      >
                        {formData.bmi}
                      </p>
                      <p 
                        className={`${colors.text} font-bold mt-2`}
                        style={{ fontFamily: 'DM Sans', fontSize: '16px' }}
                      >
                        {message.title}
                      </p>
                      <p 
                        className="text-gray-700 mt-2 text-sm"
                        style={{ fontFamily: 'DM Sans' }}
                      >
                        {message.description}
                      </p>
                    </div>
                  );
                })()}
              </div>

              <button
                onClick={() => setStep(2)}
                disabled={!formData.age || !formData.weight || !formData.heightFeet || !formData.heightInches}
                className="w-full mt-8 py-4 bg-[#4A6B78] text-white rounded-lg font-bold hover:bg-[#3E5147] transition-all disabled:bg-gray-300 disabled:cursor-not-allowed"
                style={{ fontFamily: 'DM Sans', fontSize: '16px' }}
              >
                Continue
              </button>
            </div>
          )}

          {/* Step 2: Health Conditions */}
          {step === 2 && (
            <div className="bg-white border-2 border-gray-200 rounded-2xl p-8">
              <h2 
                className="text-gray-900 mb-6"
                style={{ 
                  fontFamily: 'Bebas Neue',
                  fontSize: '32px',
                  letterSpacing: '0.02em'
                }}
              >
                Health Conditions
              </h2>
              
              <p 
                className="text-gray-600 mb-6"
                style={{ fontFamily: 'DM Sans', fontSize: '14px' }}
              >
                Select any conditions that apply to you:
              </p>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {[
                  'Type 2 Diabetes',
                  'High Blood Pressure',
                  'High Cholesterol',
                  'Sleep Apnea',
                  'Fatty Liver Disease',
                  'PCOS',
                  'Heart Disease',
                  'None of the above'
                ].map((condition) => (
                  <button
                    key={condition}
                    onClick={() => toggleCondition(condition)}
                    className={`p-4 rounded-lg border-2 text-left transition-all ${
                      formData.conditions.includes(condition)
                        ? 'border-[#4A6B78] bg-[#4A6B78]/10'
                        : 'border-gray-200 hover:border-gray-300'
                    }`}
                    style={{ fontFamily: 'DM Sans', fontSize: '14px' }}
                  >
                    {condition}
                  </button>
                ))}
              </div>

              <div className="flex gap-4 mt-8">
                <button
                  onClick={() => setStep(1)}
                  className="flex-1 py-4 bg-gray-100 text-gray-700 rounded-lg font-bold hover:bg-gray-200 transition-all"
                  style={{ fontFamily: 'DM Sans', fontSize: '16px' }}
                >
                  Back
                </button>
                <button
                  onClick={() => setStep(3)}
                  className="flex-1 py-4 bg-[#4A6B78] text-white rounded-lg font-bold hover:bg-[#3E5147] transition-all"
                  style={{ fontFamily: 'DM Sans', fontSize: '16px' }}
                >
                  Continue
                </button>
              </div>
            </div>
          )}

          {/* Step 3: Previous Attempts */}
          {step === 3 && (
            <div className="bg-white border-2 border-gray-200 rounded-2xl p-8">
              <h2 
                className="text-gray-900 mb-6"
                style={{ 
                  fontFamily: 'Bebas Neue',
                  fontSize: '32px',
                  letterSpacing: '0.02em'
                }}
              >
                Weight Loss History
              </h2>
              
              <div className="space-y-6">
                <div>
                  <label 
                    className="block text-gray-700 mb-2 text-sm font-medium"
                    style={{ fontFamily: 'DM Sans' }}
                  >
                    Have you tried to lose weight before?
                  </label>
                  <select
                    value={formData.previousAttempts}
                    onChange={(e) => setFormData({ ...formData, previousAttempts: e.target.value })}
                    className="w-full p-4 border-2 border-gray-200 rounded-lg focus:border-[#4A6B78] focus:outline-none"
                    style={{ fontFamily: 'DM Sans' }}
                  >
                    <option value="">Select an option</option>
                    <option value="diet-exercise">Diet and Exercise</option>
                    <option value="weight-loss-programs">Weight Loss Programs</option>
                    <option value="medications">Weight Loss Medications</option>
                    <option value="multiple">Multiple Attempts</option>
                    <option value="none">This is my first attempt</option>
                  </select>
                </div>

                <div>
                  <label 
                    className="block text-gray-700 mb-2 text-sm font-medium"
                    style={{ fontFamily: 'DM Sans' }}
                  >
                    Current Medications (Optional)
                  </label>
                  <textarea
                    value={formData.medications}
                    onChange={(e) => setFormData({ ...formData, medications: e.target.value })}
                    className="w-full p-4 border-2 border-gray-200 rounded-lg focus:border-[#4A6B78] focus:outline-none"
                    style={{ fontFamily: 'DM Sans' }}
                    placeholder="List any medications you're currently taking"
                    rows={4}
                  />
                </div>
              </div>

              <div className="flex gap-4 mt-8">
                <button
                  onClick={() => setStep(2)}
                  className="flex-1 py-4 bg-gray-100 text-gray-700 rounded-lg font-bold hover:bg-gray-200 transition-all"
                  style={{ fontFamily: 'DM Sans', fontSize: '16px' }}
                >
                  Back
                </button>
                <button
                  onClick={() => setStep(4)}
                  disabled={!formData.previousAttempts}
                  className="flex-1 py-4 bg-[#4A6B78] text-white rounded-lg font-bold hover:bg-[#3E5147] transition-all disabled:bg-gray-300 disabled:cursor-not-allowed"
                  style={{ fontFamily: 'DM Sans', fontSize: '16px' }}
                >
                  See Results
                </button>
              </div>
            </div>
          )}

          {/* Step 4: Results */}
          {step === 4 && (
            <div className="bg-white border-2 border-gray-200 rounded-2xl p-8">
              {isEligible() ? (
                <div className="text-center">
                  <div className="w-20 h-20 bg-[#55675E] rounded-full flex items-center justify-center mx-auto mb-6">
                    <svg className="w-10 h-10 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M5 13l4 4L19 7" />
                    </svg>
                  </div>
                  
                  <h2 
                    className="text-gray-900 mb-4"
                    style={{ 
                      fontFamily: 'Bebas Neue',
                      fontSize: '36px',
                      letterSpacing: '0.02em'
                    }}
                  >
                    You May Be Eligible for Treatment
                  </h2>
                  
                  <p 
                    className="text-gray-700 mb-8 max-w-lg mx-auto"
                    style={{ fontFamily: 'DM Sans', fontSize: '16px', lineHeight: '1.6' }}
                  >
                    Based on your responses, you may qualify for GLP-1 medication. Schedule a consultation with Dr. Motabhai to discuss your options and determine the best treatment plan.
                  </p>

                  {/* Warning Box */}
                  <div className="bg-red-50 border-2 border-red-300 rounded-xl p-5 mb-6 text-left">
                    <div className="flex items-start gap-3">
                      <svg className="w-6 h-6 text-red-600 flex-shrink-0 mt-0.5" fill="currentColor" viewBox="0 0 20 20">
                        <path fillRule="evenodd" d="M8.257 3.099c.765-1.36 2.722-1.36 3.486 0l5.58 9.92c.75 1.334-.213 2.98-1.742 2.98H4.42c-1.53 0-2.493-1.646-1.743-2.98l5.58-9.92zM11 13a1 1 0 11-2 0 1 1 0 012 0zm-1-8a1 1 0 00-1 1v3a1 1 0 002 0V6a1 1 0 00-1-1z" clipRule="evenodd" />
                      </svg>
                      <div>
                        <h3 
                          className="text-red-800 font-bold mb-2"
                          style={{ fontFamily: 'DM Sans', fontSize: '15px' }}
                        >
                          Important Health Information
                        </h3>
                        <p 
                          className="text-red-900 text-sm"
                          style={{ fontFamily: 'DM Sans', lineHeight: '1.6' }}
                        >
                          Untreated weight issues combined with your current health profile may increase risk for cardiovascular disease, type 2 diabetes, and other metabolic conditions. Early intervention with medical treatment can help manage these risks effectively.
                        </p>
                      </div>
                    </div>
                  </div>

                  {/* Benefits of Medication */}
                  <div className="bg-gradient-to-br from-[#55675E]/10 to-[#4A6B78]/10 border-2 border-[#4A6B78]/30 rounded-xl p-6 mb-6 text-left">
                    <h3 
                      className="text-[#4A6B78] mb-4 flex items-center gap-2"
                      style={{ 
                        fontFamily: 'Bebas Neue',
                        fontSize: '24px',
                        letterSpacing: '0.02em'
                      }}
                    >
                      <svg className="w-6 h-6" fill="currentColor" viewBox="0 0 20 20">
                        <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                      </svg>
                      GLP-1 Medication Benefits
                    </h3>
                    <div className="grid md:grid-cols-2 gap-4">
                      {[
                        { icon: '📉', title: 'Lose 15-20% Body Weight', desc: 'Clinically proven average weight loss' },
                        { icon: '❤️', title: 'Improve Heart Health', desc: 'Reduce cardiovascular risk factors' },
                        { icon: '🍽️', title: 'Control Appetite Naturally', desc: 'Feel full longer, eat less effortlessly' },
                        { icon: '🎯', title: 'Better Blood Sugar', desc: 'Regulate glucose and insulin levels' },
                        { icon: '⚡', title: 'Boost Energy Levels', desc: 'Feel more active and motivated' },
                        { icon: '🎉', title: 'Sustainable Results', desc: 'Long-term weight management solution' }
                      ].map((benefit, i) => (
                        <div 
                          key={i}
                          className="flex items-start gap-3 bg-white/60 p-3 rounded-lg"
                        >
                          <span className="text-2xl flex-shrink-0">{benefit.icon}</span>
                          <div>
                            <p 
                              className="text-gray-900 font-bold"
                              style={{ fontFamily: 'DM Sans', fontSize: '14px' }}
                            >
                              {benefit.title}
                            </p>
                            <p 
                              className="text-gray-600 text-xs"
                              style={{ fontFamily: 'DM Sans' }}
                            >
                              {benefit.desc}
                            </p>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Why Act Now */}
                  <div className="bg-orange-50 border-2 border-orange-200 rounded-xl p-5 mb-8 text-left">
                    <h3 
                      className="text-orange-700 mb-2 flex items-center gap-2"
                      style={{ 
                        fontFamily: 'Bebas Neue',
                        fontSize: '20px',
                        letterSpacing: '0.02em'
                      }}
                    >
                      ⏰ Why Start Now?
                    </h3>
                    <p 
                      className="text-orange-900"
                      style={{ fontFamily: 'DM Sans', fontSize: '14px', lineHeight: '1.6' }}
                    >
                      The sooner you begin treatment, the faster you'll see results. Our patients report feeling more in control of their eating habits within the first week, with noticeable weight loss starting in the first month. Don't wait to feel your best!
                    </p>
                  </div>

                  <div className="bg-gray-50 rounded-xl p-6 mb-8 text-left">
                    <h3 
                      className="text-gray-900 mb-4"
                      style={{ 
                        fontFamily: 'Bebas Neue',
                        fontSize: '24px',
                        letterSpacing: '0.02em'
                      }}
                    >
                      Your Next Steps
                    </h3>
                    <ul className="space-y-3">
                      {[
                        'Complete eligibility assessment (Done! ✅)',
                        'Schedule your free consultation with Dr. Motabhai',
                        'Discuss your health goals and medical history',
                        'Receive your personalized GLP-1 prescription',
                        'Start your transformation journey with ongoing support'
                      ].map((step, i) => (
                        <li 
                          key={i}
                          className="flex items-start text-gray-700"
                          style={{ fontFamily: 'DM Sans', fontSize: '14px' }}
                        >
                          <span className="text-[#4A6B78] mr-3 font-bold text-lg">•</span>
                          <span>{step}</span>
                        </li>
                      ))}
                    </ul>
                  </div>

                  <button
                    className="w-full py-4 bg-[#55675E] text-white rounded-lg font-bold hover:bg-[#3E5147] transition-all shadow-lg mb-3"
                    style={{ fontFamily: 'DM Sans', fontSize: '16px' }}
                  >
                    Schedule Free Consultation
                  </button>
                  <p 
                    className="text-gray-500 text-sm"
                    style={{ fontFamily: 'DM Sans' }}
                  >
                    Free consultation • No obligation • Same-day appointments available
                  </p>
                </div>
              ) : (
                <div className="text-center">
                  <div className="w-20 h-20 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-6">
                    <svg className="w-10 h-10 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                    </svg>
                  </div>
                  
                  <h2 
                    className="text-green-700 mb-4"
                    style={{ 
                      fontFamily: 'Bebas Neue',
                      fontSize: '36px',
                      letterSpacing: '0.02em'
                    }}
                  >
                    Great News!
                  </h2>
                  
                  <p 
                    className="text-gray-800 mb-6 max-w-lg mx-auto font-bold"
                    style={{ fontFamily: 'DM Sans', fontSize: '18px', lineHeight: '1.6' }}
                  >
                    You don't need medication at this time
                  </p>

                  <div className="bg-green-50 border-2 border-green-200 rounded-xl p-6 mb-8 text-left">
                    <h3 
                      className="text-green-700 mb-3"
                      style={{ 
                        fontFamily: 'Bebas Neue',
                        fontSize: '20px',
                        letterSpacing: '0.02em'
                      }}
                    >
                      Your Health Status
                    </h3>
                    <p 
                      className="text-gray-700 mb-4"
                      style={{ fontFamily: 'DM Sans', fontSize: '14px', lineHeight: '1.6' }}
                    >
                      Your BMI is below 25 and you don't have weight-related health conditions that require medical intervention. 
                      This means you're in a good position to maintain a healthy weight through lifestyle choices.
                    </p>
                    <p 
                      className="text-gray-700 font-bold"
                      style={{ fontFamily: 'DM Sans', fontSize: '14px' }}
                    >
                      Recommended: Focus on balanced nutrition and regular exercise to maintain your current health status.
                    </p>
                  </div>

                  <div className="bg-blue-50 border-2 border-blue-200 rounded-xl p-6 mb-8 text-left">
                    <h3 
                      className="text-blue-700 mb-3"
                      style={{ 
                        fontFamily: 'Bebas Neue',
                        fontSize: '20px',
                        letterSpacing: '0.02em'
                      }}
                    >
                      Prevention Tips
                    </h3>
                    <ul className="space-y-2">
                      {[
                        'Maintain a balanced diet with whole foods',
                        'Exercise regularly (150 minutes per week)',
                        'Get adequate sleep (7-9 hours nightly)',
                        'Stay hydrated and limit processed foods',
                        'Regular health checkups with your doctor'
                      ].map((tip, i) => (
                        <li 
                          key={i}
                          className="flex items-start text-gray-700"
                          style={{ fontFamily: 'DM Sans', fontSize: '14px' }}
                        >
                          <span className="text-blue-600 mr-2">✓</span>
                          <span>{tip}</span>
                        </li>
                      ))}
                    </ul>
                  </div>

                  <button
                    className="w-full py-4 bg-[#4A6B78] text-white rounded-lg font-bold hover:bg-[#3E5147] transition-all"
                    style={{ fontFamily: 'DM Sans', fontSize: '16px' }}
                  >
                    Learn About Preventive Care
                  </button>
                </div>
              )}

              <button
                onClick={() => setStep(1)}
                className="w-full mt-4 py-3 text-gray-600 hover:text-gray-900 transition-all"
                style={{ fontFamily: 'DM Sans', fontSize: '14px' }}
              >
                Start Over
              </button>
            </div>
          )}
        </div>
      </section>
      
      <Footer />
    </div>
  );
}