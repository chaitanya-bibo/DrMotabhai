import { useState } from "react";
import { Activity, Bell, Calendar, CheckCircle, ChevronRight, ClipboardList, FileText, MessageSquare, Pill, TrendingUp, Users, Video } from "lucide-react";

export function DoctorDashboardPage() {
  const [activeTab, setActiveTab] = useState("overview");

  const todayStats = {
    consultations: 8,
    pending: 3,
    completed: 5,
    prescriptions: 12,
    labReviews: 6
  };

  const upcomingConsultations = [
    { time: "10:00 AM", patient: "Priya Sharma", mrn: "MRN-0123", type: "Follow-up", weight: "-2kg", duration: "30 min", mode: "Video" },
    { time: "11:00 AM", patient: "Raj Patel", mrn: "MRN-0124", type: "Urgent Review", weight: "-1.5kg", duration: "30 min", mode: "In-person" },
    { time: "2:00 PM", patient: "Anjali Verma", mrn: "MRN-0125", type: "Initial Consultation", weight: "New", duration: "45 min", mode: "Video" }
  ];

  const pendingReviews = [
    { patient: "Vikram Singh", mrn: "MRN-0126", type: "Lab Results", priority: "High", submitted: "2 hours ago" },
    { patient: "Meera Kapoor", mrn: "MRN-0127", type: "Treatment Plan", priority: "Medium", submitted: "5 hours ago" },
    { patient: "Arjun Nair", mrn: "MRN-0128", type: "Medication Adjustment", priority: "Medium", submitted: "1 day ago" }
  ];

  const activePrescriptions = [
    { patient: "Priya Sharma", medication: "Semaglutide 1.0mg", startDate: "Jan 15, 2024", status: "Active", nextRefill: "Feb 15, 2024" },
    { patient: "Raj Patel", medication: "Semaglutide 0.5mg", startDate: "Jan 10, 2024", status: "Active", nextRefill: "Feb 10, 2024" },
    { patient: "Anjali Verma", medication: "Semaglutide 1.0mg", startDate: "Jan 20, 2024", status: "Pending Approval", nextRefill: "-" }
  ];

  const patientList = [
    { name: "Priya Sharma", mrn: "MRN-0123", program: "Complete Care", progress: "12kg lost", compliance: "95%", lastVisit: "Jan 29", status: "Excellent" },
    { name: "Raj Patel", mrn: "MRN-0124", program: "Essential", progress: "8kg lost", compliance: "88%", lastVisit: "Jan 28", status: "Good" },
    { name: "Anjali Verma", mrn: "MRN-0125", program: "Premium Plus", progress: "15kg lost", compliance: "92%", lastVisit: "Jan 27", status: "Excellent" },
    { name: "Vikram Singh", mrn: "MRN-0126", program: "Complete Care", progress: "6kg lost", compliance: "78%", lastVisit: "Jan 26", status: "Needs Attention" }
  ];

  const recentNotes = [
    { patient: "Priya Sharma", date: "Jan 29, 2024", note: "Patient reports good tolerance to current dosage. Continue Semaglutide 1.0mg. Encouraged dietary adherence.", type: "Follow-up" },
    { patient: "Raj Patel", date: "Jan 28, 2024", note: "BP slightly elevated. Discussed lifestyle modifications. Will monitor closely.", type: "Clinical Review" }
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white border-b border-gray-200 sticky top-0 z-50">
        <div className="px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <h1 className="text-2xl font-bold text-gray-900" style={{ fontFamily: 'Bebas Neue' }}>
                DR. MOTABHAI™ Physician Portal
              </h1>
              <span className="px-3 py-1 bg-[#4A6B78] text-white text-sm rounded-full" style={{ fontFamily: 'DM Sans' }}>
                Doctor Dashboard
              </span>
            </div>
            <div className="flex items-center gap-4">
              <button className="relative p-2 hover:bg-gray-100 rounded-full">
                <Bell className="w-5 h-5 text-gray-600" />
                <span className="absolute top-1 right-1 w-2 h-2 bg-red-500 rounded-full"></span>
              </button>
              <div className="flex items-center gap-3">
                <div className="text-right">
                  <p className="text-sm font-semibold" style={{ fontFamily: 'DM Sans' }}>Dr. Rajesh Kumar</p>
                  <p className="text-xs text-gray-500" style={{ fontFamily: 'DM Sans' }}>MD, Endocrinology</p>
                </div>
                <div className="w-10 h-10 bg-[#4A6B78] rounded-full flex items-center justify-center text-white font-bold">
                  RK
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Navigation Tabs */}
        <div className="px-6 flex gap-6 border-t border-gray-200">
          {[
            { id: "overview", label: "Overview", icon: Activity },
            { id: "consultations", label: "Consultations", icon: Video },
            { id: "patients", label: "Patient Management", icon: Users },
            { id: "prescriptions", label: "Prescriptions", icon: Pill },
            { id: "reviews", label: "Pending Reviews", icon: ClipboardList },
            { id: "analytics", label: "Analytics", icon: TrendingUp }
          ].map(tab => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`flex items-center gap-2 px-4 py-3 border-b-2 transition-colors ${
                activeTab === tab.id 
                  ? "border-[#4A6B78] text-[#4A6B78]" 
                  : "border-transparent text-gray-600 hover:text-gray-900"
              }`}
              style={{ fontFamily: 'DM Sans' }}
            >
              <tab.icon className="w-4 h-4" />
              {tab.label}
              {tab.id === "reviews" && (
                <span className="ml-1 px-2 py-0.5 bg-red-500 text-white text-xs rounded-full">3</span>
              )}
            </button>
          ))}
        </div>
      </header>

      {/* Main Content */}
      <main className="p-6 max-w-7xl mx-auto">
        {activeTab === "overview" && (
          <div className="space-y-6">
            {/* Today's Stats */}
            <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
              <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200">
                <div className="flex items-center justify-between mb-2">
                  <Calendar className="w-5 h-5 text-[#4A6B78]" />
                </div>
                <p className="text-3xl font-bold text-gray-900" style={{ fontFamily: 'DM Sans' }}>{todayStats.consultations}</p>
                <p className="text-sm text-gray-500">Today's Consultations</p>
              </div>

              <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200">
                <div className="flex items-center justify-between mb-2">
                  <ClipboardList className="w-5 h-5 text-yellow-600" />
                  <span className="text-xs text-yellow-600 font-semibold">Pending</span>
                </div>
                <p className="text-3xl font-bold text-gray-900" style={{ fontFamily: 'DM Sans' }}>{todayStats.pending}</p>
                <p className="text-sm text-gray-500">Awaiting Action</p>
              </div>

              <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200">
                <div className="flex items-center justify-between mb-2">
                  <CheckCircle className="w-5 h-5 text-green-600" />
                  <span className="text-xs text-green-600 font-semibold">Done</span>
                </div>
                <p className="text-3xl font-bold text-gray-900" style={{ fontFamily: 'DM Sans' }}>{todayStats.completed}</p>
                <p className="text-sm text-gray-500">Completed</p>
              </div>

              <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200">
                <div className="flex items-center justify-between mb-2">
                  <Pill className="w-5 h-5 text-[#55675E]" />
                </div>
                <p className="text-3xl font-bold text-gray-900" style={{ fontFamily: 'DM Sans' }}>{todayStats.prescriptions}</p>
                <p className="text-sm text-gray-500">Active Prescriptions</p>
              </div>

              <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200">
                <div className="flex items-center justify-between mb-2">
                  <FileText className="w-5 h-5 text-[#3E5147]" />
                </div>
                <p className="text-3xl font-bold text-gray-900" style={{ fontFamily: 'DM Sans' }}>{todayStats.labReviews}</p>
                <p className="text-sm text-gray-500">Lab Reviews</p>
              </div>
            </div>

            {/* Main Grid */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* Upcoming Consultations */}
              <div className="bg-white rounded-xl shadow-sm border border-gray-200">
                <div className="p-6 border-b border-gray-200">
                  <h3 className="text-lg font-bold text-gray-900" style={{ fontFamily: 'DM Sans' }}>Today's Consultations</h3>
                </div>
                <div className="divide-y divide-gray-100">
                  {upcomingConsultations.map((consult, idx) => (
                    <div key={idx} className="p-6 hover:bg-gray-50">
                      <div className="flex items-start justify-between mb-3">
                        <div className="flex items-start gap-4">
                          <div className="text-center min-w-[60px]">
                            <p className="text-xl font-bold text-[#4A6B78]">{consult.time.split(':')[0]}</p>
                            <p className="text-xs text-gray-500">{consult.time.split(' ')[1]}</p>
                          </div>
                          <div>
                            <h4 className="font-bold text-gray-900">{consult.patient}</h4>
                            <p className="text-sm text-gray-600">{consult.mrn}</p>
                            <div className="flex items-center gap-2 mt-1">
                              <span className="text-xs bg-blue-100 text-blue-700 px-2 py-0.5 rounded">{consult.type}</span>
                              <span className="text-xs bg-purple-100 text-purple-700 px-2 py-0.5 rounded">{consult.mode}</span>
                            </div>
                          </div>
                        </div>
                        {consult.weight !== "New" && (
                          <span className="text-green-600 font-semibold text-sm">{consult.weight}</span>
                        )}
                      </div>
                      <button className="w-full py-2 bg-[#4A6B78] text-white rounded-lg hover:bg-[#3E5147] text-sm font-medium">
                        Start Consultation
                      </button>
                    </div>
                  ))}
                </div>
              </div>

              {/* Pending Reviews */}
              <div className="bg-white rounded-xl shadow-sm border border-gray-200">
                <div className="p-6 border-b border-gray-200">
                  <h3 className="text-lg font-bold text-gray-900" style={{ fontFamily: 'DM Sans' }}>Pending Reviews</h3>
                </div>
                <div className="divide-y divide-gray-100">
                  {pendingReviews.map((review, idx) => (
                    <div key={idx} className="p-6 hover:bg-gray-50">
                      <div className="flex items-start justify-between mb-3">
                        <div>
                          <h4 className="font-bold text-gray-900">{review.patient}</h4>
                          <p className="text-sm text-gray-600">{review.mrn}</p>
                          <p className="text-sm text-gray-900 mt-1">{review.type}</p>
                          <p className="text-xs text-gray-500 mt-1">{review.submitted}</p>
                        </div>
                        <span className={`px-3 py-1 rounded-full text-xs font-semibold ${
                          review.priority === "High" ? "bg-red-100 text-red-700" : "bg-yellow-100 text-yellow-700"
                        }`}>
                          {review.priority}
                        </span>
                      </div>
                      <button className="text-[#4A6B78] hover:underline text-sm font-semibold">
                        Review Now →
                      </button>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            {/* Recent Clinical Notes */}
            <div className="bg-white rounded-xl shadow-sm border border-gray-200">
              <div className="p-6 border-b border-gray-200">
                <h3 className="text-lg font-bold text-gray-900" style={{ fontFamily: 'DM Sans' }}>Recent Clinical Notes</h3>
              </div>
              <div className="divide-y divide-gray-100">
                {recentNotes.map((note, idx) => (
                  <div key={idx} className="p-6">
                    <div className="flex items-start justify-between mb-2">
                      <div>
                        <h4 className="font-semibold text-gray-900">{note.patient}</h4>
                        <span className="text-xs bg-gray-100 text-gray-700 px-2 py-1 rounded">{note.type}</span>
                      </div>
                      <p className="text-sm text-gray-500">{note.date}</p>
                    </div>
                    <p className="text-sm text-gray-700 leading-relaxed">{note.note}</p>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {activeTab === "patients" && (
          <div className="bg-white rounded-xl shadow-sm border border-gray-200">
            <div className="p-6 border-b border-gray-200">
              <h3 className="text-lg font-bold text-gray-900" style={{ fontFamily: 'DM Sans' }}>Patient Management</h3>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full" style={{ fontFamily: 'DM Sans' }}>
                <thead className="bg-gray-50">
                  <tr>
                    <th className="px-6 py-3 text-left text-xs font-semibold text-gray-600">Patient Name</th>
                    <th className="px-6 py-3 text-left text-xs font-semibold text-gray-600">MRN</th>
                    <th className="px-6 py-3 text-left text-xs font-semibold text-gray-600">Program</th>
                    <th className="px-6 py-3 text-left text-xs font-semibold text-gray-600">Progress</th>
                    <th className="px-6 py-3 text-left text-xs font-semibold text-gray-600">Compliance</th>
                    <th className="px-6 py-3 text-left text-xs font-semibold text-gray-600">Last Visit</th>
                    <th className="px-6 py-3 text-left text-xs font-semibold text-gray-600">Status</th>
                    <th className="px-6 py-3 text-left text-xs font-semibold text-gray-600">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {patientList.map((patient, idx) => (
                    <tr key={idx} className="border-b border-gray-100 hover:bg-gray-50">
                      <td className="px-6 py-4 text-sm font-semibold text-gray-900">{patient.name}</td>
                      <td className="px-6 py-4 text-sm font-mono text-gray-600">{patient.mrn}</td>
                      <td className="px-6 py-4 text-sm text-gray-600">{patient.program}</td>
                      <td className="px-6 py-4 text-sm font-semibold text-green-600">{patient.progress}</td>
                      <td className="px-6 py-4 text-sm text-gray-900">{patient.compliance}</td>
                      <td className="px-6 py-4 text-sm text-gray-600">{patient.lastVisit}</td>
                      <td className="px-6 py-4">
                        <span className={`px-3 py-1 rounded-full text-xs font-semibold ${
                          patient.status === "Excellent" ? "bg-green-100 text-green-700" :
                          patient.status === "Good" ? "bg-blue-100 text-blue-700" :
                          "bg-yellow-100 text-yellow-700"
                        }`}>
                          {patient.status}
                        </span>
                      </td>
                      <td className="px-6 py-4">
                        <button className="text-[#4A6B78] hover:underline text-sm font-semibold">View Chart</button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {activeTab === "prescriptions" && (
          <div className="bg-white rounded-xl shadow-sm border border-gray-200">
            <div className="p-6 border-b border-gray-200 flex items-center justify-between">
              <h3 className="text-lg font-bold text-gray-900" style={{ fontFamily: 'DM Sans' }}>Active Prescriptions</h3>
              <button className="px-4 py-2 bg-[#4A6B78] text-white rounded-lg hover:bg-[#3E5147]">
                New Prescription
              </button>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full" style={{ fontFamily: 'DM Sans' }}>
                <thead className="bg-gray-50">
                  <tr>
                    <th className="px-6 py-3 text-left text-xs font-semibold text-gray-600">Patient</th>
                    <th className="px-6 py-3 text-left text-xs font-semibold text-gray-600">Medication</th>
                    <th className="px-6 py-3 text-left text-xs font-semibold text-gray-600">Start Date</th>
                    <th className="px-6 py-3 text-left text-xs font-semibold text-gray-600">Status</th>
                    <th className="px-6 py-3 text-left text-xs font-semibold text-gray-600">Next Refill</th>
                    <th className="px-6 py-3 text-left text-xs font-semibold text-gray-600">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {activePrescriptions.map((rx, idx) => (
                    <tr key={idx} className="border-b border-gray-100 hover:bg-gray-50">
                      <td className="px-6 py-4 text-sm font-semibold text-gray-900">{rx.patient}</td>
                      <td className="px-6 py-4 text-sm text-gray-900">{rx.medication}</td>
                      <td className="px-6 py-4 text-sm text-gray-600">{rx.startDate}</td>
                      <td className="px-6 py-4">
                        <span className={`px-3 py-1 rounded-full text-xs font-semibold ${
                          rx.status === "Active" ? "bg-green-100 text-green-700" : "bg-yellow-100 text-yellow-700"
                        }`}>
                          {rx.status}
                        </span>
                      </td>
                      <td className="px-6 py-4 text-sm text-gray-600">{rx.nextRefill}</td>
                      <td className="px-6 py-4">
                        <button className="text-[#4A6B78] hover:underline text-sm font-semibold">Manage</button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {activeTab === "analytics" && (
          <div className="space-y-6">
            <div className="bg-gradient-to-br from-[#4A6B78] to-[#3E5147] rounded-xl shadow-lg text-white p-8">
              <h3 className="text-2xl font-bold mb-6" style={{ fontFamily: 'Bebas Neue' }}>Practice Analytics</h3>
              <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
                <div>
                  <p className="text-sm opacity-90 mb-2">Total Active Patients</p>
                  <p className="text-4xl font-bold">24</p>
                </div>
                <div>
                  <p className="text-sm opacity-90 mb-2">Average Weight Loss</p>
                  <p className="text-4xl font-bold">9.5kg</p>
                </div>
                <div>
                  <p className="text-sm opacity-90 mb-2">Patient Compliance Rate</p>
                  <p className="text-4xl font-bold">88%</p>
                </div>
                <div>
                  <p className="text-sm opacity-90 mb-2">Treatment Success Rate</p>
                  <p className="text-4xl font-bold">92%</p>
                </div>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
                <h4 className="font-bold text-gray-900 mb-4">Patient Distribution by Program</h4>
                <div className="space-y-3">
                  <div>
                    <div className="flex justify-between text-sm mb-1">
                      <span>Complete Care</span>
                      <span className="font-semibold">45%</span>
                    </div>
                    <div className="w-full bg-gray-200 rounded-full h-2">
                      <div className="bg-[#4A6B78] h-2 rounded-full" style={{ width: '45%' }}></div>
                    </div>
                  </div>
                  <div>
                    <div className="flex justify-between text-sm mb-1">
                      <span>Premium Plus</span>
                      <span className="font-semibold">30%</span>
                    </div>
                    <div className="w-full bg-gray-200 rounded-full h-2">
                      <div className="bg-[#55675E] h-2 rounded-full" style={{ width: '30%' }}></div>
                    </div>
                  </div>
                  <div>
                    <div className="flex justify-between text-sm mb-1">
                      <span>Essential</span>
                      <span className="font-semibold">25%</span>
                    </div>
                    <div className="w-full bg-gray-200 rounded-full h-2">
                      <div className="bg-[#3E5147] h-2 rounded-full" style={{ width: '25%' }}></div>
                    </div>
                  </div>
                </div>
              </div>

              <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
                <h4 className="font-bold text-gray-900 mb-4">Medication Distribution</h4>
                <div className="space-y-3">
                  <div>
                    <div className="flex justify-between text-sm mb-1">
                      <span>Semaglutide 1.0mg</span>
                      <span className="font-semibold">60%</span>
                    </div>
                    <div className="w-full bg-gray-200 rounded-full h-2">
                      <div className="bg-[#4A6B78] h-2 rounded-full" style={{ width: '60%' }}></div>
                    </div>
                  </div>
                  <div>
                    <div className="flex justify-between text-sm mb-1">
                      <span>Semaglutide 0.5mg</span>
                      <span className="font-semibold">25%</span>
                    </div>
                    <div className="w-full bg-gray-200 rounded-full h-2">
                      <div className="bg-[#55675E] h-2 rounded-full" style={{ width: '25%' }}></div>
                    </div>
                  </div>
                  <div>
                    <div className="flex justify-between text-sm mb-1">
                      <span>Mounjaro</span>
                      <span className="font-semibold">15%</span>
                    </div>
                    <div className="w-full bg-gray-200 rounded-full h-2">
                      <div className="bg-[#3E5147] h-2 rounded-full" style={{ width: '15%' }}></div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}
      </main>
    </div>
  );
}
