import { useState } from "react";
import { ShoppingCart, Star, Info } from "lucide-react";
import { Header } from "@/app/components/header";
import { Footer } from "@/app/components/footer";
import { ImageWithFallback } from "@/app/components/figma/ImageWithFallback";
import { useCart } from "@/app/contexts/cart-context";
import { toast } from "sonner";

export function ProductsPage() {
  const { addItem } = useCart();
  const [activeCategory, setActiveCategory] = useState("All Products");

  const medications = [
    {
      id: "med-1",
      name: "Semaglutide (Ozempic)",
      category: "GLP-1 Medications",
      price: 12500,
      displayPrice: "₹12,500",
      originalPrice: "₹15,000",
      rating: 4.9,
      reviews: 342,
      image: "https://images.unsplash.com/photo-1745940369366-330f0159720d?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxvemVtcGljJTIwc2VtYWdsdXRpZGUlMjBpbmplY3Rpb24lMjBtZWRpY2FsfGVufDF8fHx8MTc3MDEyNTk2NXww&ixlib=rb-4.1.0&q=80&w=1080",
      description: "Once-weekly GLP-1 injection for weight management",
      size: "4 doses (1 month supply)",
      inStock: true,
      bonusIncluded: true
    },
    {
      id: "med-2",
      name: "Tirzepatide (Mounjaro)",
      category: "GLP-1 Medications",
      price: 16500,
      displayPrice: "₹16,500",
      originalPrice: "₹19,500",
      rating: 4.9,
      reviews: 278,
      image: "https://images.unsplash.com/photo-1745940369366-330f0159720d?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxvemVtcGljJTIwc2VtYWdsdXRpZGUlMjBpbmplY3Rpb24lMjBtZWRpY2FsfGVufDF8fHx8MTc3MDEyNTk2NXww&ixlib=rb-4.1.0&q=80&w=1080",
      description: "Dual GLP-1/GIP agonist for enhanced weight loss",
      size: "4 doses (1 month supply)",
      inStock: true,
      bonusIncluded: true
    },
    {
      id: "med-3",
      name: "Compounded Semaglutide",
      category: "GLP-1 Medications",
      price: 8500,
      displayPrice: "₹8,500",
      originalPrice: "₹11,000",
      rating: 4.7,
      reviews: 189,
      image: "https://images.unsplash.com/photo-1745940369366-330f0159720d?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxvemVtcGljJTIwc2VtYWdsdXRpZGUlMjBpbmplY3Rpb24lMjBtZWRpY2FsfGVufDF8fHx8MTc3MDEyNTk2NXww&ixlib=rb-4.1.0&q=80&w=1080",
      description: "Affordable GLP-1 option from licensed pharmacies",
      size: "4 doses (1 month supply)",
      inStock: true,
      bonusIncluded: true
    },
    {
      id: "med-4",
      name: "Orlistat (Alli)",
      category: "Oral Medications",
      price: 3200,
      displayPrice: "₹3,200",
      originalPrice: "₹4,200",
      rating: 4.4,
      reviews: 456,
      image: "https://images.unsplash.com/photo-1611077544218-c93992b06e92?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtZWRpY2F0aW9uJTIwcGlsbHMlMjBjYXBzdWxlcyUyMHdlaWdodCUyMGxvc3N8ZW58MXx8fHwxNzcwMTI1OTY4fDA&ixlib=rb-4.1.0&q=80&w=1080",
      description: "Oral medication that blocks fat absorption",
      size: "90 capsules (1 month supply)",
      inStock: true,
      bonusIncluded: true
    }
  ];

  const wellnessProducts = [
    {
      id: "prod-1",
      name: "Premium Whey Protein Isolate",
      category: "Protein Supplements",
      price: 2499,
      displayPrice: "₹2,499",
      originalPrice: "₹3,499",
      rating: 4.8,
      reviews: 234,
      image: "https://images.unsplash.com/photo-1763757933292-d8290692edde?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwcm90ZWluJTIwcG93ZGVyJTIwc3VwcGxlbWVudCUyMGphcnxlbnwxfHx8fDE3NzAxMjQ3Mjd8MA&ixlib=rb-4.1.0&q=80&w=1080",
      description: "High-quality whey protein isolate with 25g protein per serving",
      size: "1 kg",
      inStock: true
    },
    {
      id: "prod-2",
      name: "High Protein Bars (Box of 12)",
      category: "Protein Snacks",
      price: 899,
      displayPrice: "₹899",
      originalPrice: "₹1,199",
      rating: 4.6,
      reviews: 456,
      image: "https://images.unsplash.com/photo-1679384323883-d5b0b9290e2b?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwcm90ZWluJTIwYmFycyUyMGhlYWx0aHklMjBzbmFja3xlbnwxfHx8fDE3NzAxMjQ3Mjh8MA&ixlib=rb-4.1.0&q=80&w=1080",
      description: "Delicious protein bars with 20g protein and low sugar",
      size: "12 x 60g bars",
      inStock: true
    },
    {
      id: "prod-3",
      name: "Multivitamin Complex",
      category: "Vitamins & Minerals",
      price: 699,
      displayPrice: "₹699",
      originalPrice: "₹999",
      rating: 4.7,
      reviews: 189,
      image: "https://images.unsplash.com/photo-1763668331599-487470fb85b2?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx2aXRhbWlucyUyMHN1cHBsZW1lbnRzJTIwYm90dGxlc3xlbnwxfHx8fDE3NzAwMjU2NTF8MA&ixlib=rb-4.1.0&q=80&w=1080",
      description: "Complete daily multivitamin with essential nutrients",
      size: "60 capsules",
      inStock: true
    },
    {
      id: "prod-4",
      name: "Omega-3 Fish Oil",
      category: "Vitamins & Minerals",
      price: 849,
      displayPrice: "₹849",
      originalPrice: "₹1,099",
      rating: 4.9,
      reviews: 312,
      image: "https://images.unsplash.com/photo-1763668331599-487470fb85b2?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx2aXRhbWlucyUyMHN1cHBsZW1lbnRzJTIwYm90dGxlc3xlbnwxfHx8fDE3NzAwMjU2NTF8MA&ixlib=rb-4.1.0&q=80&w=1080",
      description: "Premium omega-3 supplement for heart and brain health",
      size: "90 softgels",
      inStock: true
    },
    {
      id: "prod-5",
      name: "Plant-Based Protein Powder",
      category: "Protein Supplements",
      price: 1999,
      displayPrice: "₹1,999",
      originalPrice: "₹2,799",
      rating: 4.5,
      reviews: 167,
      image: "https://images.unsplash.com/photo-1763757933292-d8290692edde?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwcm90ZWluJTIwcG93ZGVyJTIwc3VwcGxlbWVudCUyMGphcnxlbnwxfHx8fDE3NzAxMjQ3Mjd8MA&ixlib=rb-4.1.0&q=80&w=1080",
      description: "Vegan protein blend with 22g protein per serving",
      size: "900g",
      inStock: true
    },
    {
      id: "prod-6",
      name: "Continuous Glucose Monitor (CGM)",
      category: "Medical Devices",
      price: 3200,
      displayPrice: "₹3,200",
      originalPrice: "₹4,500",
      rating: 4.9,
      reviews: 89,
      image: "https://images.unsplash.com/photo-1766325693829-79d0b13a545e?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxnbHVjb3NlJTIwbW9uaXRvciUyMG1lZGljYWwlMjBkZXZpY2V8ZW58MXx8fHwxNzcwMTI0NzI5fDA&ixlib=rb-4.1.0&q=80&w=1080",
      description: "Real-time glucose monitoring with mobile app integration",
      size: "14-day sensor",
      inStock: true
    },
    {
      id: "prod-7",
      name: "Collagen Peptides",
      category: "Protein Supplements",
      price: 1599,
      displayPrice: "₹1,599",
      originalPrice: "₹2,199",
      rating: 4.6,
      reviews: 203,
      image: "https://images.unsplash.com/photo-1763757933292-d8290692edde?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwcm90ZWluJTIwcG93ZGVyJTIwc3VwcGxlbWVudCUyMGphcnxlbnwxfHx8fDE3NzAxMjQ3Mjd8MA&ixlib=rb-4.1.0&q=80&w=1080",
      description: "Hydrolyzed collagen for skin, hair, and joint health",
      size: "500g",
      inStock: true
    },
    {
      id: "prod-8",
      name: "Sugar-Free Protein Cookies (Box of 6)",
      category: "Protein Snacks",
      price: 599,
      displayPrice: "₹599",
      originalPrice: "₹799",
      rating: 4.4,
      reviews: 278,
      image: "https://images.unsplash.com/photo-1679384323883-d5b0b9290e2b?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwcm90ZWluJTIwYmFycyUyMGhlYWx0aHklMjBzbmFja3xlbnwxfHx8fDE3NzAxMjQ3Mjh8MA&ixlib=rb-4.1.0&q=80&w=1080",
      description: "Guilt-free protein cookies with 12g protein each",
      size: "6 x 50g cookies",
      inStock: true
    },
    {
      id: "prod-9",
      name: "Vitamin D3 + K2",
      category: "Vitamins & Minerals",
      price: 549,
      displayPrice: "₹549",
      originalPrice: "₹749",
      rating: 4.8,
      reviews: 421,
      image: "https://images.unsplash.com/photo-1763668331599-487470fb85b2?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx2aXRhbWlucyUyMHN1cHBsZW1lbnRzJTIwYm90dGxlc3xlbnwxfHx8fDE3NzAwMjU2NTF8MA&ixlib=rb-4.1.0&q=80&w=1080",
      description: "Essential vitamin D and K for bone health and immunity",
      size: "60 tablets",
      inStock: true
    }
  ];

  const categories = [
    "All Products",
    "GLP-1 Medications",
    "Oral Medications",
    "Protein Supplements",
    "Protein Snacks",
    "Vitamins & Minerals",
    "Medical Devices"
  ];

  const allProducts = [...medications, ...wellnessProducts];
  
  const filteredProducts = activeCategory === "All Products"
    ? allProducts
    : allProducts.filter(p => p.category === activeCategory);

  const handleAddToCart = (product: any) => {
    addItem({
      id: product.id,
      name: product.name,
      price: product.price,
      quantity: 1,
      type: product.id.startsWith('med') ? 'medication' : 'product',
      image: product.image,
      description: product.description,
      category: product.category
    });
    toast.success(`${product.name} added to cart!`);
  };

  return (
    <div className="min-h-screen bg-white">
      <Header />
      
      {/* Hero Section */}
      <section className="pt-32 pb-12 bg-gradient-to-b from-[#4A6B78]/10 to-white">
        <div className="container mx-auto px-4 lg:px-8 max-w-7xl">
          <div className="text-center mb-8">
            <h1 
              className="text-gray-900 mb-4"
              style={{ 
                fontFamily: 'Bebas Neue',
                fontSize: 'clamp(48px, 8vw, 72px)',
                lineHeight: '1',
                letterSpacing: '0.02em'
              }}
            >
              Shop Medications & Wellness Products
            </h1>
            <p 
              className="text-gray-600 max-w-2xl mx-auto"
              style={{ 
                fontFamily: 'DM Sans',
                fontSize: '18px',
                lineHeight: '1.6'
              }}
            >
              Purchase medications directly or browse premium supplements and health products. No prescription required for wellness items.
            </p>
          </div>

          {/* Category Filter */}
          <div className="flex flex-wrap justify-center gap-3 mb-12">
            {categories.map((category, index) => (
              <button
                key={index}
                onClick={() => setActiveCategory(category)}
                className={`px-6 py-2 rounded-full transition-all ${
                  category === activeCategory
                    ? 'bg-[#4A6B78] text-white' 
                    : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                }`}
                style={{ 
                  fontFamily: 'DM Sans',
                  fontSize: '14px',
                  fontWeight: '500'
                }}
              >
                {category}
              </button>
            ))}
          </div>
        </div>
      </section>

      {/* Medications Section */}
      {(activeCategory === "All Products" || activeCategory === "GLP-1 Medications" || activeCategory === "Oral Medications") && (
        <section className="py-8 bg-gradient-to-b from-[#E8BFB8]/10 to-white">
          <div className="container mx-auto px-4 lg:px-8 max-w-7xl">
            <div className="bg-[#4A6B78] rounded-2xl p-6 mb-8">
              <div className="flex items-start gap-3">
                <Info className="w-5 h-5 text-white mt-0.5 flex-shrink-0" />
                <div>
                  <p className="text-white font-semibold mb-1" style={{ fontFamily: 'DM Sans', fontSize: '16px' }}>
                    First Purchase Bonus
                  </p>
                  <p className="text-white/90 text-sm" style={{ fontFamily: 'DM Sans', lineHeight: '1.6' }}>
                    Get complimentary generic fitness plan, nutrition guide, and medical wellness chart with your first medication purchase.{' '}
                    <span className="text-white/70 text-xs italic">Plans are provided as general wellness information only.</span>
                  </p>
                </div>
              </div>
            </div>

            <h2 
              className="text-gray-900 mb-6"
              style={{ 
                fontFamily: 'Bebas Neue',
                fontSize: 'clamp(32px, 5vw, 48px)',
                letterSpacing: '0.02em'
              }}
            >
              Weight Loss Medications
            </h2>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
              {medications
                .filter(med => activeCategory === "All Products" || med.category === activeCategory)
                .map((product) => (
                <div
                  key={product.id}
                  className="bg-white border-2 border-[#4A6B78]/20 rounded-2xl overflow-hidden hover:border-[#4A6B78] transition-all hover:shadow-lg group"
                >
                  <div className="relative h-48 bg-gray-100 overflow-hidden">
                    <ImageWithFallback
                      src={product.image}
                      alt={product.name}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                    />
                    <div className="absolute top-3 right-3 bg-[#E8BFB8] px-2 py-1 rounded-full">
                      <span 
                        className="text-gray-900 font-bold text-xs"
                        style={{ fontFamily: 'DM Sans' }}
                      >
                        BONUS
                      </span>
                    </div>
                  </div>

                  <div className="p-5">
                    <p 
                      className="text-[#4A6B78] text-xs uppercase tracking-wider mb-2"
                      style={{ 
                        fontFamily: 'DM Sans',
                        letterSpacing: '0.1em'
                      }}
                    >
                      {product.category}
                    </p>
                    
                    <h3 
                      className="text-gray-900 mb-2"
                      style={{ 
                        fontFamily: 'DM Sans',
                        fontSize: '16px',
                        fontWeight: '600',
                        lineHeight: '1.4'
                      }}
                    >
                      {product.name}
                    </h3>
                    
                    <p 
                      className="text-gray-600 text-sm mb-3"
                      style={{ 
                        fontFamily: 'DM Sans',
                        lineHeight: '1.5'
                      }}
                    >
                      {product.description}
                    </p>

                    <p 
                      className="text-gray-500 text-xs mb-3"
                      style={{ fontFamily: 'DM Sans' }}
                    >
                      {product.size}
                    </p>

                    <div className="flex items-center gap-2 mb-3">
                      <div className="flex items-center">
                        <Star className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                        <span 
                          className="ml-1 text-gray-900 font-semibold text-sm"
                          style={{ fontFamily: 'DM Sans' }}
                        >
                          {product.rating}
                        </span>
                      </div>
                      <span 
                        className="text-gray-500 text-xs"
                        style={{ fontFamily: 'DM Sans' }}
                      >
                        ({product.reviews})
                      </span>
                    </div>

                    <div className="flex items-center justify-between mb-3">
                      <div>
                        <span 
                          className="text-[#4A6B78] font-bold text-xl"
                          style={{ fontFamily: 'DM Sans' }}
                        >
                          {product.displayPrice}
                        </span>
                        {product.originalPrice && (
                          <span 
                            className="ml-2 text-gray-400 line-through text-sm"
                            style={{ fontFamily: 'DM Sans' }}
                          >
                            {product.originalPrice}
                          </span>
                        )}
                      </div>
                    </div>

                    <button 
                      onClick={() => handleAddToCart(product)}
                      className="w-full py-2.5 bg-[#4A6B78] text-white rounded-lg font-bold hover:bg-[#3E5147] transition-all flex items-center justify-center gap-2"
                      style={{ fontFamily: 'DM Sans', fontSize: '14px' }}
                    >
                      <ShoppingCart className="w-4 h-4" />
                      Add to Cart
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </section>
      )}

      {/* Wellness Products Section */}
      <section className="py-12 bg-white">
        <div className="container mx-auto px-4 lg:px-8 max-w-7xl">
          {(activeCategory === "All Products") && (
            <h2 
              className="text-gray-900 mb-6"
              style={{ 
                fontFamily: 'Bebas Neue',
                fontSize: 'clamp(32px, 5vw, 48px)',
                letterSpacing: '0.02em'
              }}
            >
              Wellness Supplements
            </h2>
          )}

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {wellnessProducts
              .filter(prod => activeCategory === "All Products" || prod.category === activeCategory)
              .map((product) => (
              <div
                key={product.id}
                className="bg-white border-2 border-gray-200 rounded-2xl overflow-hidden hover:border-[#4A6B78] transition-all hover:shadow-lg group"
              >
                <div className="relative h-64 bg-gray-100 overflow-hidden">
                  <ImageWithFallback
                    src={product.image}
                    alt={product.name}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                  />
                  {product.originalPrice && (
                    <div className="absolute top-4 right-4 bg-[#E8BFB8] px-3 py-1 rounded-full">
                      <span 
                        className="text-gray-900 font-bold text-xs"
                        style={{ fontFamily: 'DM Sans' }}
                      >
                        SALE
                      </span>
                    </div>
                  )}
                </div>

                <div className="p-6">
                  <p 
                    className="text-[#4A6B78] text-xs uppercase tracking-wider mb-2"
                    style={{ 
                      fontFamily: 'DM Sans',
                      letterSpacing: '0.1em'
                    }}
                  >
                    {product.category}
                  </p>
                  
                  <h3 
                    className="text-gray-900 mb-2"
                    style={{ 
                      fontFamily: 'DM Sans',
                      fontSize: '18px',
                      fontWeight: '600',
                      lineHeight: '1.4'
                    }}
                  >
                    {product.name}
                  </h3>
                  
                  <p 
                    className="text-gray-600 text-sm mb-3"
                    style={{ 
                      fontFamily: 'DM Sans',
                      lineHeight: '1.5'
                    }}
                  >
                    {product.description}
                  </p>

                  <p 
                    className="text-gray-500 text-xs mb-4"
                    style={{ fontFamily: 'DM Sans' }}
                  >
                    Size: {product.size}
                  </p>

                  <div className="flex items-center gap-2 mb-4">
                    <div className="flex items-center">
                      <Star className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                      <span 
                        className="ml-1 text-gray-900 font-semibold text-sm"
                        style={{ fontFamily: 'DM Sans' }}
                      >
                        {product.rating}
                      </span>
                    </div>
                    <span 
                      className="text-gray-500 text-xs"
                      style={{ fontFamily: 'DM Sans' }}
                    >
                      ({product.reviews} reviews)
                    </span>
                  </div>

                  <div className="flex items-center justify-between">
                    <div>
                      <span 
                        className="text-[#4A6B78] font-bold text-2xl"
                        style={{ fontFamily: 'DM Sans' }}
                      >
                        {product.displayPrice}
                      </span>
                      {product.originalPrice && (
                        <span 
                          className="ml-2 text-gray-400 line-through text-sm"
                          style={{ fontFamily: 'DM Sans' }}
                        >
                          {product.originalPrice}
                        </span>
                      )}
                    </div>
                  </div>

                  <button 
                    onClick={() => handleAddToCart(product)}
                    className="w-full mt-4 py-3 bg-[#4A6B78] text-white rounded-lg font-bold hover:bg-[#3E5147] transition-all flex items-center justify-center gap-2"
                    style={{ fontFamily: 'DM Sans', fontSize: '14px' }}
                  >
                    <ShoppingCart className="w-4 h-4" />
                    Add to Cart
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Info Banner */}
      <section className="py-16 bg-[#4A6B78]">
        <div className="container mx-auto px-4 lg:px-8 max-w-5xl text-center">
          <h2 
            className="text-white mb-4"
            style={{ 
              fontFamily: 'Bebas Neue',
              fontSize: 'clamp(32px, 5vw, 48px)',
              letterSpacing: '0.02em'
            }}
          >
            Shop With Confidence
          </h2>
          <p 
            className="text-white/90 max-w-2xl mx-auto"
            style={{ 
              fontFamily: 'DM Sans',
              fontSize: '16px',
              lineHeight: '1.6'
            }}
          >
            All wellness products can be purchased directly without consultation. Medications include complimentary generic wellness guides on first purchase. For supervised treatment plans with personalized medical guidance, visit our Pricing page.
          </p>
        </div>
      </section>

      <Footer />
    </div>
  );
}
