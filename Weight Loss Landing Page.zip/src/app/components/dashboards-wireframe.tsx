import { Link } from "react-router";

export function DashboardsWireframe() {
  return (
    <div className="min-h-screen bg-gray-50 p-8" style={{ fontFamily: 'DM Sans' }}>
      <div className="max-w-7xl mx-auto space-y-8">
        {/* Title */}
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold mb-2">Dr. MOTABHAI - Dashboard Systems Wireframe</h1>
          <p className="text-gray-600">Complete Multi-Dashboard Healthcare Management System</p>
          <p className="text-sm text-gray-500 mt-2">3 Unified Dashboard Systems with Dedicated Access</p>
          
          <div className="mt-6 flex flex-wrap gap-2 justify-center">
            <Link to="/" className="px-4 py-2 bg-gray-500 text-white rounded-lg text-sm hover:bg-gray-600">← Back to Website</Link>
            <Link to="/dashboard/patient" className="px-4 py-2 bg-blue-500 text-white rounded-lg text-sm hover:bg-blue-600">Patient EMR</Link>
            <Link to="/dashboard/doctor" className="px-4 py-2 bg-purple-500 text-white rounded-lg text-sm hover:bg-purple-600">Doctor Dashboard</Link>
            <Link to="/dashboard/manager" className="px-4 py-2 bg-green-500 text-white rounded-lg text-sm hover:bg-green-600">Manager Dashboard</Link>
          </div>
          
          <div className="mt-4 bg-green-100 border-2 border-green-500 rounded-lg p-4 max-w-3xl mx-auto">
            <p className="text-sm font-bold text-green-800 mb-2">✓ Consolidated Dashboard System</p>
            <p className="text-xs text-green-700">
              The Manager Dashboard has been consolidated to combine Admin, Clinical Staff (Nurse), and Vendor management functions into one unified portal with 10 comprehensive tabs. This reduces complexity while maintaining 100% of original functionality.
            </p>
            <p className="text-xs text-green-700 mt-2">
              ★ All three dashboards are now accessible from the FAQ page under the "Healthcare Portals" section with direct navigation buttons.
            </p>
          </div>
        </div>

        {/* System Architecture */}
        <section className="bg-gradient-to-br from-indigo-600 to-purple-600 rounded-lg p-8 shadow-2xl text-white">
          <h2 className="text-3xl font-bold mb-6 text-center">System Architecture Overview</h2>
          
          <div className="bg-white/10 backdrop-blur-sm rounded-lg p-6">
            <div className="flex flex-col items-center gap-4">
              {/* Central System */}
              <div className="bg-black/30 rounded-lg p-6 text-center w-full max-w-md">
                <p className="font-bold text-2xl mb-2">DR. MOTABHAI™</p>
                <p className="text-sm">Healthcare Management Platform</p>
              </div>

              {/* Dashboard Grid */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6 w-full mt-4">
                <div className="bg-blue-500/40 backdrop-blur-sm rounded-lg p-4 border-2 border-white/50">
                  <p className="font-bold text-sm mb-2 text-center">PATIENT EMR</p>
                  <div className="space-y-1 text-xs">
                    <div className="bg-white/20 p-2 rounded">Medical Records</div>
                    <div className="bg-white/20 p-2 rounded">Vitals Tracking</div>
                    <div className="bg-white/20 p-2 rounded">Appointments</div>
                    <div className="bg-white/20 p-2 rounded">Medications</div>
                  </div>
                </div>

                <div className="bg-purple-500/40 backdrop-blur-sm rounded-lg p-4 border-2 border-white/50">
                  <p className="font-bold text-sm mb-2 text-center">DOCTOR PORTAL</p>
                  <div className="space-y-1 text-xs">
                    <div className="bg-white/20 p-2 rounded">Consultations</div>
                    <div className="bg-white/20 p-2 rounded">Prescriptions</div>
                    <div className="bg-white/20 p-2 rounded">Patient Mgmt</div>
                    <div className="bg-white/20 p-2 rounded">Analytics</div>
                  </div>
                </div>

                <div className="bg-green-500/40 backdrop-blur-sm rounded-lg p-4 border-2 border-white/50">
                  <p className="font-bold text-sm mb-2 text-center">MANAGER PORTAL</p>
                  <p className="text-[10px] mb-2 text-center italic">(Unified: Admin + Nurse + Vendor)</p>
                  <div className="space-y-1 text-xs">
                    <div className="bg-white/20 p-2 rounded">User Management</div>
                    <div className="bg-white/20 p-2 rounded">Patient Care</div>
                    <div className="bg-white/20 p-2 rounded">Billing & Finance</div>
                    <div className="bg-white/20 p-2 rounded">Inventory</div>
                    <div className="bg-white/20 p-2 rounded">Vendor Orders</div>
                    <div className="bg-white/20 p-2 rounded">Analytics</div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* PATIENT EMR - Detailed Wireframe */}
        <section className="bg-white rounded-lg p-6 border-4 border-blue-500 shadow-lg">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-2xl font-bold text-blue-600">PATIENT EMR - Electronic Medical Record</h2>
            <span className="text-sm text-gray-500">Patient Portal</span>
          </div>

          <div className="space-y-4">
            {/* Navigation */}
            <div className="bg-blue-50 rounded p-4">
              <p className="font-bold mb-2 text-sm">Navigation Tabs:</p>
              <div className="flex flex-wrap gap-2">
                <span className="bg-blue-500 text-white px-3 py-1 rounded text-xs">Overview</span>
                <span className="bg-gray-200 px-3 py-1 rounded text-xs">Vitals & Tracking</span>
                <span className="bg-gray-200 px-3 py-1 rounded text-xs">Medications</span>
                <span className="bg-gray-200 px-3 py-1 rounded text-xs">Appointments</span>
                <span className="bg-gray-200 px-3 py-1 rounded text-xs">Lab Results</span>
                <span className="bg-gray-200 px-3 py-1 rounded text-xs">Messages</span>
              </div>
            </div>

            {/* Features */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
              <div className="bg-gray-50 rounded p-3 border border-gray-200">
                <p className="font-bold text-xs mb-2 text-blue-600">Personal Health Data</p>
                <ul className="text-[10px] space-y-1 text-gray-600">
                  <li>• Weight tracking chart</li>
                  <li>• BMI calculations</li>
                  <li>• Progress metrics</li>
                  <li>• Goal visualization</li>
                </ul>
              </div>
              <div className="bg-gray-50 rounded p-3 border border-gray-200">
                <p className="font-bold text-xs mb-2 text-blue-600">Vitals Management</p>
                <ul className="text-[10px] space-y-1 text-gray-600">
                  <li>• Blood pressure log</li>
                  <li>• Blood glucose tracking</li>
                  <li>• Heart rate monitor</li>
                  <li>• Manual entry forms</li>
                </ul>
              </div>
              <div className="bg-gray-50 rounded p-3 border border-gray-200">
                <p className="font-bold text-xs mb-2 text-blue-600">Medication Tracking</p>
                <ul className="text-[10px] space-y-1 text-gray-600">
                  <li>• Active prescriptions</li>
                  <li>• Dosage schedules</li>
                  <li>• Refill reminders</li>
                  <li>• Instruction guides</li>
                </ul>
              </div>
              <div className="bg-gray-50 rounded p-3 border border-gray-200">
                <p className="font-bold text-xs mb-2 text-blue-600">Communication</p>
                <ul className="text-[10px] space-y-1 text-gray-600">
                  <li>• Secure messaging</li>
                  <li>• Doctor consultation</li>
                  <li>• Appointment booking</li>
                  <li>• Document uploads</li>
                </ul>
              </div>
            </div>

            <div className="bg-blue-100 rounded p-3 text-xs italic text-blue-900">
              ★ Patient-facing portal with complete medical history, treatment tracking, and secure communication
            </div>
          </div>
        </section>

        {/* DOCTOR DASHBOARD - Detailed Wireframe */}
        <section className="bg-white rounded-lg p-6 border-4 border-purple-500 shadow-lg">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-2xl font-bold text-purple-600">DOCTOR DASHBOARD - Physician Portal</h2>
            <span className="text-sm text-gray-500">Medical Providers</span>
          </div>

          <div className="space-y-4">
            {/* Navigation */}
            <div className="bg-purple-50 rounded p-4">
              <p className="font-bold mb-2 text-sm">Navigation Tabs:</p>
              <div className="flex flex-wrap gap-2">
                <span className="bg-purple-500 text-white px-3 py-1 rounded text-xs">Overview</span>
                <span className="bg-gray-200 px-3 py-1 rounded text-xs">Consultations</span>
                <span className="bg-gray-200 px-3 py-1 rounded text-xs">Patient Management</span>
                <span className="bg-gray-200 px-3 py-1 rounded text-xs">Prescriptions</span>
                <span className="bg-gray-200 px-3 py-1 rounded text-xs">Pending Reviews (3)</span>
                <span className="bg-gray-200 px-3 py-1 rounded text-xs">Analytics</span>
              </div>
            </div>

            {/* Features */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
              <div className="bg-gray-50 rounded p-3 border border-gray-200">
                <p className="font-bold text-xs mb-2 text-purple-600">Consultation Management</p>
                <ul className="text-[10px] space-y-1 text-gray-600">
                  <li>• Video consultations</li>
                  <li>• Patient history review</li>
                  <li>• Progress tracking</li>
                  <li>• Clinical notes entry</li>
                </ul>
              </div>
              <div className="bg-gray-50 rounded p-3 border border-gray-200">
                <p className="font-bold text-xs mb-2 text-purple-600">Prescription System</p>
                <ul className="text-[10px] space-y-1 text-gray-600">
                  <li>• GLP-1 prescriptions</li>
                  <li>• Dosage adjustments</li>
                  <li>• Drug interactions</li>
                  <li>• E-prescribing</li>
                </ul>
              </div>
              <div className="bg-gray-50 rounded p-3 border border-gray-200">
                <p className="font-bold text-xs mb-2 text-purple-600">Patient Analytics</p>
                <ul className="text-[10px] space-y-1 text-gray-600">
                  <li>• Weight loss trends</li>
                  <li>• Compliance rates</li>
                  <li>• Success metrics</li>
                  <li>• Treatment outcomes</li>
                </ul>
              </div>
              <div className="bg-gray-50 rounded p-3 border border-gray-200">
                <p className="font-bold text-xs mb-2 text-purple-600">Review Workflow</p>
                <ul className="text-[10px] space-y-1 text-gray-600">
                  <li>• Lab result reviews</li>
                  <li>• Treatment plan updates</li>
                  <li>• Medication approvals</li>
                  <li>• Clinical documentation</li>
                </ul>
              </div>
            </div>

            <div className="bg-purple-100 rounded p-3 text-xs italic text-purple-900">
              ★ Physician portal for consultations, prescriptions, patient management, and clinical analytics
            </div>
          </div>
        </section>

        {/* MANAGER DASHBOARD - Detailed Wireframe (Consolidated) */}
        <section className="bg-white rounded-lg p-6 border-4 border-green-500 shadow-lg">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-2xl font-bold text-green-600">MANAGER DASHBOARD - Unified Operations Portal</h2>
            <span className="text-sm text-gray-500">Operations Management</span>
          </div>

          <div className="bg-green-50 rounded p-4 mb-4">
            <p className="font-bold text-sm mb-2">📊 UNIFIED SYSTEM - Consolidates Admin + Nurse + Vendor Functions</p>
            <p className="text-xs text-gray-700">This comprehensive dashboard combines administrative operations, clinical staff workflows, and vendor management into one powerful management interface.</p>
          </div>

          <div className="space-y-4">
            {/* Navigation */}
            <div className="bg-green-50 rounded p-4">
              <p className="font-bold mb-2 text-sm">Navigation Tabs:</p>
              <div className="flex flex-wrap gap-2">
                <span className="bg-green-500 text-white px-3 py-1 rounded text-xs">Overview</span>
                <span className="bg-gray-200 px-3 py-1 rounded text-xs">Users & Staff</span>
                <span className="bg-gray-200 px-3 py-1 rounded text-xs">Patient Care</span>
                <span className="bg-gray-200 px-3 py-1 rounded text-xs">Schedule</span>
                <span className="bg-gray-200 px-3 py-1 rounded text-xs">Billing</span>
                <span className="bg-gray-200 px-3 py-1 rounded text-xs">Inventory</span>
                <span className="bg-gray-200 px-3 py-1 rounded text-xs">Vendors</span>
                <span className="bg-gray-200 px-3 py-1 rounded text-xs">Analytics</span>
                <span className="bg-gray-200 px-3 py-1 rounded text-xs">Messages</span>
                <span className="bg-gray-200 px-3 py-1 rounded text-xs">Settings</span>
              </div>
            </div>

            {/* Features - Organized by Function Area */}
            <div className="space-y-4">
              {/* Administrative Functions (formerly Admin Dashboard) */}
              <div className="bg-red-50 rounded-lg p-4">
                <h3 className="font-bold text-sm mb-3 text-red-700">🔴 ADMINISTRATIVE FUNCTIONS</h3>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                  <div className="bg-white rounded p-3 border border-red-200">
                    <p className="font-bold text-xs mb-2 text-red-600">User Management</p>
                    <ul className="text-[10px] space-y-1 text-gray-600">
                      <li>• Add/edit users</li>
                      <li>• Role assignments</li>
                      <li>• Access control</li>
                      <li>• Activity logs</li>
                    </ul>
                  </div>
                  <div className="bg-white rounded p-3 border border-red-200">
                    <p className="font-bold text-xs mb-2 text-red-600">Billing System</p>
                    <ul className="text-[10px] space-y-1 text-gray-600">
                      <li>• Revenue tracking (₹)</li>
                      <li>• Payment processing</li>
                      <li>• Overdue management</li>
                      <li>• Financial reports</li>
                    </ul>
                  </div>
                  <div className="bg-white rounded p-3 border border-red-200">
                    <p className="font-bold text-xs mb-2 text-red-600">System Analytics</p>
                    <ul className="text-[10px] space-y-1 text-gray-600">
                      <li>• Patient growth metrics</li>
                      <li>• Revenue analytics</li>
                      <li>• Performance KPIs</li>
                      <li>• Custom reports</li>
                    </ul>
                  </div>
                  <div className="bg-white rounded p-3 border border-red-200">
                    <p className="font-bold text-xs mb-2 text-red-600">System Settings</p>
                    <ul className="text-[10px] space-y-1 text-gray-600">
                      <li>• Configuration</li>
                      <li>• Integrations</li>
                      <li>• Security settings</li>
                      <li>• Backup management</li>
                    </ul>
                  </div>
                </div>
              </div>

              {/* Clinical Staff Functions (formerly Nurse Dashboard) */}
              <div className="bg-blue-50 rounded-lg p-4">
                <h3 className="font-bold text-sm mb-3 text-blue-700">🔵 CLINICAL OPERATIONS</h3>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                  <div className="bg-white rounded p-3 border border-blue-200">
                    <p className="font-bold text-xs mb-2 text-blue-600">Patient Monitoring</p>
                    <ul className="text-[10px] space-y-1 text-gray-600">
                      <li>• Real-time patient list</li>
                      <li>• Priority flagging</li>
                      <li>• Vitals due tracking</li>
                      <li>• Quick chart access</li>
                    </ul>
                  </div>
                  <div className="bg-white rounded p-3 border border-blue-200">
                    <p className="font-bold text-xs mb-2 text-blue-600">Vitals Recording</p>
                    <ul className="text-[10px] space-y-1 text-gray-600">
                      <li>• Queue management</li>
                      <li>• Vital sign entry</li>
                      <li>• Overdue alerts</li>
                      <li>• Historical comparison</li>
                    </ul>
                  </div>
                  <div className="bg-white rounded p-3 border border-blue-200">
                    <p className="font-bold text-xs mb-2 text-blue-600">Medication Admin</p>
                    <ul className="text-[10px] space-y-1 text-gray-600">
                      <li>• Med administration log</li>
                      <li>• Scheduled doses</li>
                      <li>• Safety checks</li>
                      <li>• Documentation</li>
                    </ul>
                  </div>
                  <div className="bg-white rounded p-3 border border-blue-200">
                    <p className="font-bold text-xs mb-2 text-blue-600">Alert System</p>
                    <ul className="text-[10px] space-y-1 text-gray-600">
                      <li>• High priority alerts</li>
                      <li>• Vital abnormalities</li>
                      <li>• Patient reports</li>
                      <li>• Follow-up tasks</li>
                    </ul>
                  </div>
                </div>
              </div>

              {/* Vendor Management Functions (formerly Vendor Dashboard) */}
              <div className="bg-orange-50 rounded-lg p-4">
                <h3 className="font-bold text-sm mb-3 text-orange-700">🟠 VENDOR & SUPPLY CHAIN</h3>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                  <div className="bg-white rounded p-3 border border-orange-200">
                    <p className="font-bold text-xs mb-2 text-orange-600">Order Management</p>
                    <ul className="text-[10px] space-y-1 text-gray-600">
                      <li>• Pending orders view</li>
                      <li>• Order confirmation</li>
                      <li>• Status updates</li>
                      <li>• Order history</li>
                    </ul>
                  </div>
                  <div className="bg-white rounded p-3 border border-orange-200">
                    <p className="font-bold text-xs mb-2 text-orange-600">Delivery Tracking</p>
                    <ul className="text-[10px] space-y-1 text-gray-600">
                      <li>• Shipment scheduling</li>
                      <li>• Delivery confirmation</li>
                      <li>• Performance metrics</li>
                      <li>• Delivery history</li>
                    </ul>
                  </div>
                  <div className="bg-white rounded p-3 border border-orange-200">
                    <p className="font-bold text-xs mb-2 text-orange-600">Inventory Control</p>
                    <ul className="text-[10px] space-y-1 text-gray-600">
                      <li>• Medication stock</li>
                      <li>• Reorder alerts</li>
                      <li>• Supplier management</li>
                      <li>• Stock reports</li>
                    </ul>
                  </div>
                  <div className="bg-white rounded p-3 border border-orange-200">
                    <p className="font-bold text-xs mb-2 text-orange-600">Invoicing System</p>
                    <ul className="text-[10px] space-y-1 text-gray-600">
                      <li>• Vendor invoices</li>
                      <li>• Payment tracking (₹)</li>
                      <li>• Expense reports</li>
                      <li>• Download invoices</li>
                    </ul>
                  </div>
                </div>
              </div>
            </div>

            <div className="bg-green-100 rounded p-3 text-xs italic text-green-900">
              ★ Unified management portal combining administrative operations, clinical staff workflows, and vendor/supply chain management into one comprehensive interface. Reduces complexity while maintaining full functionality across all management areas.
            </div>
          </div>
        </section>

        {/* Technical Specifications */}
        <section className="bg-gradient-to-br from-blue-500 to-indigo-600 rounded-lg p-8 shadow-2xl text-white">
          <h3 className="text-2xl font-bold mb-6">Technical Specifications & Features</h3>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {/* Security */}
            <div className="bg-white/10 backdrop-blur-sm rounded-lg p-4">
              <h4 className="font-bold mb-3 text-lg">Security & Access Control</h4>
              <ul className="space-y-2 text-sm">
                <li>✓ Role-based access control (RBAC)</li>
                <li>✓ Separate login portals</li>
                <li>✓ Session management</li>
                <li>✓ Audit logs for all actions</li>
                <li>✓ HIPAA compliance ready</li>
                <li>✓ Data encryption</li>
              </ul>
            </div>

            {/* Data Management */}
            <div className="bg-white/10 backdrop-blur-sm rounded-lg p-4">
              <h4 className="font-bold mb-3 text-lg">Data Management</h4>
              <ul className="space-y-2 text-sm">
                <li>✓ Real-time data sync</li>
                <li>✓ EMR integration</li>
                <li>✓ Cloud-based storage</li>
                <li>✓ Automated backups</li>
                <li>✓ Export capabilities</li>
                <li>✓ Data analytics engine</li>
              </ul>
            </div>

            {/* Communication */}
            <div className="bg-white/10 backdrop-blur-sm rounded-lg p-4">
              <h4 className="font-bold mb-3 text-lg">Communication Features</h4>
              <ul className="space-y-2 text-sm">
                <li>✓ Secure messaging</li>
                <li>✓ Video consultation support</li>
                <li>✓ Email notifications</li>
                <li>✓ SMS alerts</li>
                <li>✓ Push notifications</li>
                <li>✓ In-app chat</li>
              </ul>
            </div>
          </div>

          {/* Dashboard Access Matrix */}
          <div className="mt-6 bg-white/10 backdrop-blur-sm rounded-lg p-4">
            <h4 className="font-bold mb-3 text-lg">Dashboard Access & Permissions Matrix</h4>
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b border-white/20">
                    <th className="text-left p-2">User Type</th>
                    <th className="text-center p-2">Patient Data</th>
                    <th className="text-center p-2">Medical Records</th>
                    <th className="text-center p-2">Prescriptions</th>
                    <th className="text-center p-2">Billing</th>
                    <th className="text-center p-2">Analytics</th>
                  </tr>
                </thead>
                <tbody className="text-xs">
                  <tr className="border-b border-white/10">
                    <td className="p-2">Patient</td>
                    <td className="text-center">Own Only</td>
                    <td className="text-center">View Own</td>
                    <td className="text-center">View Own</td>
                    <td className="text-center">View Own</td>
                    <td className="text-center">-</td>
                  </tr>
                  <tr className="border-b border-white/10">
                    <td className="p-2">Doctor</td>
                    <td className="text-center">Full Access</td>
                    <td className="text-center">Full Access</td>
                    <td className="text-center">Prescribe</td>
                    <td className="text-center">View</td>
                    <td className="text-center">Full</td>
                  </tr>
                  <tr className="border-b border-white/10">
                    <td className="p-2">Manager (Admin/Nurse/Vendor)</td>
                    <td className="text-center">Full Access</td>
                    <td className="text-center">View/Edit</td>
                    <td className="text-center">Administer</td>
                    <td className="text-center">Full Access</td>
                    <td className="text-center">Full</td>
                  </tr>
                </tbody>
              </table>
            </div>
            <p className="text-xs mt-3 italic">* Manager Dashboard combines permissions from Admin, Clinical Staff, and Vendor roles for comprehensive operations management</p>
          </div>
        </section>

        {/* User Journey Flows */}
        <section className="bg-gradient-to-br from-green-500 to-teal-600 rounded-lg p-8 shadow-2xl text-white">
          <h3 className="text-2xl font-bold mb-6">Dashboard Consolidation Benefits</h3>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="bg-white/10 backdrop-blur-sm rounded-lg p-4">
              <h4 className="font-bold mb-3 text-lg">Efficiency Improvements</h4>
              <ul className="space-y-2 text-sm">
                <li>✓ Reduced context switching between dashboards</li>
                <li>✓ Unified view of all operational data</li>
                <li>✓ Single login for all management functions</li>
                <li>✓ Streamlined workflows across departments</li>
                <li>✓ Faster decision-making with integrated insights</li>
              </ul>
            </div>

            <div className="bg-white/10 backdrop-blur-sm rounded-lg p-4">
              <h4 className="font-bold mb-3 text-lg">Operational Benefits</h4>
              <ul className="space-y-2 text-sm">
                <li>✓ Complete visibility across operations</li>
                <li>✓ Better coordination between functions</li>
                <li>✓ Simplified training for management staff</li>
                <li>✓ Reduced system maintenance overhead</li>
                <li>✓ Enhanced cross-functional reporting</li>
              </ul>
            </div>
          </div>

          <div className="mt-6 bg-white/10 backdrop-blur-sm rounded-lg p-4">
            <h4 className="font-bold mb-3 text-lg">System Architecture Evolution</h4>
            <div className="flex items-center justify-center gap-8 flex-wrap">
              <div className="text-center">
                <p className="text-3xl font-bold mb-2">5 → 3</p>
                <p className="text-xs">Dashboard Systems</p>
              </div>
              <div className="text-center">
                <p className="text-3xl font-bold mb-2">100%</p>
                <p className="text-xs">Functionality Retained</p>
              </div>
              <div className="text-center">
                <p className="text-3xl font-bold mb-2">40%</p>
                <p className="text-xs">Complexity Reduction</p>
              </div>
            </div>
          </div>
        </section>

        {/* Implementation Notes */}
        <section className="bg-gray-800 rounded-lg p-8 text-white">
          <h3 className="text-2xl font-bold mb-6">Implementation & Architecture Notes</h3>
          
          <div className="space-y-4 text-sm">
            <div>
              <h4 className="font-bold mb-2">🏗️ Dashboard Structure:</h4>
              <ul className="list-disc list-inside space-y-1 ml-4">
                <li><strong>Patient EMR:</strong> Patient-facing electronic medical record portal</li>
                <li><strong>Doctor Dashboard:</strong> Physician consultation and prescription management</li>
                <li><strong>Manager Dashboard:</strong> Unified operations management (Admin + Clinical Staff + Vendor functions)</li>
              </ul>
            </div>

            <div>
              <h4 className="font-bold mb-2">🔄 Data Flow:</h4>
              <ul className="list-disc list-inside space-y-1 ml-4">
                <li>Real-time synchronization across all dashboards</li>
                <li>Centralized database with role-based access</li>
                <li>Secure API endpoints for cross-dashboard communication</li>
                <li>Event-driven updates for immediate data consistency</li>
              </ul>
            </div>

            <div>
              <h4 className="font-bold mb-2">🎯 Access Routes:</h4>
              <ul className="list-disc list-inside space-y-1 ml-4">
                <li><code>/dashboard/patient</code> - Patient EMR Portal</li>
                <li><code>/dashboard/doctor</code> - Doctor Dashboard</li>
                <li><code>/dashboard/manager</code> - Manager Dashboard (Unified)</li>
                <li><code>/dashboard/wireframe</code> - System Wireframe Documentation</li>
              </ul>
            </div>

            <div>
              <h4 className="font-bold mb-2">📱 Responsive Design:</h4>
              <p className="ml-4">All dashboards are fully responsive and optimized for desktop, tablet, and mobile devices with adaptive layouts and touch-friendly interfaces.</p>
            </div>
          </div>
        </section>
      </div>
    </div>
  );
}