import { Play, Youtube, ChevronLeft, ChevronRight } from "lucide-react";
import { useState } from "react";

export function SocialVideoCarousel() {
  const [currentIndex, setCurrentIndex] = useState(0);

  const socialVideos = [
    {
      title: "Real Patient Transformation Story",
      channel: "Dr. MOTABHAI Official",
      views: "125K views",
      thumbnail: "https://images.unsplash.com/photo-1571019613454-1cb2f99b2d8b?w=400",
      url: "https://youtube.com/watch?v=example1"
    },
    {
      title: "Understanding Semaglutide - Expert Explained",
      channel: "Dr. MOTABHAI Official",
      views: "89K views",
      thumbnail: "https://images.unsplash.com/photo-1576091160550-2173dba999ef?w=400",
      url: "https://youtube.com/watch?v=example2"
    },
    {
      title: "Life After GLP-1 Treatment",
      channel: "Dr. MOTABHAI Official",
      views: "156K views",
      thumbnail: "https://images.unsplash.com/photo-1551076805-e1869033e561?w=400",
      url: "https://youtube.com/watch?v=example3"
    },
    {
      title: "Nutrition Tips for Weight Loss Success",
      channel: "Dr. MOTABHAI Official",
      views: "92K views",
      thumbnail: "https://images.unsplash.com/photo-1490645935967-10de6ba17061?w=400",
      url: "https://youtube.com/watch?v=example4"
    },
    {
      title: "Managing Side Effects Naturally",
      channel: "Dr. MOTABHAI Official",
      views: "78K views",
      thumbnail: "https://images.unsplash.com/photo-1505751172876-fa1923c5c528?w=400",
      url: "https://youtube.com/watch?v=example5"
    },
    {
      title: "Exercise Guide for GLP-1 Users",
      channel: "Dr. MOTABHAI Official",
      views: "103K views",
      thumbnail: "https://images.unsplash.com/photo-1517836357463-d25dfeac3438?w=400",
      url: "https://youtube.com/watch?v=example6"
    }
  ];

  const handlePrev = () => {
    setCurrentIndex((prev) => (prev === 0 ? Math.max(0, socialVideos.length - 3) : prev - 1));
  };

  const handleNext = () => {
    setCurrentIndex((prev) => (prev >= socialVideos.length - 3 ? 0 : prev + 1));
  };

  return (
    <section className="py-20 lg:py-28 bg-gray-50">
      <div className="container mx-auto px-4 lg:px-8 max-w-7xl">
        {/* Header */}
        <div className="text-center mb-16">
          <div className="flex items-center justify-center gap-3 mb-4">
            <Youtube className="w-8 h-8 text-red-600" />
            <h2 
              className="text-gray-900"
              style={{ 
                fontFamily: 'Bebas Neue',
                fontSize: 'clamp(32px, 4vw, 48px)',
                letterSpacing: '0.02em'
              }}
            >
              Our Social Content
            </h2>
          </div>
          <p 
            className="text-gray-600 max-w-2xl mx-auto"
            style={{ 
              fontFamily: 'DM Sans',
              fontSize: '16px',
              lineHeight: '1.6'
            }}
          >
            Watch real stories, expert insights, and educational content about GLP-1 weight loss
          </p>
        </div>

        {/* Carousel */}
        <div className="relative">
          {/* Navigation Buttons */}
          <button
            onClick={handlePrev}
            className="absolute left-0 top-1/2 -translate-y-1/2 -translate-x-4 z-10 w-12 h-12 bg-white rounded-full shadow-lg flex items-center justify-center hover:bg-gray-50 transition-all disabled:opacity-50 disabled:cursor-not-allowed"
            disabled={currentIndex === 0}
          >
            <ChevronLeft className="w-6 h-6 text-gray-700" />
          </button>

          <button
            onClick={handleNext}
            className="absolute right-0 top-1/2 -translate-y-1/2 translate-x-4 z-10 w-12 h-12 bg-white rounded-full shadow-lg flex items-center justify-center hover:bg-gray-50 transition-all disabled:opacity-50 disabled:cursor-not-allowed"
            disabled={currentIndex >= socialVideos.length - 3}
          >
            <ChevronRight className="w-6 h-6 text-gray-700" />
          </button>

          {/* Video Cards */}
          <div className="overflow-hidden">
            <div 
              className="flex transition-transform duration-500 ease-out gap-6"
              style={{ transform: `translateX(-${currentIndex * (100 / 3)}%)` }}
            >
              {socialVideos.map((video, idx) => (
                <a
                  key={idx}
                  href={video.url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex-shrink-0 w-full md:w-1/3 group cursor-pointer"
                >
                  <div className="bg-white rounded-2xl shadow-lg hover:shadow-2xl transition-all duration-300 overflow-hidden">
                    {/* Thumbnail */}
                    <div className="relative h-56 overflow-hidden bg-gray-200">
                      <img
                        src={video.thumbnail}
                        alt={video.title}
                        className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
                      />
                      <div className="absolute inset-0 bg-black/30 group-hover:bg-black/50 transition-colors flex items-center justify-center">
                        <div className="w-16 h-16 bg-white/95 rounded-full flex items-center justify-center group-hover:scale-110 transition-transform shadow-lg">
                          <Play className="w-8 h-8 text-red-600 ml-1" />
                        </div>
                      </div>
                      
                      {/* YouTube Badge */}
                      <div className="absolute top-3 right-3 bg-red-600 text-white px-2 py-1 rounded flex items-center gap-1 text-xs font-semibold">
                        <Youtube className="w-3 h-3" />
                        YouTube
                      </div>
                    </div>

                    {/* Content */}
                    <div className="p-5">
                      <h3 
                        className="font-bold text-gray-900 mb-2 line-clamp-2 group-hover:text-[#4A6B78] transition-colors"
                        style={{ fontFamily: 'DM Sans', fontSize: '16px' }}
                      >
                        {video.title}
                      </h3>
                      <p 
                        className="text-sm text-gray-600 mb-1"
                        style={{ fontFamily: 'DM Sans' }}
                      >
                        {video.channel}
                      </p>
                      <p 
                        className="text-xs text-gray-500"
                        style={{ fontFamily: 'DM Sans' }}
                      >
                        {video.views}
                      </p>
                    </div>
                  </div>
                </a>
              ))}
            </div>
          </div>
        </div>

        {/* Dots Indicator */}
        <div className="flex justify-center gap-2 mt-8">
          {Array.from({ length: Math.max(1, socialVideos.length - 2) }).map((_, idx) => (
            <button
              key={idx}
              onClick={() => setCurrentIndex(idx)}
              className={`w-2 h-2 rounded-full transition-all ${
                currentIndex === idx ? 'bg-[#4A6B78] w-8' : 'bg-gray-300'
              }`}
              aria-label={`Go to slide ${idx + 1}`}
            />
          ))}
        </div>

        {/* CTA */}
        <div className="text-center mt-12">
          <a
            href="https://youtube.com/@drmotabhai"
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-2 px-8 py-4 bg-red-600 text-white rounded-lg hover:bg-red-700 transition-all font-semibold shadow-lg"
            style={{ fontFamily: 'DM Sans' }}
          >
            <Youtube className="w-5 h-5" />
            Subscribe to Our Channel
          </a>
        </div>
      </div>
    </section>
  );
}
