import { Link } from "react-router-dom";
import { Button } from "@/app/components/ui/button";
import { ShoppingCart } from "lucide-react";
import { CartSheet } from "@/app/components/cart-sheet";
import { useCart } from "@/app/contexts/cart-context";

export function Header() {
  const { itemCount } = useCart();
  
  return (
    <header className="absolute top-0 left-0 right-0 z-50">
      {/* Subtle navbar backdrop for differentiation */}
      <div className="absolute inset-0 bg-gradient-to-b from-black/30 to-transparent h-16 backdrop-blur-sm"></div>
      
      <div className="relative w-full max-w-[1440px] mx-auto px-4 lg:px-0">
        {/* Brand Logo */}
        <Link to="/" className="brand">
          DR MOTABHAI<span className="tm">™</span>
        </Link>

        {/* Navigation Links - Hidden on mobile, shown on large screens */}
        <nav className="hidden lg:block">
          <Link className="nav-link" style={{ left: '450px' }} to="/treatments">
            Treatments
          </Link>
          <Link className="nav-link" style={{ left: '570px' }} to="/products">
            Products
          </Link>
          <Link className="nav-link" style={{ left: '680px' }} to="/education">
            Education
          </Link>
          <Link className="nav-link" style={{ left: '800px' }} to="/pricing">
            Pricing
          </Link>
          <Link className="nav-link" style={{ left: '910px' }} to="/eligibility">
            Eligibility
          </Link>
          <Link className="nav-link active" style={{ left: '1040px' }} to="/eligibility">
            Book Now
          </Link>
          
          {/* Cart Icon */}
          <div style={{ position: 'absolute', left: '1170px', top: '20px' }}>
            <CartSheet>
              <button className="relative text-white hover:text-[#E8BFB8] transition-colors">
                <ShoppingCart className="w-6 h-6" />
                {itemCount > 0 && (
                  <span className="absolute -top-2 -right-2 bg-[#E8BFB8] text-gray-900 text-xs font-bold rounded-full w-5 h-5 flex items-center justify-center" style={{ fontFamily: 'DM Sans' }}>
                    {itemCount}
                  </span>
                )}
              </button>
            </CartSheet>
          </div>
        </nav>

        {/* Mobile Navigation Menu */}
        <nav className="lg:hidden flex justify-center items-center gap-4 pt-20 flex-wrap">
          <Link className="text-white text-xs hover:text-[#E8BFB8] transition-colors" to="/treatments">
            Treatments
          </Link>
          <Link className="text-white text-xs hover:text-[#E8BFB8] transition-colors" to="/products">
            Products
          </Link>
          <Link className="text-white text-xs hover:text-[#E8BFB8] transition-colors" to="/education">
            Education
          </Link>
          <Link className="text-white text-xs hover:text-[#E8BFB8] transition-colors" to="/pricing">
            Pricing
          </Link>
          <Link className="text-white text-xs hover:text-[#E8BFB8] transition-colors" to="/eligibility">
            Eligibility
          </Link>
          <Link className="text-[#E8BFB8] text-xs font-medium" to="/eligibility">
            Book Now
          </Link>
          <CartSheet>
            <button className="relative text-white hover:text-[#E8BFB8] transition-colors">
              <ShoppingCart className="w-5 h-5" />
              {itemCount > 0 && (
                <span className="absolute -top-2 -right-2 bg-[#E8BFB8] text-gray-900 text-xs font-bold rounded-full w-4 h-4 flex items-center justify-center text-[10px]" style={{ fontFamily: 'DM Sans' }}>
                  {itemCount}
                </span>
              )}
            </button>
          </CartSheet>
        </nav>
      </div>
    </header>
  );
}