export function MotabhaiMeaning() {
  // Motabhai/Big Brother in multiple languages (Indian + Global)
  const translations = [
    { language: "Hindi", text: "मोटाभाई" },
    { language: "English", text: "Big Brother" },
    { language: "Gujarati", text: "મોટાભાઈ" },
    { language: "Marathi", text: "मोठा भाऊ" },
    { language: "Tamil", text: "பெரிய சகோதரர்" },
    { language: "Telugu", text: "పెద్ద సోదరుడు" },
    { language: "Bengali", text: "বড় ভাই" },
    { language: "Kannada", text: "ದೊಡ್ಡಣ್ಣ" },
    { language: "Malayalam", text: "വലിയ സഹോദരൻ" },
    { language: "Punjabi", text: "ਵੱਡਾ ਭਰਾ" },
    { language: "Spanish", text: "Hermano Mayor" },
    { language: "French", text: "Grand Frère" },
    { language: "German", text: "Großer Bruder" },
    { language: "Italian", text: "Fratello Maggiore" },
    { language: "Portuguese", text: "Irmão Mais Velho" },
    { language: "Chinese", text: "大哥" },
    { language: "Japanese", text: "兄貴" },
    { language: "Korean", text: "형님" },
    { language: "Arabic", text: "الأخ الأكبر" },
    { language: "Russian", text: "Старший Брат" },
  ];

  return (
    <section className="w-full bg-[#FCD34D] py-8">
      <div className="container mx-auto px-4">
        {/* Main Content */}
        <div className="flex flex-col md:flex-row items-center justify-center gap-6 md:gap-8 mb-6">
          {/* Left Side - Main Title */}
          <div className="text-center md:text-left">
            <h2 
              className="text-gray-900 mb-1"
              style={{ 
                fontFamily: 'Bebas Neue',
                fontSize: 'clamp(36px, 5vw, 48px)',
                lineHeight: '1',
                letterSpacing: '0.08em'
              }}
            >
              MOTABHAI
            </h2>
            <p 
              className="text-gray-800"
              style={{ 
                fontFamily: 'DM Sans',
                fontSize: '16px',
                fontWeight: '500'
              }}
            >
              means "Big Brother", Your Trusted Guide
            </p>
          </div>

          {/* Divider */}
          <div className="hidden md:block w-px h-16 bg-gray-800/20"></div>

          {/* Right Side - Language Grid */}
          <div className="grid grid-cols-4 md:grid-cols-5 lg:grid-cols-10 gap-3 md:gap-4">
            {translations.map((item, index) => (
              <div 
                key={index}
                className="text-center"
              >
                <p 
                  className="text-gray-900 font-semibold mb-0.5"
                  style={{ 
                    fontFamily: 'DM Sans',
                    fontSize: 'clamp(13px, 1.5vw, 16px)',
                    lineHeight: '1.2'
                  }}
                >
                  {item.text}
                </p>
                <p 
                  className="text-gray-700 text-xs uppercase tracking-wide"
                  style={{ 
                    fontFamily: 'DM Sans',
                    fontSize: '8px',
                    fontWeight: '500',
                    letterSpacing: '0.05em'
                  }}
                >
                  {item.language}
                </p>
              </div>
            ))}
          </div>
        </div>

        {/* Bottom Tagline */}
        <div className="text-center">
          <p 
            className="text-gray-800 italic"
            style={{ 
              fontFamily: 'DM Sans',
              fontSize: '13px',
              fontWeight: '500'
            }}
          >
            In Indian culture, someone who guides, protects, and supports with care
          </p>
        </div>
      </div>
    </section>
  );
}