import { ImageWithFallback } from "@/app/components/figma/ImageWithFallback";

export function HowItWorks() {
  const steps = [
    {
      step: "Step 01",
      title: "Comprehensive Clinical Evaluation",
      description: "Doctor-led medical assessment covering health history, metabolic profile, and eligibility for GLP-1 medical weight loss treatment."
    },
    {
      step: "Step 02",
      title: "Doctor-Prescribed GLP-1 Medication",
      description: "GLP-1 therapy is prescribed only when medically appropriate, with personalised dosing for safety and effectiveness."
    },
    {
      step: "Step 03",
      title: "Ongoing Medical Monitoring",
      description: "Regular follow-ups, dosage optimisation, and clinical supervision ensure safe and sustained weight loss results."
    }
  ];

  return (
    <section className="py-20 lg:py-28 bg-white" id="how-it-works">
      <div className="container mx-auto px-4 lg:px-8">
        {/* Section Title */}
        <h2 
          className="text-center text-gray-900 max-w-3xl mx-auto mb-6"
          style={{ 
            fontFamily: 'DM Sans',
            fontSize: 'clamp(24px, 3vw, 36px)',
            lineHeight: '1.3',
            letterSpacing: '-0.02em',
            fontWeight: '400'
          }}
        >
          This Is Not a Generic Program. It Is a Medical Responsibility.
        </h2>

        {/* Content Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 max-w-7xl mx-auto mt-16">
          {/* Image Section */}
          <div className="rounded-3xl overflow-hidden order-2 lg:order-1 relative">
            <div className="relative h-full min-h-[500px] bg-gradient-to-br from-[#4A6B78] to-[#3E5147]">
              <ImageWithFallback
                src="https://images.unsplash.com/photo-1659019730080-63caf6c9b3bc?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtZWRpY2FsJTIwd2VpZ2h0JTIwbG9zcyUyMHN5cmluZ2UlMjBoZWFsdGhjYXJlfGVufDF8fHx8MTc3MDEyNDM2NHww&ixlib=rb-4.1.0&q=80&w=1080"
                alt="GLP-1 Medical Weight Loss Treatment"
                className="w-full h-full object-cover"
              />
              {/* Overlay for better text visibility */}
              <div className="absolute inset-0 bg-gradient-to-t from-[#3E5147]/80 via-transparent to-transparent"></div>
              
              <div className="absolute inset-0 flex items-end p-8">
                <p 
                  className="text-white leading-tight max-w-md"
                  style={{ 
                    fontFamily: 'DM Sans',
                    fontSize: 'clamp(24px, 3vw, 40px)',
                    lineHeight: '1.2',
                    letterSpacing: '-0.02em',
                    fontWeight: '400'
                  }}
                >
                  Medical Weight Loss Under Doctor Supervision
                </p>
              </div>
            </div>
          </div>

          {/* Text Content */}
          <div className="flex flex-col justify-center order-1 lg:order-2">
            <h3 
              className="text-gray-900 mb-6"
              style={{ 
                fontFamily: 'DM Sans',
                fontSize: 'clamp(20px, 2.5vw, 28px)',
                letterSpacing: '-0.02em',
                fontWeight: '500'
              }}
            >
              Medical Guidance — Not Guesswork.
            </h3>

            <p 
              className="text-gray-600 mb-8 text-sm leading-relaxed"
              style={{ 
                fontFamily: 'DM Sans',
                letterSpacing: '-0.01em'
              }}
            >
              Weight loss is not a challenge to complete or a plan to follow blindly. It is a personal, medical journey that affects your metabolism, hormones, and long-term health. Dr Motabhai (मोटाभाई - your trusted big brother) exists to walk alongside you — firmly, honestly, and with clinical responsibility — so that every decision is made in your best interest.
            </p>

            {/* Steps Cards */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {steps.map((item, index) => (
                <div key={index} className="bg-gray-50 rounded-xl p-5 border border-gray-100">
                  <p 
                    className="text-gray-400 mb-3 text-xs uppercase tracking-wider"
                    style={{ 
                      fontFamily: 'DM Sans',
                      letterSpacing: '0.1em'
                    }}
                  >
                    {item.step}
                  </p>
                  <h4 
                    className="text-gray-900 mb-2 text-sm font-medium"
                    style={{ 
                      fontFamily: 'DM Sans',
                      letterSpacing: '-0.01em'
                    }}
                  >
                    {item.title}
                  </h4>
                  <p 
                    className="text-gray-600 text-xs leading-relaxed"
                    style={{ 
                      fontFamily: 'DM Sans',
                      letterSpacing: '-0.01em'
                    }}
                  >
                    {item.description}
                  </p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}