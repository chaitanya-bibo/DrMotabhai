import { X, Minus, Plus, ShoppingBag } from 'lucide-react';
import { useCart } from '@/app/contexts/cart-context';
import { Button } from '@/app/components/ui/button';
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetTrigger } from '@/app/components/ui/sheet';
import { useNavigate } from 'react-router-dom';

export function CartSheet({ children }: { children: React.ReactNode }) {
  const { items, removeItem, updateQuantity, total, itemCount } = useCart();
  const navigate = useNavigate();

  const formatPrice = (price: number) => {
    return new Intl.NumberFormat('en-IN', {
      style: 'currency',
      currency: 'INR',
      maximumFractionDigits: 0,
    }).format(price);
  };

  return (
    <Sheet>
      <SheetTrigger asChild>
        {children}
      </SheetTrigger>
      <SheetContent className="w-full sm:max-w-lg">
        <SheetHeader>
          <SheetTitle style={{ fontFamily: 'Bebas Neue', fontSize: '28px', letterSpacing: '0.05em' }}>
            Your Cart ({itemCount})
          </SheetTitle>
        </SheetHeader>

        <div className="mt-8 flex flex-col h-[calc(100vh-180px)]">
          {items.length === 0 ? (
            <div className="flex-1 flex flex-col items-center justify-center text-center">
              <ShoppingBag className="w-16 h-16 text-gray-300 mb-4" />
              <p className="text-gray-500" style={{ fontFamily: 'DM Sans', fontSize: '16px' }}>
                Your cart is empty
              </p>
              <p className="text-gray-400 text-sm mt-2" style={{ fontFamily: 'DM Sans' }}>
                Add products or plans to get started
              </p>
            </div>
          ) : (
            <>
              <div className="flex-1 overflow-y-auto pr-2">
                <div className="space-y-4">
                  {items.map((item) => (
                    <div key={item.id} className="flex gap-4 p-4 bg-gray-50 rounded-lg">
                      {item.image && (
                        <div className="w-20 h-20 bg-gray-200 rounded-lg flex-shrink-0">
                          <img src={item.image} alt={item.name} className="w-full h-full object-cover rounded-lg" />
                        </div>
                      )}
                      <div className="flex-1 min-w-0">
                        <div className="flex items-start justify-between gap-2 mb-2">
                          <div className="flex-1 min-w-0">
                            <p className="font-semibold text-gray-900 truncate" style={{ fontFamily: 'DM Sans', fontSize: '14px' }}>
                              {item.name}
                            </p>
                            {item.category && (
                              <p className="text-xs text-gray-500 uppercase tracking-wider" style={{ fontFamily: 'DM Sans' }}>
                                {item.category}
                              </p>
                            )}
                          </div>
                          <button
                            onClick={() => removeItem(item.id)}
                            className="text-gray-400 hover:text-red-500 transition-colors flex-shrink-0"
                          >
                            <X className="w-4 h-4" />
                          </button>
                        </div>

                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-2 bg-white rounded-lg border border-gray-200">
                            <button
                              onClick={() => updateQuantity(item.id, item.quantity - 1)}
                              className="p-1.5 hover:bg-gray-100 rounded-l-lg transition-colors"
                            >
                              <Minus className="w-3 h-3" />
                            </button>
                            <span className="px-2 font-medium text-sm" style={{ fontFamily: 'DM Sans' }}>
                              {item.quantity}
                            </span>
                            <button
                              onClick={() => updateQuantity(item.id, item.quantity + 1)}
                              className="p-1.5 hover:bg-gray-100 rounded-r-lg transition-colors"
                            >
                              <Plus className="w-3 h-3" />
                            </button>
                          </div>
                          <p className="font-bold text-[#4A6B78]" style={{ fontFamily: 'DM Sans', fontSize: '16px' }}>
                            {formatPrice(item.price * item.quantity)}
                          </p>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              <div className="border-t pt-4 mt-4">
                <div className="flex justify-between items-center mb-4">
                  <span className="text-gray-600 font-medium" style={{ fontFamily: 'DM Sans', fontSize: '16px' }}>
                    Total
                  </span>
                  <span className="text-2xl font-bold text-[#4A6B78]" style={{ fontFamily: 'DM Sans' }}>
                    {formatPrice(total)}
                  </span>
                </div>
                <Button
                  onClick={() => navigate('/checkout')}
                  className="w-full py-6 bg-[#4A6B78] text-white hover:bg-[#3E5147] rounded-lg font-bold text-lg"
                  style={{ fontFamily: 'DM Sans' }}
                >
                  Proceed to Checkout
                </Button>
              </div>
            </>
          )}
        </div>
      </SheetContent>
    </Sheet>
  );
}
