import { ImageWithFallback } from "@/app/components/figma/ImageWithFallback";

export function TreatmentsSection() {
  const treatments = [
    { name: "Ozempic Injection for Medical Weight Loss", price: "Starting from ₹30,000 per month" },
    { name: "Semaglutide Weight Loss Treatment", price: "Starting from ₹30,000 per month" },
    { name: "Mounjaro (Tirzepatide) Weight Loss Therapy", price: "Starting from ₹30,000 per month" }
  ];

  return (
    <section className="py-20 lg:py-28 bg-white" id="treatments">
      <div className="container mx-auto px-4 lg:px-8">
        {/* Section Title */}
        <h2 
          className="text-center text-gray-900 max-w-3xl mx-auto mb-16"
          style={{ 
            fontFamily: 'DM Sans',
            fontSize: 'clamp(24px, 3vw, 36px)',
            lineHeight: '1.3',
            letterSpacing: '-0.02em',
            fontWeight: '400'
          }}
        >
          Our Most Trusted Doctor-Prescribed Weight Loss Treatments
        </h2>

        {/* Treatment Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 max-w-7xl mx-auto">
          {/* GLP 1 Programme Card - Featured */}
          <div className="bg-gradient-to-br from-[#4A6B78] via-[#55675E] to-[#3E5147] rounded-2xl overflow-hidden lg:col-span-1 relative min-h-[320px] shadow-xl hover:shadow-2xl transition-all duration-300 group">
            {/* Decorative background pattern */}
            <div className="absolute inset-0 opacity-10">
              <div className="absolute top-0 right-0 w-40 h-40 bg-white rounded-full blur-3xl"></div>
              <div className="absolute bottom-0 left-0 w-32 h-32 bg-white rounded-full blur-2xl"></div>
            </div>
            
            {/* Content */}
            <div className="relative h-full flex flex-col justify-between p-8">
              <div>
                <div className="inline-block px-3 py-1 bg-white/20 backdrop-blur-sm rounded-full mb-4">
                  <p 
                    className="text-white/90 text-xs tracking-wide uppercase"
                    style={{ 
                      fontFamily: 'DM Sans',
                      fontWeight: '600',
                      letterSpacing: '0.05em'
                    }}
                  >
                    Most Popular
                  </p>
                </div>
                
                <h3 
                  className="text-white leading-tight mb-3"
                  style={{ 
                    fontFamily: 'Bebas Neue',
                    fontSize: '32px',
                    letterSpacing: '-0.02em',
                    fontWeight: '400',
                    lineHeight: '1.1'
                  }}
                >
                  GLP-1 Weight Loss Programme
                </h3>
                
                <p 
                  className="text-white/80 mb-4"
                  style={{ 
                    fontFamily: 'DM Sans',
                    fontSize: '15px',
                    letterSpacing: '-0.01em',
                    lineHeight: '1.6',
                    fontWeight: '400'
                  }}
                >
                  Evidence-based medical treatments for sustainable, doctor-monitored results
                </p>
              </div>

              <div className="space-y-2">
                <div className="flex items-center gap-2 text-white/70">
                  <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 20 20">
                    <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                  </svg>
                  <span 
                    className="text-sm"
                    style={{ fontFamily: 'DM Sans', fontSize: '13px' }}
                  >
                    Doctor prescribed
                  </span>
                </div>
                <div className="flex items-center gap-2 text-white/70">
                  <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 20 20">
                    <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                  </svg>
                  <span 
                    className="text-sm"
                    style={{ fontFamily: 'DM Sans', fontSize: '13px' }}
                  >
                    Medically monitored
                  </span>
                </div>
                <div className="flex items-center gap-2 text-white/70">
                  <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 20 20">
                    <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                  </svg>
                  <span 
                    className="text-sm"
                    style={{ fontFamily: 'DM Sans', fontSize: '13px' }}
                  >
                    Proven results
                  </span>
                </div>
              </div>
            </div>

            {/* Hover effect indicator */}
            <div className="absolute bottom-0 left-0 right-0 h-1 bg-gradient-to-r from-[#E8BFB8] to-white transform scale-x-0 group-hover:scale-x-100 transition-transform duration-300"></div>
          </div>

          {/* Treatment Product Cards */}
          {treatments.map((treatment, index) => (
            <div key={index} className="bg-white rounded-2xl p-6 flex flex-col border border-gray-200 shadow-sm">
              <div className="flex-1 flex items-center justify-center mb-6">
                <div className="w-full h-40 bg-gradient-to-b from-gray-50 to-white rounded-xl flex items-center justify-center">
                  <div className="w-12 h-32 bg-gradient-to-b from-[#55675E] to-[#7A9B8A] rounded-full"></div>
                </div>
              </div>
              <h3 
                className="text-center text-gray-900 mb-2"
                style={{ 
                  fontFamily: 'DM Sans',
                  fontSize: '18px',
                  letterSpacing: '-0.01em',
                  fontWeight: '500'
                }}
              >
                {treatment.name}
              </h3>
              <p 
                className="text-center text-gray-600 mb-6 text-sm"
                style={{ 
                  fontFamily: 'DM Sans',
                  letterSpacing: '-0.01em'
                }}
              >
                {treatment.price}
              </p>
              <div className="flex flex-col gap-2">
                <a
                  href="/eligibility"
                  className="w-full py-3 bg-[#4A6B78] text-center rounded-lg text-white hover:bg-[#3E5147] transition-all text-sm font-medium"
                  style={{ 
                    fontFamily: 'DM Sans',
                    letterSpacing: '-0.01em'
                  }}
                >
                  Check Eligibility
                </a>
                <a
                  href="/treatments"
                  className="w-full py-3 bg-white border-2 border-[#55675E] text-center rounded-lg text-[#55675E] hover:bg-[#55675E] hover:text-white transition-all text-sm font-medium"
                  style={{ 
                    fontFamily: 'DM Sans',
                    letterSpacing: '-0.01em'
                  }}
                >
                  Learn More
                </a>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}