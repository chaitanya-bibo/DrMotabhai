import { Link } from "react-router-dom";

export function WireframeMultipage() {
  return (
    <div className="min-h-screen bg-gray-50 p-8" style={{ fontFamily: 'DM Sans' }}>
      <div className="max-w-7xl mx-auto space-y-8">
        {/* Title */}
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold mb-2">Dr. MOTABHAI - Multi-Page E-commerce Website Wireframe</h1>
          <p className="text-gray-600">Complete Site Structure with Shopping Cart & Checkout</p>
          <p className="text-sm text-gray-500 mt-2">Navigate between pages using header links</p>
          <div className="mt-4 flex flex-wrap gap-2 justify-center">
            <Link to="/" className="px-4 py-2 bg-blue-500 text-white rounded-lg text-sm hover:bg-blue-600">View Live Home</Link>
            <Link to="/treatments" className="px-4 py-2 bg-green-500 text-white rounded-lg text-sm hover:bg-green-600">View Live Treatments</Link>
            <Link to="/products" className="px-4 py-2 bg-teal-500 text-white rounded-lg text-sm hover:bg-teal-600">View Live Products</Link>
            <Link to="/education" className="px-4 py-2 bg-yellow-500 text-white rounded-lg text-sm hover:bg-yellow-600">View Live Education</Link>
            <Link to="/pricing" className="px-4 py-2 bg-purple-500 text-white rounded-lg text-sm hover:bg-purple-600">View Live Pricing</Link>
            <Link to="/eligibility" className="px-4 py-2 bg-orange-500 text-white rounded-lg text-sm hover:bg-orange-600">View Live Eligibility</Link>
            <Link to="/checkout" className="px-4 py-2 bg-red-500 text-white rounded-lg text-sm hover:bg-red-600">View Live Checkout</Link>
          </div>
        </div>

        {/* Site Navigation Map */}
        <section className="bg-gradient-to-br from-indigo-600 to-purple-600 rounded-lg p-8 shadow-2xl text-white">
          <h2 className="text-3xl font-bold mb-6 text-center">Site Navigation Structure</h2>
          
          <div className="bg-white/10 backdrop-blur-sm rounded-lg p-6">
            <div className="flex flex-col items-center gap-4">
              {/* Header */}
              <div className="w-full max-w-5xl">
                <div className="bg-black/30 rounded-lg p-4 text-center">
                  <p className="font-bold text-lg mb-3">GLOBAL HEADER (All Pages)</p>
                  <div className="flex flex-wrap gap-2 justify-center text-xs">
                    <span className="bg-white/20 px-3 py-1 rounded">DR MOTABHAI™ Logo</span>
                    <span className="bg-white/20 px-3 py-1 rounded">Treatments</span>
                    <span className="bg-white/20 px-3 py-1 rounded">Products</span>
                    <span className="bg-white/20 px-3 py-1 rounded">Education</span>
                    <span className="bg-white/20 px-3 py-1 rounded">Pricing</span>
                    <span className="bg-white/20 px-3 py-1 rounded">Eligibility</span>
                    <span className="bg-green-400 px-3 py-1 rounded font-bold">Book Now</span>
                    <span className="bg-yellow-400 text-gray-900 px-3 py-1 rounded font-bold">🛒 Cart</span>
                  </div>
                  <p className="text-xs mt-2 text-yellow-200">★ FAQ removed from nav, replaced with Cart icon</p>
                </div>
              </div>

              {/* Page Hierarchy */}
              <div className="text-2xl">↓</div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 w-full">
                {/* Home Page */}
                <div className="bg-blue-500/30 backdrop-blur-sm rounded-lg p-4 border-2 border-white/50">
                  <p className="font-bold text-sm mb-2 text-center">HOME PAGE</p>
                  <div className="space-y-1 text-xs">
                    <div className="bg-white/20 p-2 rounded">Hero (Custom Image)</div>
                    <div className="bg-yellow-400/60 p-2 rounded font-bold">Motabhai Meaning ★</div>
                    <div className="bg-white/20 p-2 rounded">Treatments Overview</div>
                    <div className="bg-green-400/60 p-2 rounded font-bold">Weight Loss Slider (Dynamic 15%)</div>
                    <div className="bg-white/20 p-2 rounded">How It Works</div>
                    <div className="bg-emerald-400/60 p-2 rounded font-bold">Dr. Raju Feature ★</div>
                    <div className="bg-white/20 p-2 rounded">Testimonials (Real Images)</div>
                    <div className="bg-white/20 p-2 rounded">Products Showcase</div>
                    <div className="bg-red-400/60 p-2 rounded font-bold">Social Videos ★</div>
                  </div>
                </div>

                {/* Products Page */}
                <div className="bg-teal-500/30 backdrop-blur-sm rounded-lg p-4 border-2 border-yellow-400">
                  <p className="font-bold text-sm mb-2 text-center">PRODUCTS PAGE ★ NEW</p>
                  <div className="space-y-1 text-xs">
                    <div className="bg-white/20 p-2 rounded">Hero + Category Filter</div>
                    <div className="bg-yellow-400/60 p-2 rounded font-bold">MEDICATIONS SECTION FIRST:</div>
                    <div className="bg-white/20 p-2 rounded">• Semaglutide (₹12,500)</div>
                    <div className="bg-white/20 p-2 rounded">• Tirzepatide (₹16,500)</div>
                    <div className="bg-white/20 p-2 rounded">• Compounded Sema (₹8,500)</div>
                    <div className="bg-green-400/60 p-2 rounded font-bold">• Orlistat/Alli (₹3,200) ★</div>
                    <div className="bg-blue-400/60 p-2 rounded text-white">First Purchase Bonus Note</div>
                    <div className="bg-white/20 p-2 rounded">Wellness Products (9 items)</div>
                    <div className="bg-white/20 p-2 rounded">Add to Cart Buttons</div>
                  </div>
                </div>

                {/* Pricing Page */}
                <div className="bg-purple-500/30 backdrop-blur-sm rounded-lg p-4 border-2 border-yellow-400">
                  <p className="font-bold text-sm mb-2 text-center">PRICING PAGE ★ UPDATED</p>
                  <div className="space-y-1 text-xs">
                    <div className="bg-white/20 p-2 rounded">Hero</div>
                    <div className="bg-white/20 p-2 rounded">3 Plans (₹13k/₹16k/₹18k)</div>
                    <div className="bg-green-400/60 p-2 rounded font-bold">Book Consultation Button</div>
                    <div className="bg-yellow-400/60 p-2 rounded font-bold text-gray-900">★ Buy Plan Button (NEW)</div>
                    <div className="bg-white/20 p-2 rounded">Add-ons Dialog (Plans 1 & 2)</div>
                    <div className="bg-white/20 p-2 rounded">• Medical Coach (₹1,200)</div>
                    <div className="bg-white/20 p-2 rounded">• Fitness Coach (₹1,400)</div>
                    <div className="bg-white/20 p-2 rounded">• Nutrition Coach (₹1,300)</div>
                    <div className="bg-white/20 p-2 rounded">• CGM (₹3,200)</div>
                  </div>
                </div>

                {/* Treatments Page */}
                <div className="bg-green-500/30 backdrop-blur-sm rounded-lg p-4 border-2 border-yellow-400">
                  <p className="font-bold text-sm mb-2 text-center">TREATMENTS PAGE ★ UPDATED</p>
                  <div className="space-y-1 text-xs">
                    <div className="bg-white/20 p-2 rounded">Hero (Weight Loss Options)</div>
                    <div className="bg-white/20 p-2 rounded">Expandable Treatment Cards:</div>
                    <div className="bg-white/20 p-2 rounded">• Semaglutide (Ozempic)</div>
                    <div className="bg-white/20 p-2 rounded">• Tirzepatide (Mounjaro)</div>
                    <div className="bg-white/20 p-2 rounded">• Compounded Semaglutide</div>
                    <div className="bg-green-400/60 p-2 rounded font-bold">• Orlistat (Alli/Xenical) ★</div>
                    <div className="bg-white/20 p-2 rounded">Benefits & Side Effects</div>
                    <div className="bg-white/20 p-2 rounded">How GLP-1 Works</div>
                  </div>
                </div>
              </div>

              {/* Second Row of Pages */}
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 w-full mt-6">
                {/* Education Page */}
                <div className="bg-yellow-500/30 backdrop-blur-sm rounded-lg p-4 border-2 border-yellow-400">
                  <p className="font-bold text-sm mb-2 text-center">EDUCATION PAGE ★ UPDATED</p>
                  <div className="space-y-1 text-xs">
                    <div className="bg-white/20 p-2 rounded">Hero</div>
                    <div className="bg-white/20 p-2 rounded">Dr. Raju Profile Featured</div>
                    <div className="bg-white/20 p-2 rounded">Educational Resources:</div>
                    <div className="bg-white/20 p-2 rounded">• Semaglutide Guide</div>
                    <div className="bg-white/20 p-2 rounded">• Tirzepatide Guide</div>
                    <div className="bg-green-400/60 p-2 rounded font-bold">• Orlistat Guide ★</div>
                    <div className="bg-white/20 p-2 rounded">• GLP-1 Understanding</div>
                    <div className="bg-white/20 p-2 rounded">• Side Effects Management</div>
                  </div>
                </div>

                {/* Eligibility Page */}
                <div className="bg-orange-500/30 backdrop-blur-sm rounded-lg p-4 border-2 border-white/50">
                  <p className="font-bold text-sm mb-2 text-center">ELIGIBILITY PAGE</p>
                  <div className="space-y-1 text-xs">
                    <div className="bg-white/20 p-2 rounded">Hero</div>
                    <div className="bg-white/20 p-2 rounded">BMI Calculator</div>
                    <div className="bg-white/20 p-2 rounded">Requirements List</div>
                    <div className="bg-white/20 p-2 rounded">Process Flow</div>
                    <div className="bg-white/20 p-2 rounded">Book Consultation CTA</div>
                  </div>
                </div>

                {/* Checkout Page */}
                <div className="bg-red-500/30 backdrop-blur-sm rounded-lg p-4 border-2 border-yellow-400">
                  <p className="font-bold text-sm mb-2 text-center">CHECKOUT PAGE ★ NEW</p>
                  <div className="space-y-1 text-xs">
                    <div className="bg-white/20 p-2 rounded">Step 1: Login/Sign Up</div>
                    <div className="bg-green-400/60 p-2 rounded font-bold">• Email Login</div>
                    <div className="bg-green-400/60 p-2 rounded font-bold">• Phone Login</div>
                    <div className="bg-green-400/60 p-2 rounded font-bold">• Google Login ★</div>
                    <div className="bg-white/20 p-2 rounded">Step 2: Delivery Address</div>
                    <div className="bg-white/20 p-2 rounded">Order Summary Sidebar</div>
                    <div className="bg-white/20 p-2 rounded">Place Order Button</div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* E-Commerce Flow */}
        <section className="bg-gradient-to-br from-pink-600 to-red-600 rounded-lg p-8 shadow-2xl text-white">
          <h2 className="text-3xl font-bold mb-6 text-center">E-Commerce Shopping Flow</h2>
          
          <div className="bg-white/10 backdrop-blur-sm rounded-lg p-6">
            <div className="flex flex-col gap-4">
              <div className="flex items-center gap-4">
                <div className="bg-teal-500 px-4 py-2 rounded-lg font-bold min-w-[200px] text-center">
                  PRODUCTS PAGE
                </div>
                <div className="flex-1 text-sm">
                  Browse medications & wellness products
                </div>
              </div>

              <div className="text-center text-2xl">↓ Click "Add to Cart"</div>

              <div className="flex items-center gap-4">
                <div className="bg-yellow-400 text-gray-900 px-4 py-2 rounded-lg font-bold min-w-[200px] text-center">
                  SHOPPING CART
                </div>
                <div className="flex-1 text-sm">
                  Review items, adjust quantities, remove items
                </div>
              </div>

              <div className="text-center text-2xl">↓ Click "Proceed to Checkout"</div>

              <div className="flex items-center gap-4">
                <div className="bg-red-500 px-4 py-2 rounded-lg font-bold min-w-[200px] text-center">
                  CHECKOUT - LOGIN
                </div>
                <div className="flex-1 text-sm">
                  Login via Email / Phone / Google
                </div>
              </div>

              <div className="text-center text-2xl">↓</div>

              <div className="flex items-center gap-4">
                <div className="bg-red-600 px-4 py-2 rounded-lg font-bold min-w-[200px] text-center">
                  CHECKOUT - DELIVERY
                </div>
                <div className="flex-1 text-sm">
                  Enter address, city, pincode
                </div>
              </div>

              <div className="text-center text-2xl">↓ Click "Place Order"</div>

              <div className="flex items-center gap-4">
                <div className="bg-green-500 px-4 py-2 rounded-lg font-bold min-w-[200px] text-center">
                  ORDER COMPLETE
                </div>
                <div className="flex-1 text-sm">
                  Order confirmation & redirect to home
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Plan Purchase Flow */}
        <section className="bg-gradient-to-br from-purple-600 to-indigo-600 rounded-lg p-8 shadow-2xl text-white">
          <h2 className="text-3xl font-bold mb-6 text-center">Plan Purchase Flow (Alternative Path)</h2>
          
          <div className="bg-white/10 backdrop-blur-sm rounded-lg p-6">
            <div className="flex flex-col gap-4">
              <div className="flex items-center gap-4">
                <div className="bg-purple-500 px-4 py-2 rounded-lg font-bold min-w-[200px] text-center">
                  PRICING PAGE
                </div>
                <div className="flex-1 text-sm">
                  Choose from 3 treatment plans
                </div>
              </div>

              <div className="text-center text-2xl">↓ Click "Buy Plan"</div>

              <div className="flex items-center gap-4">
                <div className="bg-purple-600 px-4 py-2 rounded-lg font-bold min-w-[200px] text-center">
                  ADD-ONS DIALOG
                </div>
                <div className="flex-1 text-sm">
                  Select optional add-ons (Essential & Complete Care only)
                </div>
              </div>

              <div className="text-center text-2xl">↓ Click "Add to Cart"</div>

              <div className="flex items-center gap-4">
                <div className="bg-yellow-400 text-gray-900 px-4 py-2 rounded-lg font-bold min-w-[200px] text-center">
                  CART
                </div>
                <div className="flex-1 text-sm">
                  Plan + Add-ons in cart → Proceed to Checkout
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Key Features Summary */}
        <section className="bg-gradient-to-br from-emerald-600 to-teal-600 rounded-lg p-8 shadow-2xl text-white">
          <h2 className="text-3xl font-bold mb-6 text-center">New E-Commerce Features</h2>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="bg-white/10 backdrop-blur-sm rounded-lg p-6">
              <h3 className="text-xl font-bold mb-3">🛒 Shopping Cart</h3>
              <ul className="space-y-2 text-sm">
                <li>• Cart icon in header with item count badge</li>
                <li>• Slide-out cart sheet with full item management</li>
                <li>• Add/remove items, adjust quantities</li>
                <li>• Real-time total calculation</li>
                <li>• Persistent cart state across pages</li>
              </ul>
            </div>

            <div className="bg-white/10 backdrop-blur-sm rounded-lg p-6">
              <h3 className="text-xl font-bold mb-3">🔐 Authentication</h3>
              <ul className="space-y-2 text-sm">
                <li>• Email login</li>
                <li>• Phone number login</li>
                <li>• Google OAuth integration</li>
                <li>• Required before checkout</li>
                <li>• User session management</li>
              </ul>
            </div>

            <div className="bg-white/10 backdrop-blur-sm rounded-lg p-6">
              <h3 className="text-xl font-bold mb-3">💊 Medications Store</h3>
              <ul className="space-y-2 text-sm">
                <li>• 4 medications available for direct purchase</li>
                <li>• Semaglutide, Tirzepatide, Compounded, Orlistat</li>
                <li>• First purchase bonus: free wellness guides</li>
                <li>• No prescription required for direct purchase</li>
                <li>• Medications section appears first on products page</li>
              </ul>
            </div>

            <div className="bg-white/10 backdrop-blur-sm rounded-lg p-6">
              <h3 className="text-xl font-bold mb-3">📋 Plan Customization</h3>
              <ul className="space-y-2 text-sm">
                <li>• Buy plans directly from pricing page</li>
                <li>• Add-ons selection for Essential & Complete Care</li>
                <li>• Dynamic total price calculation</li>
                <li>• Medical, Fitness, Nutrition coaches + CGM</li>
                <li>• Premium Plus includes everything (no add-ons)</li>
              </ul>
            </div>
          </div>
        </section>

        {/* Navigation Changes */}
        <section className="bg-gradient-to-br from-gray-700 to-gray-900 rounded-lg p-8 shadow-2xl text-white">
          <h2 className="text-3xl font-bold mb-6 text-center">Navigation Updates</h2>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="bg-red-500/30 backdrop-blur-sm rounded-lg p-6 border-2 border-red-400">
              <h3 className="text-xl font-bold mb-3 text-center">❌ REMOVED</h3>
              <div className="text-center">
                <p className="text-lg font-bold">FAQ</p>
                <p className="text-sm opacity-80 mt-2">Removed from main navigation</p>
              </div>
            </div>

            <div className="bg-green-500/30 backdrop-blur-sm rounded-lg p-6 border-2 border-green-400">
              <h3 className="text-xl font-bold mb-3 text-center">✅ ADDED</h3>
              <div className="space-y-3 text-center">
                <div>
                  <p className="text-lg font-bold">Book Now</p>
                  <p className="text-sm opacity-80">Replaced FAQ position</p>
                </div>
                <div>
                  <p className="text-lg font-bold">🛒 Cart Icon</p>
                  <p className="text-sm opacity-80">Moved to old FAQ spot</p>
                </div>
              </div>
            </div>

            <div className="bg-blue-500/30 backdrop-blur-sm rounded-lg p-6 border-2 border-blue-400">
              <h3 className="text-xl font-bold mb-3 text-center">ℹ️ NOTE</h3>
              <div className="text-sm opacity-90">
                <p className="mb-2">FAQ page still exists at /faq route for direct access</p>
                <p>Healthcare portal links remain in FAQ section</p>
              </div>
            </div>
          </div>
        </section>

        {/* Technical Implementation */}
        <section className="bg-gradient-to-br from-slate-700 to-slate-900 rounded-lg p-8 shadow-2xl text-white">
          <h2 className="text-3xl font-bold mb-6 text-center">Technical Implementation</h2>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="bg-white/10 backdrop-blur-sm rounded-lg p-6">
              <h3 className="text-xl font-bold mb-3">Context Providers</h3>
              <ul className="space-y-2 text-sm font-mono">
                <li>• CartContext - Cart state management</li>
                <li>• AuthContext - User authentication</li>
                <li>• React Context API for global state</li>
                <li>• Persistent across routes</li>
              </ul>
            </div>

            <div className="bg-white/10 backdrop-blur-sm rounded-lg p-6">
              <h3 className="text-xl font-bold mb-3">New Routes</h3>
              <ul className="space-y-2 text-sm font-mono">
                <li>• /checkout - Checkout page</li>
                <li>• /products - Enhanced with medications</li>
                <li>• /pricing - Enhanced with buy plans</li>
              </ul>
            </div>

            <div className="bg-white/10 backdrop-blur-sm rounded-lg p-6">
              <h3 className="text-xl font-bold mb-3">New Components</h3>
              <ul className="space-y-2 text-sm font-mono">
                <li>• CartSheet - Shopping cart sidebar</li>
                <li>• CheckoutPage - Multi-step checkout</li>
                <li>• Login modals - Auth UI</li>
                <li>• Add-ons Dialog - Plan customization</li>
              </ul>
            </div>

            <div className="bg-white/10 backdrop-blur-sm rounded-lg p-6">
              <h3 className="text-xl font-bold mb-3">Libraries Used</h3>
              <ul className="space-y-2 text-sm font-mono">
                <li>• React Router - Navigation</li>
                <li>• Sonner - Toast notifications</li>
                <li>• Radix UI - Dialogs & Sheets</li>
                <li>• Lucide React - Icons</li>
              </ul>
            </div>
          </div>
        </section>

        {/* Footer */}
        <section className="bg-gray-800 rounded-lg p-6 text-white text-center">
          <p className="text-sm opacity-80">
            ★ = New or significantly updated feature | All pricing in Indian Rupees (₹)
          </p>
          <p className="text-xs opacity-60 mt-2">
            This wireframe reflects the complete e-commerce enabled Dr. MOTABHAI weight loss clinic website
          </p>
        </section>
      </div>
    </div>
  );
}
