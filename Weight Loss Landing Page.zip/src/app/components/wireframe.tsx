export function Wireframe() {
  return (
    <div className="min-h-screen bg-gray-50 p-8" style={{ fontFamily: 'DM Sans' }}>
      <div className="max-w-7xl mx-auto space-y-8">
        {/* Title */}
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold mb-2">Dr. MOTABHAI GLP-1 Weight Loss Landing Page</h1>
          <p className="text-gray-600">Complete High-Fidelity Wireframe - All Sections & Content</p>
          <p className="text-sm text-gray-500 mt-2">Scroll to view full page flow</p>
        </div>

        {/* Header / Navigation */}
        <section className="bg-white rounded-lg p-6 border-2 border-blue-500 shadow-lg">
          <div className="flex items-center justify-between mb-3">
            <span className="text-xs font-semibold text-blue-600 uppercase">HEADER - Fixed Position, Absolute</span>
            <span className="text-xs text-gray-500">z-index: 50 | Height: ~60px compact</span>
          </div>
          <div className="border-2 border-dashed border-blue-400 rounded p-5 bg-gradient-to-b from-black/20 to-transparent">
            <div className="flex items-center justify-between">
              {/* Brand Logo */}
              <div className="flex items-center gap-2">
                <div className="h-10 w-52 bg-white/80 rounded flex items-center justify-center">
                  <span className="text-xs font-bold" style={{ fontFamily: 'Bebas Neue', letterSpacing: '-0.04em' }}>
                    DR MOTABHAI™
                  </span>
                </div>
              </div>
              
              {/* Desktop Nav */}
              <div className="hidden lg:flex gap-6 items-center">
                <div className="h-6 w-24 bg-white/60 rounded flex items-center justify-center text-xs">Treatments</div>
                <div className="h-6 w-32 bg-white/60 rounded flex items-center justify-center text-xs">How It Works</div>
                <div className="h-6 w-20 bg-white/60 rounded flex items-center justify-center text-xs">About</div>
                <div className="h-6 w-24 bg-[#E8BFB8] rounded flex items-center justify-center text-xs font-semibold">Book Now</div>
              </div>
            </div>
            <div className="mt-3 text-center">
              <p className="text-xs text-gray-700 italic">Backdrop: Semi-transparent dark gradient with blur</p>
            </div>
          </div>
        </section>

        {/* Hero Section */}
        <section className="bg-white rounded-lg p-6 border-2 border-green-500 shadow-lg">
          <div className="flex items-center justify-between mb-3">
            <span className="text-xs font-semibold text-green-600 uppercase">HERO SECTION</span>
            <span className="text-xs text-gray-500">900px height | Full-width background image</span>
          </div>
          <div className="border-2 border-dashed border-green-400 rounded overflow-hidden bg-gradient-to-b from-[#374d5a] to-[#56839d]">
            {/* Visual representation */}
            <div className="relative h-[600px] p-6">
              {/* Watermark */}
              <div className="absolute inset-0 flex items-start justify-center pt-12 opacity-25">
                <span className="text-6xl text-[#779db3]" style={{ fontFamily: 'Bebas Neue' }}>DR MOTABHAI™</span>
              </div>

              {/* Hero Image Placeholder */}
              <div className="absolute inset-0 flex items-center justify-center">
                <div className="w-full h-full max-w-[90%] bg-gradient-to-br from-gray-400 to-gray-600 flex items-center justify-center rounded-lg">
                  <div className="text-center text-white">
                    <p className="text-sm font-semibold mb-2">Full-Width Hero Image</p>
                    <p className="text-xs">Diverse people exercising in gym</p>
                    <p className="text-xs">100% width × 100% height</p>
                    <p className="text-xs mt-2">cover | center position</p>
                  </div>
                </div>
              </div>

              {/* Gradient Overlay */}
              <div className="absolute bottom-0 left-0 right-0 h-1/2 bg-gradient-to-t from-black/85 to-transparent"></div>

              {/* Content Layer */}
              <div className="absolute bottom-0 left-0 right-0 p-8 space-y-4 z-10">
                {/* Title */}
                <div className="bg-white/10 backdrop-blur-sm rounded-lg p-4 max-w-3xl mx-auto">
                  <p className="text-white text-center" style={{ fontFamily: 'DM Sans', fontSize: 'clamp(28px, 4vw, 48px)', lineHeight: '1.25' }}>
                    GLP-1 Medical Weight Loss Program with Dr Motabhai
                  </p>
                </div>

                {/* Subtitle */}
                <div className="bg-white/10 backdrop-blur-sm rounded-lg p-3 max-w-2xl mx-auto">
                  <p className="text-white/90 text-center text-sm">
                    Doctor-led weight loss. Evidence-based GLP-1 treatment. Personally and medically monitored.
                  </p>
                </div>

                {/* CTA Buttons */}
                <div className="flex items-center justify-center gap-4 flex-wrap">
                  <div className="h-14 w-60 bg-[#55675E] rounded-full flex items-center justify-center text-white text-sm font-medium">
                    Book Consultation
                  </div>
                  <div className="h-14 w-52 border-2 border-[#E8BFB8] rounded-full flex items-center justify-center text-[#E8BFB8] text-sm">
                    Learn About GLP-1
                  </div>
                </div>
              </div>
            </div>

            {/* Specifications */}
            <div className="bg-gray-100 p-4 space-y-2 text-xs">
              <p><strong>Background:</strong> Gradient from #374d5a to #56839d</p>
              <p><strong>Watermark:</strong> DR MOTABHAI™ (Bebas Neue, clamp 80px-180px, opacity 25%, color #779db3)</p>
              <p><strong>Image:</strong> People exercising - Full width/height coverage</p>
              <p><strong>Overlay:</strong> Black gradient from bottom (85% opacity to transparent)</p>
              <p><strong>CTA Positioning:</strong> Desktop - side by side at bottom 80px | Mobile - stacked</p>
            </div>
          </div>
        </section>

        {/* Treatments Section */}
        <section className="bg-white rounded-lg p-6 border-2 border-purple-500 shadow-lg">
          <div className="flex items-center justify-between mb-3">
            <span className="text-xs font-semibold text-purple-600 uppercase">TREATMENTS SECTION</span>
            <span className="text-xs text-gray-500">Background: White | py-20 lg:py-28</span>
          </div>
          <div className="border-2 border-dashed border-purple-400 rounded p-6 bg-white">
            {/* Section Title */}
            <div className="bg-purple-100 rounded-lg p-4 mb-6 text-center">
              <p className="text-gray-900 font-normal" style={{ fontFamily: 'DM Sans', fontSize: 'clamp(24px, 3vw, 36px)' }}>
                Our Most Trusted Doctor-Prescribed Weight Loss Treatments
              </p>
            </div>

            {/* Cards Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              {/* GLP-1 Featured Card */}
              <div className="bg-gradient-to-br from-[#4A6B78] via-[#55675E] to-[#3E5147] rounded-2xl p-6 min-h-[320px] relative border-4 border-purple-400">
                <div className="space-y-3">
                  {/* Badge */}
                  <div className="inline-block bg-white/20 px-3 py-1 rounded-full">
                    <span className="text-white text-xs font-semibold uppercase tracking-wide">Most Popular</span>
                  </div>
                  
                  {/* Title */}
                  <div className="bg-white/10 rounded p-2">
                    <p className="text-white" style={{ fontFamily: 'Bebas Neue', fontSize: '32px', lineHeight: '1.1' }}>
                      GLP-1 Weight Loss Programme
                    </p>
                  </div>

                  {/* Description */}
                  <div className="bg-white/5 rounded p-2">
                    <p className="text-white/80 text-xs">
                      Evidence-based medical treatments for sustainable, doctor-monitored results
                    </p>
                  </div>

                  {/* Feature Checklist */}
                  <div className="space-y-1.5 pt-2">
                    <div className="flex items-center gap-2 text-white/70 text-xs">
                      <span>✓</span>
                      <span>Doctor prescribed</span>
                    </div>
                    <div className="flex items-center gap-2 text-white/70 text-xs">
                      <span>✓</span>
                      <span>Medically monitored</span>
                    </div>
                    <div className="flex items-center gap-2 text-white/70 text-xs">
                      <span>✓</span>
                      <span>Proven results</span>
                    </div>
                  </div>
                </div>

                {/* Hover indicator */}
                <div className="absolute bottom-0 left-0 right-0 h-1 bg-gradient-to-r from-[#E8BFB8] to-white rounded-b-2xl"></div>
              </div>

              {/* Treatment Product Cards */}
              {['Ozempic', 'Semaglutide', 'Mounjaro'].map((name) => (
                <div key={name} className="bg-white rounded-2xl p-6 border-2 border-gray-200 shadow-sm">
                  {/* Icon/Visual */}
                  <div className="h-40 bg-gradient-to-b from-gray-50 to-white rounded-xl mb-6 flex items-center justify-center">
                    <div className="w-12 h-32 bg-gradient-to-b from-[#55675E] to-[#7A9B8A] rounded-full"></div>
                  </div>
                  
                  {/* Title */}
                  <div className="bg-gray-50 rounded p-2 mb-2 text-center">
                    <p className="text-gray-900 text-sm font-medium">{name} Injection for Medical Weight Loss</p>
                  </div>

                  {/* Price */}
                  <div className="bg-gray-50 rounded p-2 mb-6 text-center">
                    <p className="text-gray-600 text-xs">Starting from ₹30,000 per month</p>
                  </div>

                  {/* CTA */}
                  <div className="h-12 bg-[#55675E] rounded-lg text-white flex items-center justify-center text-sm font-medium">
                    Get Started
                  </div>
                </div>
              ))}
            </div>

            {/* Specifications */}
            <div className="mt-6 bg-purple-50 rounded p-4 space-y-1 text-xs">
              <p><strong>Grid:</strong> 1 col mobile, 2 cols tablet, 4 cols desktop</p>
              <p><strong>GLP-1 Card:</strong> Gradient background with decorative glowing orbs, "Most Popular" badge, Bebas Neue heading (32px), feature checklist with checkmarks, hover effects with shadow and gradient underline</p>
              <p><strong>Product Cards:</strong> White background, visual representation of injection vial, product name, price, CTA button (#55675E)</p>
            </div>
          </div>
        </section>

        {/* Weight Loss Program Section */}
        <section className="bg-white rounded-lg p-6 border-2 border-teal-500 shadow-lg">
          <div className="flex items-center justify-between mb-3">
            <span className="text-xs font-semibold text-teal-600 uppercase">WEIGHT LOSS PROGRAM SECTION</span>
            <span className="text-xs text-gray-500">Background: #55675E | py-20 lg:py-28</span>
          </div>
          <div className="border-2 border-dashed border-teal-400 rounded p-6 bg-[#55675E]">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
              {/* Left Content */}
              <div className="bg-[#4A6B78] rounded-2xl p-6 space-y-4">
                <div className="bg-white/10 rounded p-2">
                  <p className="text-white" style={{ fontFamily: 'Bebas Neue', fontSize: 'clamp(32px, 5vw, 48px)' }}>
                    DR. MOTABHAI <sup className="text-sm">TM</sup>
                  </p>
                </div>

                <div className="bg-white/10 rounded p-3">
                  <p className="text-white" style={{ fontFamily: 'DM Sans', fontSize: 'clamp(60px, 10vw, 120px)', fontWeight: '700', lineHeight: '0.9' }}>
                    12%
                  </p>
                </div>

                <div className="bg-white/5 rounded p-3 space-y-2 text-xs text-white/90">
                  <p><strong>Achieve Sustainable Weight Loss</strong> with Clinically Supervised GLP-1 Treatment</p>
                  <p>Patients under Dr Motabhai have achieved up to <strong>12–15% total body weight reduction</strong> through responsible GLP-1 medical therapy.</p>
                  <p className="text-white/70 text-[10px] italic">*Results vary based on individual medical evaluation</p>
                </div>

                <div className="h-12 bg-white/90 rounded-lg flex items-center justify-center text-gray-900 font-medium text-sm">
                  Get Started
                </div>
              </div>

              {/* Right Content - Calculator Widget */}
              <div className="bg-[#3E5147] rounded-3xl p-8 space-y-6">
                <div className="text-center">
                  <p className="text-white/60 text-xs uppercase tracking-widest mb-4">Lose up to</p>
                  <p className="text-white" style={{ fontFamily: 'DM Sans', fontSize: 'clamp(48px, 8vw, 80px)', fontWeight: '700' }}>
                    5Kg
                  </p>
                </div>

                {/* Calculator Card */}
                <div className="bg-white rounded-2xl p-6 space-y-4">
                  <p className="text-gray-500 text-xs uppercase tracking-widest">Current Weight</p>
                  
                  {/* Slider */}
                  <div className="relative">
                    <div className="h-1 bg-gray-200 rounded-full"></div>
                    <div className="absolute top-0 left-0 h-1 bg-[#55675E] w-[45%] rounded-full"></div>
                    <div className="absolute top-[-5px] left-[45%] w-3.5 h-3.5 bg-[#55675E] rounded-full border-2 border-white shadow-md"></div>
                  </div>

                  {/* Weight Display */}
                  <div className="flex justify-center">
                    <span className="px-4 py-1.5 bg-gray-100 rounded-full text-gray-900 text-sm font-medium">
                      85 KG
                    </span>
                  </div>
                </div>
              </div>
            </div>

            {/* Specifications */}
            <div className="mt-6 bg-teal-900 rounded p-4 space-y-1 text-xs text-white">
              <p><strong>Layout:</strong> 2-column grid (stacked on mobile)</p>
              <p><strong>Left:</strong> Brand logo, 12% stat (120px), description text, CTA button</p>
              <p><strong>Right:</strong> Interactive weight calculator with slider showing potential weight loss</p>
              <p><strong>Typography:</strong> Mix of Bebas Neue for brand/stats, DM Sans for body</p>
            </div>
          </div>
        </section>

        {/* How It Works Section */}
        <section className="bg-white rounded-lg p-6 border-2 border-orange-500 shadow-lg">
          <div className="flex items-center justify-between mb-3">
            <span className="text-xs font-semibold text-orange-600 uppercase">HOW IT WORKS SECTION</span>
            <span className="text-xs text-gray-500">Background: White | 3-Step Process | py-20 lg:py-28</span>
          </div>
          <div className="border-2 border-dashed border-orange-400 rounded p-6 bg-white">
            {/* Section Title */}
            <div className="bg-orange-100 rounded-lg p-4 mb-8 text-center">
              <p className="text-gray-900 font-normal" style={{ fontFamily: 'DM Sans', fontSize: 'clamp(24px, 3vw, 36px)' }}>
                This Is Not a Generic Program. It Is a Medical Responsibility.
              </p>
            </div>

            {/* Content Grid */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
              {/* Left: Image */}
              <div className="bg-gradient-to-br from-gray-300 to-gray-500 rounded-3xl p-8 min-h-[500px] flex items-end">
                <div className="bg-black/50 backdrop-blur-sm rounded-lg p-4">
                  <p className="text-white text-sm leading-tight">
                    <strong>Image:</strong> Wellness/healthy person<br />
                    <strong>Overlay Text:</strong> "Weight Loss, Under Medical Responsibility and Doctor Supervision"
                  </p>
                </div>
              </div>

              {/* Right: Content */}
              <div className="space-y-6">
                {/* Subtitle */}
                <div className="bg-orange-50 rounded-lg p-4">
                  <p className="text-gray-900 font-medium" style={{ fontFamily: 'DM Sans', fontSize: 'clamp(20px, 2.5vw, 28px)' }}>
                    Medical Guidance — Not Guesswork.
                  </p>
                </div>

                {/* Body Text */}
                <div className="bg-gray-50 rounded-lg p-4">
                  <p className="text-gray-600 text-xs leading-relaxed">
                    Weight loss is not a challenge to complete or a plan to follow blindly. It is a personal, medical journey that affects your metabolism, hormones, and long-term health. Dr Motabhai exists to walk alongside you — firmly, honestly, and with clinical responsibility — so that every decision is made in your best interest.
                  </p>
                </div>

                {/* 3 Steps */}
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div className="bg-gray-50 rounded-xl p-4 border border-gray-200">
                    <p className="text-gray-400 text-[10px] uppercase tracking-wider mb-2">Step 01</p>
                    <p className="text-gray-900 text-xs font-medium mb-2">Comprehensive Clinical Evaluation</p>
                    <p className="text-gray-600 text-[10px] leading-relaxed">Doctor-led medical assessment covering health history, metabolic profile, and eligibility for GLP-1 medical weight loss treatment.</p>
                  </div>
                  
                  <div className="bg-gray-50 rounded-xl p-4 border border-gray-200">
                    <p className="text-gray-400 text-[10px] uppercase tracking-wider mb-2">Step 02</p>
                    <p className="text-gray-900 text-xs font-medium mb-2">Doctor-Prescribed GLP-1 Medication</p>
                    <p className="text-gray-600 text-[10px] leading-relaxed">GLP-1 therapy is prescribed only when medically appropriate, with personalised dosing for safety and effectiveness.</p>
                  </div>
                  
                  <div className="bg-gray-50 rounded-xl p-4 border border-gray-200">
                    <p className="text-gray-400 text-[10px] uppercase tracking-wider mb-2">Step 03</p>
                    <p className="text-gray-900 text-xs font-medium mb-2">Ongoing Medical Monitoring</p>
                    <p className="text-gray-600 text-[10px] leading-relaxed">Regular follow-ups, dosage optimisation, and clinical supervision ensure safe and sustained weight loss results.</p>
                  </div>
                </div>
              </div>
            </div>

            {/* Specifications */}
            <div className="mt-6 bg-orange-50 rounded p-4 space-y-1 text-xs">
              <p><strong>Layout:</strong> 2-column grid (image left, content right) - stacked on mobile</p>
              <p><strong>Image:</strong> Large rounded image with text overlay at bottom</p>
              <p><strong>Steps:</strong> 3 cards in horizontal row (stack on smaller screens)</p>
              <p><strong>Message:</strong> Emphasizes medical responsibility over generic programs</p>
            </div>
          </div>
        </section>

        {/* Testimonials Section */}
        <section className="bg-white rounded-lg p-6 border-2 border-indigo-500 shadow-lg">
          <div className="flex items-center justify-between mb-3">
            <span className="text-xs font-semibold text-indigo-600 uppercase">TESTIMONIALS SECTION</span>
            <span className="text-xs text-gray-500">Background: #E6EEEA | py-20 lg:py-28</span>
          </div>
          <div className="border-2 border-dashed border-indigo-400 rounded p-6 bg-[#E6EEEA]">
            {/* Section Title */}
            <div className="bg-indigo-100 rounded-lg p-4 mb-8 text-center">
              <p className="text-gray-900 font-normal" style={{ fontFamily: 'DM Sans', fontSize: 'clamp(24px, 3vw, 36px)' }}>
                Inspiring <span className="italic">transformation</span> stories.
              </p>
            </div>

            {/* Testimonial Card */}
            <div className="bg-[#4A6B78] rounded-3xl p-6">
              <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
                {/* Before Section */}
                <div className="lg:col-span-4 space-y-3">
                  {/* Before Image */}
                  <div className="bg-gray-400 rounded-2xl h-[300px] flex items-center justify-center relative">
                    <div className="absolute top-4 left-4 bg-black/30 px-3 py-1 rounded-md backdrop-blur-sm">
                      <span className="text-white text-xs font-medium">Before</span>
                    </div>
                    <span className="text-white text-xs">Before Photo</span>
                  </div>

                  {/* Stats Card */}
                  <div className="bg-[#3E5147] rounded-2xl p-4 space-y-3">
                    <div>
                      <p className="text-white/60 text-[10px] uppercase tracking-wider">Lost</p>
                      <p className="text-white text-xl font-bold">12 KG</p>
                    </div>
                    <div>
                      <p className="text-white/60 text-[10px] uppercase tracking-wider">Timeframe</p>
                      <p className="text-white text-xl font-bold">5 Months</p>
                    </div>
                  </div>
                </div>

                {/* Arrow Divider */}
                <div className="lg:col-span-1 flex items-center justify-center">
                  <div className="w-12 h-12 bg-white/20 rounded-full flex items-center justify-center backdrop-blur-sm">
                    <span className="text-white text-xl">→</span>
                  </div>
                </div>

                {/* After Section */}
                <div className="lg:col-span-7 space-y-4">
                  {/* After Image */}
                  <div className="bg-gray-400 rounded-2xl h-[300px] flex items-center justify-center">
                    <span className="text-white text-xs">After Photo</span>
                  </div>

                  {/* Testimonial Card */}
                  <div className="bg-[#3E5147] rounded-2xl p-4 space-y-3">
                    <p className="text-white text-sm font-medium">Jay's Story</p>
                    <p className="text-white/80 italic text-xs leading-relaxed">
                      "I stopped fighting hunger all day. For the first time, food stopped running my schedule. The doctor was clear about dosing, and patience. Nothing felt rushed. That mattered."
                    </p>
                    <p className="text-white/60 text-[10px]">
                      — 38, Mumbai. On GLP-1 for 5 months
                    </p>
                  </div>
                </div>
              </div>
            </div>

            {/* Specifications */}
            <div className="mt-6 bg-indigo-50 rounded p-4 space-y-1 text-xs">
              <p><strong>Layout:</strong> Before/After comparison with arrow divider (12-column grid)</p>
              <p><strong>Before:</strong> Image with badge, stats card showing weight lost and timeframe</p>
              <p><strong>After:</strong> Larger after image, testimonial card with name, quote, and attribution</p>
              <p><strong>Card Background:</strong> #4A6B78 teal with rounded corners</p>
            </div>
          </div>
        </section>

        {/* Footer */}
        <section className="bg-white rounded-lg p-6 border-2 border-gray-500 shadow-lg">
          <div className="flex items-center justify-between mb-3">
            <span className="text-xs font-semibold text-gray-600 uppercase">FOOTER</span>
            <span className="text-xs text-gray-500">Background: #2A3A35 | py-12</span>
          </div>
          <div className="border-2 border-dashed border-gray-400 rounded p-6 bg-[#2A3A35]">
            <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-6">
              {/* Brand */}
              <div className="md:col-span-2 bg-[#1f2d28] rounded-lg p-4">
                <div className="bg-white/10 rounded p-2 mb-3 inline-block">
                  <span className="text-white" style={{ fontFamily: 'Bebas Neue', fontSize: '24px' }}>
                    DR. MOTABHAI<sup className="text-[8px]">TM</sup>
                  </span>
                </div>
                <p className="text-gray-400 text-xs leading-relaxed">
                  Doctor-led weight loss with evidence-based GLP-1 treatments. Weight loss under medical responsibility.
                </p>
              </div>

              {/* Quick Links */}
              <div className="bg-[#1f2d28] rounded-lg p-4">
                <p className="text-white text-xs font-medium mb-3">Quick Links</p>
                <div className="space-y-2">
                  {['Weight Loss', 'How It Works', 'About Us', 'Contact'].map((link) => (
                    <div key={link} className="h-4 bg-gray-700 rounded text-[10px] text-gray-400 flex items-center px-2">
                      {link}
                    </div>
                  ))}
                </div>
              </div>

              {/* Legal */}
              <div className="bg-[#1f2d28] rounded-lg p-4">
                <p className="text-white text-xs font-medium mb-3">Legal</p>
                <div className="space-y-2">
                  {['Privacy Policy', 'Terms of Service', 'Medical Disclaimer'].map((link) => (
                    <div key={link} className="h-4 bg-gray-700 rounded text-[10px] text-gray-400 flex items-center px-2">
                      {link}
                    </div>
                  ))}
                </div>
              </div>
            </div>

            {/* Bottom Bar */}
            <div className="border-t border-gray-700 pt-4 text-center">
              <p className="text-gray-500 text-xs">© 2026 Dr. MOTABHAI. All rights reserved.</p>
            </div>

            {/* Specifications */}
            <div className="mt-6 bg-gray-800 rounded p-4 space-y-1 text-xs text-gray-300">
              <p><strong>Grid:</strong> 4 columns (Brand spans 2 cols, Links col, Legal col)</p>
              <p><strong>Links:</strong> Hover effects with color transition to white</p>
              <p><strong>Typography:</strong> Bebas Neue for brand, DM Sans for all other text</p>
            </div>
          </div>
        </section>

        {/* Design System Specifications */}
        <section className="bg-gradient-to-br from-blue-500 to-indigo-600 rounded-lg p-8 shadow-2xl text-white">
          <h3 className="text-2xl font-bold mb-6">Complete Design System Specifications</h3>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {/* Typography */}
            <div className="bg-white/10 backdrop-blur-sm rounded-lg p-4">
              <h4 className="font-bold mb-3 text-lg">Typography</h4>
              <ul className="space-y-2 text-sm">
                <li><strong>Headings:</strong> <span style={{ fontFamily: 'Bebas Neue' }}>Bebas Neue</span></li>
                <li><strong>Body:</strong> <span style={{ fontFamily: 'DM Sans' }}>DM Sans</span></li>
                <li><strong>Hero Title:</strong> clamp(28px, 4vw, 48px)</li>
                <li><strong>Section Titles:</strong> clamp(24px, 3vw, 36px)</li>
                <li><strong>Large Stats:</strong> clamp(60px, 10vw, 120px)</li>
                <li><strong>Letter Spacing:</strong> -0.02em to -0.04em</li>
              </ul>
            </div>

            {/* Color Palette */}
            <div className="bg-white/10 backdrop-blur-sm rounded-lg p-4">
              <h4 className="font-bold mb-3 text-lg">Color Palette</h4>
              <div className="space-y-2 text-xs">
                <div className="flex items-center gap-2">
                  <div className="w-6 h-6 bg-[#374D5A] rounded border-2 border-white"></div>
                  <span>#374D5A - Dark Teal</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-6 h-6 bg-[#56839D] rounded border-2 border-white"></div>
                  <span>#56839D - Light Blue</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-6 h-6 bg-[#4A6B78] rounded border-2 border-white"></div>
                  <span>#4A6B78 - Brand Teal</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-6 h-6 bg-[#55675E] rounded border-2 border-white"></div>
                  <span>#55675E - Accent Green</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-6 h-6 bg-[#3E5147] rounded border-2 border-white"></div>
                  <span>#3E5147 - Dark Green</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-6 h-6 bg-[#E8BFB8] rounded border-2 border-white"></div>
                  <span>#E8BFB8 - Accent Pink</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-6 h-6 bg-[#779DB3] rounded border-2 border-white"></div>
                  <span>#779DB3 - Light Teal</span>
                </div>
              </div>
            </div>

            {/* Layout & Components */}
            <div className="bg-white/10 backdrop-blur-sm rounded-lg p-4">
              <h4 className="font-bold mb-3 text-lg">Layout & Components</h4>
              <ul className="space-y-2 text-sm">
                <li><strong>Max Width:</strong> 1440px</li>
                <li><strong>Container:</strong> max-w-7xl</li>
                <li><strong>Section Padding:</strong> py-20 lg:py-28</li>
                <li><strong>Button Radius:</strong> 50px (pills)</li>
                <li><strong>Card Radius:</strong> 16-24px</li>
                <li><strong>Grid Gaps:</strong> 4-6 (16-24px)</li>
                <li><strong>Responsive:</strong> Mobile-first</li>
                <li><strong>Breakpoints:</strong> md:768px, lg:1024px</li>
              </ul>
            </div>
          </div>

          {/* Page Flow */}
          <div className="mt-6 bg-white/10 backdrop-blur-sm rounded-lg p-4">
            <h4 className="font-bold mb-3 text-lg">Page Flow & User Journey</h4>
            <div className="flex items-center gap-3 overflow-x-auto pb-2">
              <div className="bg-blue-600 px-4 py-2 rounded-full text-xs whitespace-nowrap">1. Hero CTA</div>
              <span>→</span>
              <div className="bg-purple-600 px-4 py-2 rounded-full text-xs whitespace-nowrap">2. View Treatments</div>
              <span>→</span>
              <div className="bg-teal-600 px-4 py-2 rounded-full text-xs whitespace-nowrap">3. See Results (12%)</div>
              <span>→</span>
              <div className="bg-orange-600 px-4 py-2 rounded-full text-xs whitespace-nowrap">4. Learn Process</div>
              <span>→</span>
              <div className="bg-indigo-600 px-4 py-2 rounded-full text-xs whitespace-nowrap">5. Read Testimonial</div>
              <span>→</span>
              <div className="bg-green-600 px-4 py-2 rounded-full text-xs whitespace-nowrap">6. Book Consultation</div>
            </div>
          </div>

          {/* Key Features */}
          <div className="mt-6 bg-white/10 backdrop-blur-sm rounded-lg p-4">
            <h4 className="font-bold mb-3 text-lg">Key Features & Interactions</h4>
            <ul className="grid grid-cols-1 md:grid-cols-2 gap-2 text-sm">
              <li>✓ Fixed header with backdrop blur</li>
              <li>✓ Full-screen hero with layered content</li>
              <li>✓ Featured GLP-1 card with gradient & hover effects</li>
              <li>✓ Interactive weight calculator widget</li>
              <li>✓ 3-step process explanation</li>
              <li>✓ Before/after testimonial comparison</li>
              <li>✓ Multiple CTA placements</li>
              <li>✓ Fully responsive across all devices</li>
            </ul>
          </div>
        </section>

        {/* Technical Notes */}
        <section className="bg-yellow-50 border-2 border-yellow-400 rounded-lg p-6">
          <h3 className="text-lg font-bold mb-4 text-yellow-900">Technical Implementation Notes</h3>
          <ul className="space-y-2 text-sm text-yellow-900">
            <li><strong>React Components:</strong> Modular structure with separate files for each section</li>
            <li><strong>Styling:</strong> Tailwind CSS v4 + Custom CSS in theme.css for precise positioning</li>
            <li><strong>Images:</strong> Unsplash API integration via ImageWithFallback component</li>
            <li><strong>Fonts:</strong> Google Fonts - Bebas Neue & DM Sans (imported in fonts.css)</li>
            <li><strong>Responsive:</strong> Mobile-first approach with breakpoints at 768px and 1024px</li>
            <li><strong>Z-indexing:</strong> Layered hero section (bg=1, watermark=2, image=3, overlay=4, content=10, header=50)</li>
            <li><strong>Animations:</strong> Hover states, transitions, gradient effects</li>
            <li><strong>Accessibility:</strong> Semantic HTML, ARIA labels, proper heading hierarchy</li>
          </ul>
        </section>
      </div>
    </div>
  );
}
