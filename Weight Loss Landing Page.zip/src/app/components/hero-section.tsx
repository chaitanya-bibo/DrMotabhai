import { ImageWithFallback } from "@/app/components/figma/ImageWithFallback";
import heroImage from "figma:asset/bc2c3a9698f5cf5946f75d20a7dd86e042ddcd47.png";

export function HeroSection() {
  return (
    <section className="relative w-full h-[900px] overflow-hidden">
      {/* Background Gradient */}
      <div className="hero-bg"></div>

      {/* Watermark */}
      <div className="hero-watermark">DR MOTABHAI™</div>

      {/* Hero Image */}
      <div 
        className="hero-image" 
        style={{
          backgroundImage: `url(${heroImage})`
        }}
        aria-label="People on their fitness journey"
      ></div>

      {/* Gradient Overlay */}
      <div className="hero-overlay"></div>

      {/* Hero Title */}
      <h1 className="hero-title">
        GLP-1 Medical Weight Loss Program with Dr Motabhai
      </h1>

      {/* Hero Subtitle */}
      <h2 className="hero-subtitle">
        Doctor-led weight loss. Evidence-based GLP-1 treatment. Personally and medically monitored.
      </h2>

      {/* Primary CTA */}
      <a href="#consultation" className="btn-primary">
        Book Consultation
      </a>

      {/* Secondary CTA */}
      <a href="#glp1" className="btn-secondary">
        Learn About GLP-1
      </a>
    </section>
  );
}