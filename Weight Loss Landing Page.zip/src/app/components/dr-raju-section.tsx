import { useState } from "react";
import { Award, ChevronDown, Play } from "lucide-react";
import { Link } from "react-router-dom";

export function DrRajuSection() {
  const [showVideos, setShowVideos] = useState(false);

  const videos = [
    {
      title: "Introduction to Dr. Raju's Approach",
      thumbnail: "https://images.unsplash.com/photo-1576091160399-112ba8d25d1d?w=400",
      duration: "5:23",
      url: "https://youtube.com/watch?v=example1"
    },
    {
      title: "Understanding GLP-1 Medications",
      thumbnail: "https://images.unsplash.com/photo-1576091160550-2173dba999ef?w=400",
      duration: "8:15",
      url: "https://youtube.com/watch?v=example2"
    },
    {
      title: "Patient Success Stories",
      thumbnail: "https://images.unsplash.com/photo-1551076805-e1869033e561?w=400",
      duration: "6:42",
      url: "https://youtube.com/watch?v=example3"
    },
    {
      title: "Your Weight Loss Journey",
      thumbnail: "https://images.unsplash.com/photo-1559757175-5700dde675bc?w=400",
      duration: "7:30",
      url: "https://youtube.com/watch?v=example4"
    }
  ];

  return (
    <section className="py-20 lg:py-28 bg-gradient-to-b from-white to-gray-50">
      <div className="container mx-auto px-4 lg:px-8 max-w-7xl">
        <div className="text-center mb-16">
          <h2 
            className="text-gray-900 mb-4"
            style={{ 
              fontFamily: 'Bebas Neue',
              fontSize: 'clamp(32px, 4vw, 48px)',
              letterSpacing: '0.02em'
            }}
          >
            Meet Your Expert
          </h2>
          <p 
            className="text-gray-600 max-w-2xl mx-auto"
            style={{ 
              fontFamily: 'DM Sans',
              fontSize: '16px',
              lineHeight: '1.6'
            }}
          >
            Led by Dr. Raju, a renowned expert in obesity medicine and GLP-1 therapy
          </p>
        </div>

        {/* Dr. Raju Card */}
        <div className="relative max-w-5xl mx-auto">
          <Link to="/education#dr-raju">
            <div className="bg-white rounded-3xl shadow-2xl overflow-hidden hover:shadow-3xl transition-all duration-300 group">
              <div className="grid grid-cols-1 md:grid-cols-5 gap-0">
                {/* Image Side */}
                <div className="md:col-span-2 relative h-80 md:h-auto">
                  <img
                    src="https://images.unsplash.com/photo-1612349317150-e413f6a5b16d?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxpbmRpYW4lMjBkb2N0b3IlMjBwcm9mZXNzaW9uYWx8ZW58MHx8fHwxNzM4MjU2ODAwfDA&ixlib=rb-4.1.0&q=80&w=1080"
                    alt="Dr. Raju"
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent md:hidden"></div>
                </div>

                {/* Content Side */}
                <div className="md:col-span-3 p-8 lg:p-12 flex flex-col justify-center">
                  <div className="flex items-center gap-3 mb-4">
                    <Award className="w-6 h-6 text-[#4A6B78]" />
                    <span className="text-sm font-semibold text-[#4A6B78] tracking-wider uppercase" style={{ fontFamily: 'DM Sans' }}>
                      Leading Expert
                    </span>
                  </div>

                  <h3 
                    className="mb-2"
                    style={{ 
                      fontFamily: 'Bebas Neue',
                      fontSize: 'clamp(28px, 3vw, 42px)',
                      letterSpacing: '0.02em',
                      color: '#1f2937'
                    }}
                  >
                    Dr. Raju
                  </h3>

                  <p 
                    className="text-xl mb-4 text-[#4A6B78] font-semibold"
                    style={{ fontFamily: 'DM Sans' }}
                  >
                    MD, FACP, FACE
                  </p>

                  <p 
                    className="text-gray-700 mb-6 leading-relaxed"
                    style={{ fontFamily: 'DM Sans', fontSize: '15px', lineHeight: '1.7' }}
                  >
                    Board-certified in Endocrinology and Obesity Medicine with over 20 years of experience. 
                    Dr. Raju specializes in GLP-1 therapy and has helped thousands of patients achieve 
                    life-changing weight loss results through personalized, evidence-based treatment.
                  </p>

                  {/* Quick Stats */}
                  <div className="grid grid-cols-3 gap-4 mb-6 pb-6 border-b border-gray-200">
                    <div>
                      <p className="text-3xl font-bold text-[#4A6B78]" style={{ fontFamily: 'DM Sans' }}>20+</p>
                      <p className="text-xs text-gray-600">Years Experience</p>
                    </div>
                    <div>
                      <p className="text-3xl font-bold text-[#4A6B78]" style={{ fontFamily: 'DM Sans' }}>2,500+</p>
                      <p className="text-xs text-gray-600">Patients Treated</p>
                    </div>
                    <div>
                      <p className="text-3xl font-bold text-[#4A6B78]" style={{ fontFamily: 'DM Sans' }}>4.9/5</p>
                      <p className="text-xs text-gray-600">Patient Rating</p>
                    </div>
                  </div>

                  <div className="flex items-center gap-3">
                    <span className="text-[#4A6B78] font-semibold group-hover:text-[#3E5147] transition-colors" style={{ fontFamily: 'DM Sans' }}>
                      Learn More About Dr. Raju →
                    </span>
                  </div>
                </div>
              </div>
            </div>
          </Link>

          {/* Expand Arrow Button */}
          <button
            onClick={() => setShowVideos(!showVideos)}
            className="absolute bottom-4 right-4 w-12 h-12 bg-[#4A6B78] hover:bg-[#3E5147] text-white rounded-full shadow-lg flex items-center justify-center transition-all z-10 group"
            aria-label="Show videos"
          >
            <ChevronDown 
              className={`w-6 h-6 transition-transform duration-300 ${showVideos ? 'rotate-180' : ''}`}
            />
          </button>

          {/* Expandable Video Section */}
          <div 
            className={`overflow-hidden transition-all duration-500 ease-in-out ${
              showVideos ? 'max-h-96 opacity-100 mt-6' : 'max-h-0 opacity-0'
            }`}
          >
            <div className="bg-white rounded-2xl shadow-xl p-6">
              <h4 
                className="text-xl font-bold text-gray-900 mb-6 flex items-center gap-2"
                style={{ fontFamily: 'DM Sans' }}
              >
                <Play className="w-5 h-5 text-[#4A6B78]" />
                Dr. Raju's Educational Videos
              </h4>
              
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                {videos.map((video, idx) => (
                  <a
                    key={idx}
                    href={video.url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="group cursor-pointer"
                  >
                    <div className="relative rounded-xl overflow-hidden shadow-md hover:shadow-xl transition-all">
                      <img
                        src={video.thumbnail}
                        alt={video.title}
                        className="w-full h-40 object-cover group-hover:scale-110 transition-transform duration-300"
                      />
                      <div className="absolute inset-0 bg-black/40 group-hover:bg-black/60 transition-colors flex items-center justify-center">
                        <div className="w-12 h-12 bg-white/90 rounded-full flex items-center justify-center group-hover:scale-110 transition-transform">
                          <Play className="w-6 h-6 text-[#4A6B78]" />
                        </div>
                      </div>
                      <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/80 to-transparent p-3">
                        <p className="text-white text-xs font-semibold" style={{ fontFamily: 'DM Sans' }}>
                          {video.title}
                        </p>
                        <p className="text-white/80 text-xs mt-1">{video.duration}</p>
                      </div>
                    </div>
                  </a>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
