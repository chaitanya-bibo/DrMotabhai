import { ImageWithFallback } from "@/app/components/figma/ImageWithFallback";

export function TestimonialsSection() {
  return (
    <section className="py-20 lg:py-28 bg-[#E6EEEA]">
      <div className="container mx-auto px-4 lg:px-8">
        {/* Section Title */}
        <h2 
          className="text-center text-gray-900 max-w-4xl mx-auto mb-16"
          style={{ 
            fontFamily: 'DM Sans',
            fontSize: 'clamp(24px, 3vw, 36px)',
            lineHeight: '1.3',
            letterSpacing: '-0.02em',
            fontWeight: '400'
          }}
        >
          Inspiring <span className="italic">transformation</span> stories.
        </h2>

        {/* Testimonial Card */}
        <div className="bg-[#4A6B78] rounded-3xl p-8 lg:p-12 max-w-7xl mx-auto relative overflow-hidden">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
            {/* Before Image & Stats */}
            <div className="lg:col-span-4 space-y-4">
              <div className="relative">
                <div className="absolute top-4 left-4 z-10 bg-black/30 px-3 py-1 rounded-md backdrop-blur-sm">
                  <span 
                    className="text-white text-xs font-medium"
                    style={{ 
                      fontFamily: 'DM Sans',
                      letterSpacing: '-0.01em'
                    }}
                  >
                    Before
                  </span>
                </div>
                <ImageWithFallback
                  src="https://images.unsplash.com/photo-1764148770912-2cc196f62725?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxoYXBweSUyMHdvbWFuJTIwcG9ydHJhaXQlMjB0cmFuc2Zvcm1hdGlvbnxlbnwxfHx8fDE3NzAxMjQzNTl8MA&ixlib=rb-4.1.0&q=80&w=1080"
                  alt="Before transformation"
                  className="w-full h-[400px] object-cover rounded-2xl"
                />
              </div>

              {/* Stats */}
              <div className="bg-[#3E5147] rounded-2xl p-6 space-y-4">
                <div>
                  <p 
                    className="text-white/60 text-xs uppercase tracking-wider mb-1"
                    style={{ 
                      fontFamily: 'DM Sans',
                      letterSpacing: '0.1em'
                    }}
                  >
                    Lost
                  </p>
                  <p 
                    className="text-white text-2xl font-bold"
                    style={{ 
                      fontFamily: 'DM Sans',
                      letterSpacing: '-0.02em'
                    }}
                  >
                    12 KG
                  </p>
                </div>

                <div>
                  <p 
                    className="text-white/60 text-xs uppercase tracking-wider mb-1"
                    style={{ 
                      fontFamily: 'DM Sans',
                      letterSpacing: '0.1em'
                    }}
                  >
                    Timeframe
                  </p>
                  <p 
                    className="text-white text-2xl font-bold"
                    style={{ 
                      fontFamily: 'DM Sans',
                      letterSpacing: '-0.02em'
                    }}
                  >
                    5 Months
                  </p>
                </div>
              </div>
            </div>

            {/* Arrow Divider */}
            <div className="lg:col-span-1 flex items-center justify-center">
              <div className="w-12 h-12 bg-white/20 rounded-full flex items-center justify-center backdrop-blur-sm">
                <svg className="w-6 h-6 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                </svg>
              </div>
            </div>

            {/* After Image & Testimonial */}
            <div className="lg:col-span-7 space-y-6">
              <ImageWithFallback
                src="https://images.unsplash.com/photo-1764148770912-2cc196f62725?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxoYXBweSUyMHdvbWFuJTIwcG9ydHJhaXQlMjB0cmFuc2Zvcm1hdGlvbnxlbnwxfHx8fDE3NzAxMjQzNTl8MA&ixlib=rb-4.1.0&q=80&w=1080"
                alt="After transformation"
                className="w-full h-[400px] object-cover rounded-2xl"
              />

              {/* Testimonial */}
              <div className="bg-[#3E5147] rounded-2xl p-6">
                <p 
                  className="text-white mb-4 font-medium"
                  style={{ 
                    fontFamily: 'DM Sans',
                    fontSize: '18px',
                    letterSpacing: '-0.01em'
                  }}
                >
                  Jay's Story
                </p>
                <p 
                  className="text-white/80 italic text-sm leading-relaxed"
                  style={{ 
                    fontFamily: 'DM Sans',
                    letterSpacing: '-0.01em'
                  }}
                >
                  "भूख से पूरे दिन लड़ना बंद हो गया। पहली बार, खाना मेरे शेड्यूल को नहीं चला रहा था। I stopped fighting hunger all day. For the first time, food stopped running my schedule. डॉक्टर ने डोजिंग और धैर्य के बारे में स्पष्ट रूप से बताया। The doctor was clear about dosing, and patience. कुछ भी जल्दबाजी में नहीं लगा। Nothing felt rushed. That mattered."
                </p>
                <p 
                  className="text-white/60 text-xs mt-3"
                  style={{ 
                    fontFamily: 'DM Sans',
                    letterSpacing: '-0.01em'
                  }}
                >
                  — जय (Jay), 38, मुंबई (Mumbai). GLP-1 पर 5 महीने से
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}