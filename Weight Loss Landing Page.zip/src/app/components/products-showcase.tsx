import { Link } from "react-router-dom";
import { ShoppingCart, Star } from "lucide-react";
import { ImageWithFallback } from "@/app/components/figma/ImageWithFallback";

export function ProductsShowcase() {
  const featuredProducts = [
    {
      id: 1,
      name: "Premium Whey Protein",
      price: "₹2,499",
      image: "https://images.unsplash.com/photo-1763757933292-d8290692edde?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwcm90ZWluJTIwcG93ZGVyJTIwc3VwcGxlbWVudCUyMGphcnxlbnwxfHx8fDE3NzAxMjQ3Mjd8MA&ixlib=rb-4.1.0&q=80&w=1080",
      rating: 4.8
    },
    {
      id: 2,
      name: "Protein Bars (Box of 12)",
      price: "₹899",
      image: "https://images.unsplash.com/photo-1679384323883-d5b0b9290e2b?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwcm90ZWluJTIwYmFycyUyMGhlYWx0aHklMjBzbmFja3xlbnwxfHx8fDE3NzAxMjQ3Mjh8MA&ixlib=rb-4.1.0&q=80&w=1080",
      rating: 4.6
    },
    {
      id: 3,
      name: "Multivitamin Complex",
      price: "₹699",
      image: "https://images.unsplash.com/photo-1763668331599-487470fb85b2?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx2aXRhbWlucyUyMHN1cHBsZW1lbnRzJTIwYm90dGxlc3xlbnwxfHx8fDE3NzAwMjU2NTF8MA&ixlib=rb-4.1.0&q=80&w=1080",
      rating: 4.7
    }
  ];

  return (
    <section className="py-16 lg:py-20 bg-gray-50">
      <div className="container mx-auto px-4 lg:px-8">
        {/* Section Header */}
        <div className="text-center mb-12">
          <h2 
            className="text-gray-900 mb-4"
            style={{ 
              fontFamily: 'DM Sans',
              fontSize: 'clamp(28px, 4vw, 40px)',
              lineHeight: '1.2',
              letterSpacing: '-0.02em',
              fontWeight: '600'
            }}
          >
            Support Your Journey
          </h2>
          <p 
            className="text-gray-600 max-w-2xl mx-auto mb-6"
            style={{ 
              fontFamily: 'DM Sans',
              fontSize: '16px',
              lineHeight: '1.6'
            }}
          >
            Premium wellness products to complement your weight loss program. No consultation required.
          </p>
        </div>

        {/* Products Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 max-w-5xl mx-auto mb-8">
          {featuredProducts.map((product) => (
            <div
              key={product.id}
              className="bg-white rounded-2xl overflow-hidden hover:shadow-lg transition-all group border border-gray-200"
            >
              {/* Product Image */}
              <div className="relative h-48 bg-gray-100 overflow-hidden">
                <ImageWithFallback
                  src={product.image}
                  alt={product.name}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                />
              </div>

              {/* Product Info */}
              <div className="p-5">
                <h3 
                  className="text-gray-900 mb-2"
                  style={{ 
                    fontFamily: 'DM Sans',
                    fontSize: '16px',
                    fontWeight: '600',
                    lineHeight: '1.4'
                  }}
                >
                  {product.name}
                </h3>
                
                {/* Rating */}
                <div className="flex items-center gap-1 mb-3">
                  <Star className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                  <span 
                    className="text-gray-900 text-sm font-semibold"
                    style={{ fontFamily: 'DM Sans' }}
                  >
                    {product.rating}
                  </span>
                </div>

                {/* Price */}
                <div className="flex items-center justify-between">
                  <span 
                    className="text-[#4A6B78] font-bold text-xl"
                    style={{ fontFamily: 'DM Sans' }}
                  >
                    {product.price}
                  </span>
                  <button 
                    className="p-2 bg-[#4A6B78] text-white rounded-lg hover:bg-[#3E5147] transition-all"
                  >
                    <ShoppingCart className="w-4 h-4" />
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* CTA */}
        <div className="text-center">
          <Link 
            to="/products"
            className="inline-flex items-center gap-2 px-8 py-4 bg-[#4A6B78] text-white rounded-lg hover:bg-[#3E5147] transition-all font-semibold shadow-md hover:shadow-lg"
            style={{ fontFamily: 'DM Sans', fontSize: '16px' }}
          >
            <ShoppingCart className="w-5 h-5" />
            View All Products
          </Link>
        </div>
      </div>
    </section>
  );
}
