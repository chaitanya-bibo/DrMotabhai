import { Link } from "react-router-dom";

export function Footer() {
  return (
    <footer className="bg-[#2A3A35] py-12">
      <div className="container mx-auto px-4 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8 max-w-6xl mx-auto mb-8">
          {/* Brand */}
          <div className="md:col-span-2">
            <div className="flex items-center gap-1 mb-4">
              <span 
                className="text-white tracking-tight" 
                style={{ fontFamily: 'Bebas Neue', fontSize: '28px', lineHeight: '1.2', letterSpacing: '0.08em' }}
              >
                DR MOTABHAI
              </span>
              <sup className="text-white" style={{ fontSize: '10px', marginLeft: '2px' }}>™</sup>
            </div>
            <p 
              className="text-gray-400 max-w-sm text-sm"
              style={{ 
                fontFamily: 'DM Sans',
                lineHeight: '1.6',
                letterSpacing: '-0.01em'
              }}
            >
              Doctor-led weight loss with evidence-based GLP-1 treatments. Weight loss under medical responsibility. Serving patients across India.
            </p>
            <p 
              className="text-gray-400 max-w-sm text-xs mt-3 italic"
              style={{ 
                fontFamily: 'DM Sans',
                lineHeight: '1.5',
                letterSpacing: '-0.01em'
              }}
            >
              मोटाभाई - आपके स्वास्थ्य यात्रा में विश्वसनीय मार्गदर्शक<br />
              Motabhai - Your trusted guide on the journey to better health
            </p>
          </div>

          {/* Quick Links */}
          <div>
            <h3 
              className="text-white mb-4 text-sm font-medium"
              style={{ 
                fontFamily: 'DM Sans',
                letterSpacing: '-0.01em'
              }}
            >
              Quick Links
            </h3>
            <ul className="space-y-2">
              {[
                { label: 'Treatments', path: '/treatments' },
                { label: 'Pricing', path: '/pricing' },
                { label: 'Eligibility', path: '/eligibility' },
                { label: 'FAQ', path: '/faq' },
                { label: 'View Wireframe', path: '/wireframe' }
              ].map((item) => (
                <li key={item.label}>
                  <Link 
                    to={item.path}
                    className="text-gray-400 hover:text-white transition-colors text-sm"
                    style={{ 
                      fontFamily: 'DM Sans',
                      letterSpacing: '-0.01em'
                    }}
                  >
                    {item.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Legal */}
          <div>
            <h3 
              className="text-white mb-4 text-sm font-medium"
              style={{ 
                fontFamily: 'DM Sans',
                letterSpacing: '-0.01em'
              }}
            >
              Legal
            </h3>
            <ul className="space-y-2">
              {['Privacy Policy', 'Terms of Service', 'Medical Disclaimer'].map((item) => (
                <li key={item}>
                  <a 
                    href="#" 
                    className="text-gray-400 hover:text-white transition-colors text-sm"
                    style={{ 
                      fontFamily: 'DM Sans',
                      letterSpacing: '-0.01em'
                    }}
                  >
                    {item}
                  </a>
                </li>
              ))}
            </ul>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="border-t border-gray-700 pt-8 text-center">
          <p 
            className="text-gray-500 text-sm"
            style={{ 
              fontFamily: 'DM Sans',
              letterSpacing: '-0.01em'
            }}
          >
            © 2026 Dr. MOTABHAI. All rights reserved.
          </p>
        </div>
      </div>
    </footer>
  );
}