import { ImageWithFallback } from "@/app/components/figma/ImageWithFallback";

export function MedicalPartners() {
  const doctors = [
    {
      name: "Dr. Rajesh Kumar",
      title: "MD, Endocrinology",
      specialization: "GLP-1 Specialist & Weight Management",
      experience: "15+ years",
      image: "https://images.unsplash.com/photo-1659353888906-adb3e0041693?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxJbmRpYW4lMjBkb2N0b3IlMjBwcm9mZXNzaW9uYWwlMjBoZWFsdGhjYXJlfGVufDF8fHx8MTc2OTY4NDc3Nnww&ixlib=rb-4.1.0&q=80&w=1080"
    },
    {
      name: "Dr. Priya Sharma",
      title: "MD, Internal Medicine",
      specialization: "Metabolic Health & Obesity Medicine",
      experience: "12+ years",
      image: "https://images.unsplash.com/photo-1659353888906-adb3e0041693?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxmZW1hbGUlMjBkb2N0b3IlMjBJbmRpYW4lMjBtZWRpY2FsJTIwcHJvZmVzc2lvbmFsfGVufDF8fHx8MTc2OTY4NDc3N3ww&ixlib=rb-4.1.0&q=80&w=1080"
    },
    {
      name: "Dr. Anil Mehta",
      title: "MD, Family Medicine",
      specialization: "Preventive Care & Chronic Disease Management",
      experience: "18+ years",
      image: "https://images.unsplash.com/photo-1659353888906-adb3e0041693?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxJbmRpYW4lMjBkb2N0b3IlMjBwcm9mZXNzaW9uYWwlMjBoZWFsdGhjYXJlfGVufDF8fHx8MTc2OTY4NDc3Nnww&ixlib=rb-4.1.0&q=80&w=1080"
    }
  ];

  const coaches = [
    {
      name: "Neha Patel",
      title: "Certified Fitness Coach",
      specialization: "Strength Training & Weight Loss Programs",
      credentials: "ACE-CPT, NASM-CPT",
      image: "https://images.unsplash.com/photo-1540206063137-4a88ca974d1a?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxmaXRuZXNzJTIwY29hY2glMjB0cmFpbmVyJTIwcHJvZmVzc2lvbmFsfGVufDF8fHx8MTc2OTU5Nzg3N3ww&ixlib=rb-4.1.0&q=80&w=1080"
    },
    {
      name: "Anjali Desai",
      title: "Registered Dietitian",
      specialization: "Clinical Nutrition & Metabolic Health",
      credentials: "RD, MSc Nutrition",
      image: "https://images.unsplash.com/photo-1736289154383-435d94804522?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxudXRyaXRpb25pc3QlMjBwcm9mZXNzaW9uYWwlMjBoZWFsdGhjYXJlJTIwd29tYW58ZW58MXx8fHwxNzY5Njg0Nzc3fDA&ixlib=rb-4.1.0&q=80&w=1080"
    },
    {
      name: "Vikram Singh",
      title: "Health & Wellness Coach",
      specialization: "Lifestyle Modification & Behavioral Change",
      credentials: "NBHWC, ACE-HC",
      image: "https://images.unsplash.com/photo-1540206063137-4a88ca974d1a?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxmaXRuZXNzJTIwY29hY2glMjB0cmFpbmVyJTIwcHJvZmVzc2lvbmFsfGVufDF8fHx8MTc2OTU5Nzg3N3ww&ixlib=rb-4.1.0&q=80&w=1080"
    }
  ];

  return (
    <section className="py-20 lg:py-28 bg-gradient-to-b from-white to-gray-50" id="medical-partners">
      <div className="container mx-auto px-4 lg:px-8 max-w-7xl">
        {/* Section Title */}
        <div className="text-center mb-16">
          <h2 
            className="text-gray-900 mb-4"
            style={{ 
              fontFamily: 'DM Sans',
              fontSize: 'clamp(28px, 4vw, 42px)',
              lineHeight: '1.2',
              letterSpacing: '-0.02em',
              fontWeight: '400'
            }}
          >
            Meet Our Expert Medical Team
          </h2>
          <p 
            className="text-gray-600 max-w-2xl mx-auto"
            style={{ 
              fontFamily: 'DM Sans',
              fontSize: '16px',
              lineHeight: '1.6'
            }}
          >
            Our board-certified physicians and certified wellness professionals work together to provide comprehensive, personalized care for your weight loss journey.
          </p>
        </div>

        {/* Medical Doctors Section */}
        <div className="mb-20">
          <div className="flex items-center gap-3 mb-8">
            <div className="h-1 w-12 bg-[#4A6B78] rounded"></div>
            <h3 
              className="text-gray-900"
              style={{ 
                fontFamily: 'Bebas Neue',
                fontSize: 'clamp(24px, 3vw, 32px)',
                letterSpacing: '0.02em'
              }}
            >
              Board-Certified Physicians
            </h3>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {doctors.map((doctor, index) => (
              <div 
                key={index}
                className="bg-white rounded-2xl overflow-hidden shadow-lg hover:shadow-2xl transition-all duration-300 group"
              >
                <div className="relative h-80 overflow-hidden">
                  <ImageWithFallback
                    src={doctor.image}
                    alt={doctor.name}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-black/20 to-transparent"></div>
                  <div className="absolute bottom-0 left-0 right-0 p-6 text-white">
                    <p 
                      className="text-sm mb-1 opacity-90"
                      style={{ fontFamily: 'DM Sans' }}
                    >
                      {doctor.title}
                    </p>
                    <h4 
                      className="mb-2"
                      style={{ 
                        fontFamily: 'Bebas Neue',
                        fontSize: '24px',
                        letterSpacing: '0.02em'
                      }}
                    >
                      {doctor.name}
                    </h4>
                  </div>
                </div>
                <div className="p-6">
                  <p 
                    className="text-gray-700 mb-3"
                    style={{ 
                      fontFamily: 'DM Sans',
                      fontSize: '14px',
                      lineHeight: '1.5',
                      fontWeight: '500'
                    }}
                  >
                    {doctor.specialization}
                  </p>
                  <div className="flex items-center gap-2">
                    <div className="w-2 h-2 bg-[#55675E] rounded-full"></div>
                    <p 
                      className="text-gray-600 text-sm"
                      style={{ fontFamily: 'DM Sans' }}
                    >
                      {doctor.experience} experience
                    </p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Nutrition & Fitness Coaches Section */}
        <div>
          <div className="flex items-center gap-3 mb-8">
            <div className="h-1 w-12 bg-[#55675E] rounded"></div>
            <h3 
              className="text-gray-900"
              style={{ 
                fontFamily: 'Bebas Neue',
                fontSize: 'clamp(24px, 3vw, 32px)',
                letterSpacing: '0.02em'
              }}
            >
              Certified Nutrition & Fitness Coaches
            </h3>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {coaches.map((coach, index) => (
              <div 
                key={index}
                className="bg-white rounded-2xl overflow-hidden shadow-lg hover:shadow-2xl transition-all duration-300 group"
              >
                <div className="relative h-80 overflow-hidden">
                  <ImageWithFallback
                    src={coach.image}
                    alt={coach.name}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-black/20 to-transparent"></div>
                  <div className="absolute bottom-0 left-0 right-0 p-6 text-white">
                    <p 
                      className="text-sm mb-1 opacity-90"
                      style={{ fontFamily: 'DM Sans' }}
                    >
                      {coach.title}
                    </p>
                    <h4 
                      className="mb-2"
                      style={{ 
                        fontFamily: 'Bebas Neue',
                        fontSize: '24px',
                        letterSpacing: '0.02em'
                      }}
                    >
                      {coach.name}
                    </h4>
                  </div>
                </div>
                <div className="p-6">
                  <p 
                    className="text-gray-700 mb-3"
                    style={{ 
                      fontFamily: 'DM Sans',
                      fontSize: '14px',
                      lineHeight: '1.5',
                      fontWeight: '500'
                    }}
                  >
                    {coach.specialization}
                  </p>
                  <div className="flex items-center gap-2">
                    <div className="w-2 h-2 bg-[#4A6B78] rounded-full"></div>
                    <p 
                      className="text-gray-600 text-sm"
                      style={{ fontFamily: 'DM Sans' }}
                    >
                      {coach.credentials}
                    </p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Bottom CTA */}
        <div className="mt-16 text-center bg-[#4A6B78]/5 rounded-2xl p-8">
          <p 
            className="text-gray-700 mb-6 max-w-2xl mx-auto"
            style={{ 
              fontFamily: 'DM Sans',
              fontSize: '16px',
              lineHeight: '1.6'
            }}
          >
            Our multidisciplinary team collaborates to create a personalized treatment plan tailored to your unique health needs and weight loss goals.
          </p>
          <a
            href="/eligibility"
            className="inline-block px-8 py-4 bg-[#4A6B78] text-white rounded-lg hover:bg-[#3E5147] transition-all font-medium"
            style={{ fontFamily: 'DM Sans', fontSize: '16px' }}
          >
            Schedule Your Consultation
          </a>
        </div>
      </div>
    </section>
  );
}
