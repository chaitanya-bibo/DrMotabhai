import { useState } from "react";

export function WeightLossProgram() {
  const [currentWeight, setCurrentWeight] = useState(85);
  const minWeight = 50;
  const maxWeight = 150;
  const potentialLoss = Math.round(currentWeight * 0.15);
  const lossPercentage = 15; // 12-15% is the range, showing 15% as the target

  const handleSliderChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setCurrentWeight(parseInt(e.target.value));
  };

  return (
    <section className="py-20 lg:py-28 bg-[#55675E] relative overflow-hidden">
      <div className="container mx-auto px-4 lg:px-8 relative z-10">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center max-w-7xl mx-auto">
          {/* Left Content */}
          <div>
            <div className="mb-8">
              <h2 
                className="text-white mb-4"
                style={{ 
                  fontFamily: 'Bebas Neue',
                  fontSize: 'clamp(32px, 5vw, 48px)',
                  lineHeight: '1',
                  letterSpacing: '0.08em'
                }}
              >
                DR MOTABHAI <sup style={{ fontSize: '14px', marginLeft: '2px' }}>™</sup>
              </h2>

              <p 
                className="text-white mb-6"
                style={{ 
                  fontFamily: 'DM Sans',
                  fontSize: 'clamp(60px, 10vw, 120px)',
                  lineHeight: '0.9',
                  letterSpacing: '-0.02em',
                  fontWeight: '700'
                }}
              >
                {lossPercentage}% <span style={{ fontSize: 'clamp(24px, 4vw, 48px)' }}>+ 5%<sup style={{ fontSize: '0.5em' }}>*</sup></span>
              </p>

              <p 
                className="text-white/90 mb-4 max-w-md text-sm"
                style={{ 
                  fontFamily: 'DM Sans',
                  lineHeight: '1.6',
                  letterSpacing: '-0.01em'
                }}
              >
                Achieve Sustainable Weight Loss with Clinically Supervised GLP-1 Treatment
              </p>

              <p 
                className="text-white/90 mb-8 max-w-md text-sm"
                style={{ 
                  fontFamily: 'DM Sans',
                  lineHeight: '1.6',
                  letterSpacing: '-0.01em'
                }}
              >
                Patients under Dr Motabhai have achieved up to <strong>12–15% total body weight reduction</strong> through responsible GLP-1 medical therapy.
              </p>

              <p 
                className="text-white/70 mb-8 max-w-md text-xs"
                style={{ 
                  fontFamily: 'DM Sans',
                  lineHeight: '1.6',
                  letterSpacing: '-0.01em'
                }}
              >
                *Results vary based on individual medical evaluation
              </p>

              <p 
                className="text-white/70 mb-8 max-w-md text-xs"
                style={{ 
                  fontFamily: 'DM Sans',
                  lineHeight: '1.6',
                  letterSpacing: '-0.01em'
                }}
              >
                *If followed along with Dr. Motabhai's nutrition and fitness plans
              </p>

              <button 
                className="px-8 py-3 bg-white/90 rounded-lg text-gray-900 hover:bg-white transition-all font-medium"
                style={{ 
                  fontFamily: 'DM Sans',
                  fontSize: '15px',
                  letterSpacing: '-0.01em'
                }}
              >
                Get Started
              </button>
            </div>
          </div>

          {/* Right Content - Weight Loss Calculator */}
          <div className="bg-[#3E5147] rounded-3xl p-8 lg:p-10">
            <p 
              className="text-white/60 text-center mb-6 text-sm uppercase tracking-wider"
              style={{ 
                fontFamily: 'DM Sans',
                letterSpacing: '0.1em'
              }}
            >
              Lose up to
            </p>

            <p 
              className="text-white text-center mb-12"
              style={{ 
                fontFamily: 'DM Sans',
                fontSize: 'clamp(48px, 8vw, 80px)',
                lineHeight: '1',
                letterSpacing: '-0.02em',
                fontWeight: '700'
              }}
            >
              {potentialLoss}Kg
            </p>

            <div className="bg-white rounded-2xl p-6">
              <p 
                className="text-gray-500 uppercase tracking-wider mb-6 text-xs"
                style={{ 
                  fontFamily: 'DM Sans',
                  letterSpacing: '0.15em'
                }}
              >
                Current Weight
              </p>
              
              <div className="relative mb-6">
                <input 
                  type="range"
                  min={minWeight}
                  max={maxWeight}
                  value={currentWeight}
                  onChange={handleSliderChange}
                  className="w-full h-1 bg-gray-200 rounded-full appearance-none cursor-pointer slider-thumb"
                  style={{
                    background: `linear-gradient(to right, #55675E 0%, #55675E ${((currentWeight - minWeight) / (maxWeight - minWeight)) * 100}%, #e5e7eb ${((currentWeight - minWeight) / (maxWeight - minWeight)) * 100}%, #e5e7eb 100%)`
                  }}
                />
              </div>

              <div className="flex justify-center">
                <span 
                  className="px-4 py-1.5 bg-gray-100 rounded-full text-gray-900 text-sm font-medium"
                  style={{ 
                    fontFamily: 'DM Sans'
                  }}
                >
                  {currentWeight} KG
                </span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}