
  # Weight Loss Landing Page (Community)

  This is a code bundle for Weight Loss Landing Page (Community). The original project is available at https://www.figma.com/design/MMUvUxNYLk1vLIoNmt1r08/Weight-Loss-Landing-Page--Community-.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  